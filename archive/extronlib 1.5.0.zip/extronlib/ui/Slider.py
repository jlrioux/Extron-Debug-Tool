from extronlib.device import UIDevice

class Slider():
    """ This module defines interfaces of Slider UI.

    ---

    Arguments:
        - UIHost (extronlib.device.UIDevice) - Device object hosting this UIObject
        - ID (int) - ID of the UIObject

    ---

    Parameters:
        - Host - Returns (extronlib.device.UIDevice) - UIDevice object that hosts this control object
        - ID - Returns (int) - the object ID
        - Fill - Returns (int) - the current fill level
        - Max - Returns (int) - the upper bound of the slider object
        - Min - Returns (int) - the lower bound of the slider object
        - Name - Returns (string) - the object Name
        - Visible - Returns (bool) - True if the control object is visible else False
        - Step - Returns (int, float)	- the step size of the slider object
        - Enabled - Returns (bool) - True if the control object is enabled else False


    Events:
        - Changed - (Event) Triggers when the slider value is changed by user interaction (i.e. after Pressed but before Released).
          -- The callback takes three arguments. The first is the Slider instance triggering the event, the second is the state, and the third is the new slider value.
        - Pressed - (Event) Triggers when the slider is pressed. The callback takes three arguments. The first is the Slider instance triggering the event, the second is the state, and the third is the new slider value
        - Released - (Event) Triggers when the slider is released. The callback takes three arguments. The first is the Slider instance triggering the event, the second is the state, and the third is the new slider value.
    """
    UIHost = None
    Host = None #type:UIDevice
    ID = 0
    Name = ''
    Visible = True
    Level = 0
    Max = 0
    Min = 0
    Step = 0

    def __init__(self, UIDevice:UIDevice, ID: int) -> None:
        """ Level class constructor.

        Arguments:
            - UIHost (extronlib.device.UIDevice) - Device object hosting this UIObject
            - ID (int) - ID of the UIObject
        """
        self.UIHost = UIDevice
        self.ID = ID
        self.Name = ''
        self.Visible = True
        self.Level = 0
        self.Max = 100
        self.Min = 0
        self.Step = 1

    def Dec(self) -> None:
        """ Nudge the level down a step """
        ...

    def Inc(self) -> None:
        """ Nudge the level up a step """
        ...

    def SetFill(self, Fill: int) -> None:
        """ Set the current fill level

        Arguments:
            - Fill (int) - Discrete value of the level object. The default range is 0 - 100 with a step size of 1.
        """
        ...

    def SetRange(self, Min: int, Max: int, Step: int=1) -> None:
        """ Set level object’s allowed range and the step size

        Arguments:
            - Min (int) - Minimum level
            - Max (int) - Maximum level
            - (optional) Step (int) - Optional step size for Inc() and Dec().
        """
        ...

    def SetVisible(self, visible: bool) -> None:
        """ Change the visibility of an UI control object.

        Arguments:
            - visible (bool) - True to make the object visible or False to hide it.
        """
        ...