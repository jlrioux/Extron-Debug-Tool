
import copy
import pprint
from tkinter import *
from Timer import Timer
from Wait import Wait
import json
import re
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from variables import variablesclass

class EthernetAndSerialDevices():
    def __init__(self,frame:'Frame',vars:'variablesclass'):
        #class variables
        self.vars = vars
        self.__frame = frame
        self.__selected_module = None
        self.__selected_virtualui_mode = None
        self.__timestamp_newest_first = True
        self.__device_color_wait = None
        self.__device_color_wait_busy = False

        self.__device_logs = {} #type:dict[list[str]]
        self.__current_tb_log = ''
        self.__tb_pause_flag = False
        self.__tb_hex_flag = False

        #set up the UI
        self.__frame_controller_status = Frame(self.__frame)
        self.__frame_controller_status.grid(column=0,row=0,sticky='nw')
        self.__lbl_controller_status = Label(self.__frame_controller_status,text = ' STATUS : Controller Disconnected')
        self.__lbl_controller_status.grid(column=0,row=0,sticky='nw')

        self.__frame_controller_views = Frame(self.__frame)
        self.__frame_controller_views.grid(column=1,row=0,sticky='nw')
        self.__btn_tb_view_rxtx_view = Button(self.__frame_controller_views,text="RX/TX View",command=self.__controller_rxtx_view_enable)
        self.__btn_tb_view_rxtx_view.grid(column=0,row=0,sticky='nw')
        self.__btn_tb_view_status_view = Button(self.__frame_controller_views,text="Status View",command=self.__controller_status_view_enable)
        self.__btn_tb_view_status_view.grid(column=1,row=0,sticky='nw')

        self.__frame_controller_clear_logs = Frame(self.__frame_controller_views)
        self.__frame_controller_clear_logs.grid(column=2,row=0,sticky='nw')
        self.__btn_tb_clear_all_logs = Button(self.__frame_controller_clear_logs,text="Clear All Logs",command=self.__clear_all_device_logs)
        self.__btn_tb_clear_all_logs.grid(column=0,row=0,sticky='ne')

        self.__frame_devices_found = Frame(self.__frame,height=40,width=20)
        self.__frame_devices_found.grid(column=0,row=1,sticky='nw')
        self.__frame_devices_found_upper = Frame(self.__frame_devices_found,height=20,width=20)
        self.__frame_devices_found_upper.grid(column=0,row=0,sticky='nw')
        self.__lbl_devices_found = Label(self.__frame_devices_found_upper,text = ' Devices Found: ')
        self.__lbl_devices_found.grid(column=0,row=0)
        self.__selected_device = StringVar()
        self.__selected_device.trace('w',self.__selected_device_changed())
        self.__device_list = []
        self.__om_devices = OptionMenu(self.__frame_devices_found_upper,self.__selected_device,self.__device_list)
        self.__om_devices.grid(column=0,row=1,sticky='nsew',pady=2)
        self.__frame_device_reinit = Frame(self.__frame_devices_found_upper)
        self.__frame_device_reinit.grid(column=0,row=2,sticky='nw')
        self.__btn_device_reinit = Button(self.__frame_device_reinit,text='Reinitialize Module',command=self.__cmd_reinitialize_selected_module)
        self.__btn_device_reinit.grid(column=0,row=0,sticky='nsew',pady=2)

        self.__frame_devices_found_lower = Frame(self.__frame_devices_found,height=20,width=20)
        self.__frame_devices_found_lower.grid(column=0,row=1,sticky='nw')
        self.__lbl_selected_device_name = Label(self.__frame_devices_found_lower,text = ' Selected: None')
        self.__lbl_selected_device_name.grid(column=0,row=0,sticky='nw')
        self.__frame_print_to_trace = Frame(self.__frame_devices_found_lower)
        self.__frame_print_to_trace.grid(column=0,row=1,sticky='nw')
        self.__var_device_print_to_trace = IntVar()
        self.__chkbox_device_print_to_trace = Checkbutton(self.__frame_print_to_trace,text='Print To Trace',variable=self.__var_device_print_to_trace,onvalue=1,offvalue=0,command=self.__cmd_device_print_to_trace())
        self.__chkbox_device_print_to_trace.grid(column=0,row=2,sticky='nw')
        self.__lbl_device_comm_detail1 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail1.grid(column=0,row=3,sticky='nw')
        self.__lbl_device_comm_detail2 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail2.grid(column=0,row=4,sticky='nw')
        self.__lbl_device_comm_detail3 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail3.grid(column=0,row=5,sticky='nw')
        self.__lbl_device_comm_detail4 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail4.grid(column=0,row=6,sticky='nw')
        self.__lbl_device_comm_detail5 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail5.grid(column=0,row=7,sticky='nw')
        self.__lbl_device_comm_detail6 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail6.grid(column=0,row=8,sticky='nw')
        self.__lbl_device_comm_detail7 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail7.grid(column=0,row=9,sticky='nw')

        self.__frame_log = Frame(self.__frame,padx=10)
        self.__frame_log.grid(column=1,row=1,sticky='w')

        self.__frame_log_top = Frame(self.__frame_log)
        self.__frame_log_top.grid(column=0,row=0,sticky='w')
        self.__btn_tb_sort_timestamp = Button(self.__frame_log_top,text="Timestamp:Newest",command=self.__toggle_tb_timestamp)
        self.__btn_tb_sort_timestamp.grid(column=0,row=0,sticky='nw')
        self.__btn_tb_clear_log = Button(self.__frame_log_top,text="Clear Log",command=self.__clear_current_device_log)
        self.__btn_tb_clear_log.grid(column=1,row=0,sticky='nw')
        self.__btn_tb_pause_log = Button(self.__frame_log_top,text="Pause Log",command=self.__pause_current_device_log)
        self.__btn_tb_pause_log.grid(column=2,row=0,sticky='nw')
        self.__btn_tb_hex_format = Button(self.__frame_log_top,text="Display HEX",command=self.__format_device_log)
        self.__btn_tb_hex_format.grid(column=3,row=0,sticky='nw')

        self.__tb_log = Text(self.__frame_log,height=20,width=95,wrap='none')
        self.__tb_log.grid(column=0,row=1,sticky='nw')
        self.__scrollb_logy = Scrollbar(self.__frame_log,command=self.__tb_log.yview)
        self.__scrollb_logy.grid(column=1,row=1,sticky='nsew')
        self.__tb_log['yscrollcommand'] = self.__scrollb_logy.set
        self.__scrollb_logx = Scrollbar(self.__frame_log,orient='horizontal',command=self.__tb_log.xview)
        self.__scrollb_logx.grid(column=0,row=2,sticky='nsew')
        self.__tb_log['xscrollcommand'] = self.__scrollb_logx.set

        self.__frame_status = Frame(self.__frame,padx=10)
        self.__frame_status.grid(column=1,row=1,sticky='e')
        self.__tb_status = Text(self.__frame_status,height=20,width=95,wrap='none')
        self.__tb_status.grid(column=0,row=0,sticky='nw')
        self.__scrollb_statusy = Scrollbar(self.__frame_status,command=self.__tb_status.yview)
        self.__scrollb_statusy.grid(column=1,row=0,sticky='nsew')
        self.__tb_status['yscrollcommand'] = self.__scrollb_statusy.set
        self.__scrollb_statusx = Scrollbar(self.__frame_status,orient='horizontal',command=self.__tb_status.xview)
        self.__scrollb_statusx.grid(column=0,row=1,sticky='nsew')
        self.__tb_status['xscrollcommand'] = self.__scrollb_statusx.set




        ''' device module '''
        self.__frame_device_commands = Frame(self.__frame,pady=10)
        self.__frame_device_commands.grid(column=1,row=2,sticky='w')

        self.__frame_device_commands_for_modules = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_modules.grid(column=0,row=0,sticky='w')
        self.__frame_device_commands_for_modules_top = Frame(self.__frame_device_commands_for_modules)
        self.__frame_device_commands_for_modules_top.grid(column=0,row=0,sticky='w')
        #Set(command,value,qualifier)
        self.__lbl_commands_module_set1 = Label(self.__frame_device_commands_for_modules_top,text='Command')
        self.__lbl_commands_module_set1.grid(column=1,row=0,sticky='w')
        self.__lbl_commands_module_set2 = Label(self.__frame_device_commands_for_modules_top,text='Value')
        self.__lbl_commands_module_set2.grid(column=2,row=0,sticky='w')
        self.__lbl_commands_module_set3 = Label(self.__frame_device_commands_for_modules_top,text='Qualifier ( example: {"Output":"1"} )')
        self.__lbl_commands_module_set3.grid(column=3,row=0,sticky='w')
        self.__btn_cmd_set = Button(self.__frame_device_commands_for_modules_top,text="Set",width=15,command=self.__cmd_set_selected_module)
        self.__btn_cmd_set.grid(column=0,row=1,sticky='w')
        self.__tb_set_command1 = Text(self.__frame_device_commands_for_modules_top,height=1,width=15,wrap='none')
        self.__tb_set_command1.grid(column=1,row=1,sticky='w')
        self.__frame_commands_module_set_value = Frame(self.__frame_device_commands_for_modules_top)
        self.__frame_commands_module_set_value.grid(column=2,row=1,sticky='w')
        self.__sv_commands_module_set_value_type = StringVar()
        self.__sv_commands_module_set_value_type.set('String')
        self.__list_commands_module_set_value_type_options = ['String','Float']
        self.__om_commands_module_set_value_type = OptionMenu(self.__frame_commands_module_set_value,self.__sv_commands_module_set_value_type,*self.__list_commands_module_set_value_type_options)
        self.__om_commands_module_set_value_type.grid(column=0,row=0,sticky='w')
        self.__tb_set_command2 = Text(self.__frame_commands_module_set_value,height=1,width=20,wrap='none')
        self.__tb_set_command2.grid(column=1,row=0,sticky='w')
        self.__tb_set_command3 = Text(self.__frame_device_commands_for_modules_top,height=1,width=30,wrap='none')
        self.__tb_set_command3.grid(column=3,row=1,sticky='w')
        #Update(command,qualifier)
        self.__lbl_commands_module_update1 = Label(self.__frame_device_commands_for_modules_top,text='Command')
        self.__lbl_commands_module_update1.grid(column=1,row=2,sticky='w')
        self.__lbl_commands_module_update2 = Label(self.__frame_device_commands_for_modules_top,text='Qualifier ( example: {"Output":"1"} )')
        self.__lbl_commands_module_update2.grid(column=3,row=2,sticky='w')
        self.__btn_cmd_update = Button(self.__frame_device_commands_for_modules_top,text='Update',width=15,command=self.__cmd_update_selected_module)
        self.__btn_cmd_update.grid(column=0,row=3,sticky='w')
        self.__tb_update_command1 = Text(self.__frame_device_commands_for_modules_top,height=1,width=15,wrap='none')
        self.__tb_update_command1.grid(column=1,row=3,sticky='w')
        self.__tb_update_command2 = Text(self.__frame_device_commands_for_modules_top,height=1,width=30,wrap='none')
        self.__tb_update_command2.grid(column=3,row=3,sticky='w')
        #WriteStatus(command,value,qualifier)
        self.__lbl_commands_module_writestatus1 = Label(self.__frame_device_commands_for_modules_top,text='Command')
        self.__lbl_commands_module_writestatus1.grid(column=1,row=4,sticky='w')
        self.__lbl_commands_module_writestatus2 = Label(self.__frame_device_commands_for_modules_top,text='Value')
        self.__lbl_commands_module_writestatus2.grid(column=2,row=4,sticky='w')
        self.__lbl_commands_module_writestatus3 = Label(self.__frame_device_commands_for_modules_top,text='Qualifier ( example: {"Output":"1"} )')
        self.__lbl_commands_module_writestatus3.grid(column=3,row=4,sticky='w')
        self.__btn_cmd_writestatus = Button(self.__frame_device_commands_for_modules_top,text='WriteStatus',width=15,command=self.__cmd_writestatus_selected_module)
        self.__btn_cmd_writestatus.grid(column=0,row=5,sticky='w')
        self.__tb_writestatus_command1 = Text(self.__frame_device_commands_for_modules_top,height=1,width=15,wrap='none')
        self.__tb_writestatus_command1.grid(column=1,row=5,sticky='w')
        self.__frame_commands_module_writestatus_value = Frame(self.__frame_device_commands_for_modules_top)
        self.__frame_commands_module_writestatus_value.grid(column=2,row=5,sticky='w')
        self.__sv_commands_module_writestatus_value_type = StringVar()
        self.__sv_commands_module_writestatus_value_type.set('String')
        self.__list_commands_module_writestatus_value_type_options = ['String','Float']
        self.__om_commands_module_writestatus_value_type = OptionMenu(self.__frame_commands_module_writestatus_value,self.__sv_commands_module_writestatus_value_type,*self.__list_commands_module_writestatus_value_type_options)
        self.__om_commands_module_writestatus_value_type.grid(column=0,row=0,sticky='w')
        self.__tb_writestatus_command2 = Text(self.__frame_commands_module_writestatus_value,height=1,width=20,wrap='none')
        self.__tb_writestatus_command2.grid(column=1,row=0,sticky='w')
        self.__tb_writestatus_command3 = Text(self.__frame_device_commands_for_modules_top,height=1,width=30,wrap='none')
        self.__tb_writestatus_command3.grid(column=3,row=5,sticky='w')
        self.__frame_device_commands_for_modules_bottom = Frame(self.__frame_device_commands_for_modules)
        self.__frame_device_commands_for_modules_bottom.grid(column=0,row=1,sticky='w')
        #Passthrough
        self.__lbl_passthrough_commmand = Label(self.__frame_device_commands_for_modules_bottom,text='Command ( example: power on\\x0d\\x0a )')
        self.__lbl_passthrough_commmand.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_passthrough = Button(self.__frame_device_commands_for_modules_bottom,text='Passthrough',width=15,command=self.__cmd_passthrough_selected_module)
        self.__btn_cmd_passthrough.grid(column=0,row=1,sticky='w')
        self.__tb_passthrough_command = Text(self.__frame_device_commands_for_modules_bottom,height=1,width=65,wrap='none')
        self.__tb_passthrough_command.grid(column=1,row=1,sticky='w')

        ''' circuit breaker '''
        self.__frame_device_commands_for_circuit_breaker = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_circuit_breaker.grid(column=0,row=1,sticky='w')
        #none

        ''' contact '''
        self.__frame_device_commands_for_contact = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_contact.grid(column=0,row=2,sticky='w')
        #none

        ''' digital input '''
        self.__frame_device_commands_for_digital_input = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_digital_input.grid(column=0,row=3,sticky='w')
        #Initialize (host,port,pullup)
        self.__lbl_device_commands_digital_input_initialize1 = Label(self.__frame_device_commands_for_digital_input,text='Pullup')
        self.__lbl_device_commands_digital_input_initialize1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_digital_input_initialize = Button(self.__frame_device_commands_for_digital_input,text='Initialize',width=15,command=self.__cmd_initialize_selected_device)
        self.__btn_cmd_digital_input_initialize.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_digital_input_initialize1 = Text(self.__frame_device_commands_for_digital_input,height=1,width=20,wrap='none')
        self.__tb_cmd_digital_input_initialize1.grid(column=1,row=1,sticky='w')

        ''' digital io '''
        self.__frame_device_commands_for_digital_io = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_digital_io.grid(column=0,row=4,sticky='w')
        #Initialize (host,port,pullup)
        self.__lbl_device_commands_digital_io_initialize1 = Label(self.__frame_device_commands_for_digital_io,text='Mode')
        self.__lbl_device_commands_digital_io_initialize1.grid(column=1,row=0,sticky='w')
        self.__lbl_device_commands_digital_io_initialize2 = Label(self.__frame_device_commands_for_digital_io,text='Pullup')
        self.__lbl_device_commands_digital_io_initialize2.grid(column=2,row=0,sticky='w')
        self.__btn_cmd_digital_io_initialize = Button(self.__frame_device_commands_for_digital_io,text='Initialize',width=15,command=self.__cmd_initialize_selected_device)
        self.__btn_cmd_digital_io_initialize.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_digital_io_initialize1 = Text(self.__frame_device_commands_for_digital_io,height=1,width=20,wrap='none')
        self.__tb_cmd_digital_io_initialize1.grid(column=1,row=1,sticky='w')
        self.__tb_cmd_digital_io_initialize2 = Text(self.__frame_device_commands_for_digital_io,height=1,width=20,wrap='none')
        self.__tb_cmd_digital_io_initialize2.grid(column=2,row=1,sticky='w')
        #Pulse(duration)
        self.__lbl_device_commands_digital_io_pulse1 = Label(self.__frame_device_commands_for_digital_io,text='Duration')
        self.__lbl_device_commands_digital_io_pulse1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_digital_io_pulse = Button(self.__frame_device_commands_for_digital_io,text='Pulse',width=15,command=self.__cmd_pulse_selected_device)
        self.__btn_cmd_digital_io_pulse.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_digital_io_pulse1 = Text(self.__frame_device_commands_for_digital_io,height=1,width=20,wrap='none')
        self.__tb_cmd_digital_io_pulse1.grid(column=1,row=3,sticky='w')
        #State('On' or 'Off')
        self.__lbl_device_commands_digital_io_state1 = Label(self.__frame_device_commands_for_digital_io,text='On or Off')
        self.__lbl_device_commands_digital_io_state1.grid(column=1,row=4,sticky='w')
        self.__btn_cmd_digital_io_state = Button(self.__frame_device_commands_for_digital_io,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_digital_io_state.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_digital_io_state1 = Text(self.__frame_device_commands_for_digital_io,height=1,width=20,wrap='none')
        self.__tb_cmd_digital_io_state1.grid(column=1,row=5,sticky='w')
        #Toggle
        self.__btn_cmd_digital_io_toggle = Button(self.__frame_device_commands_for_digital_io,text='Toggle',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_digital_io_toggle.grid(column=0,row=6,sticky='w')

        ''' flex io '''
        self.__frame_device_commands_for_flex_io = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_flex_io.grid(column=0,row=5,sticky='w')
        #initialize (mode,pullup,upper,lower)
        self.__lbl_device_commands_flex_io_initialize1 = Label(self.__frame_device_commands_for_flex_io,text='Mode')
        self.__lbl_device_commands_flex_io_initialize1.grid(column=1,row=0,sticky='w')
        self.__lbl_device_commands_flex_io_initialize2 = Label(self.__frame_device_commands_for_flex_io,text='Pullup')
        self.__lbl_device_commands_flex_io_initialize2.grid(column=2,row=0,sticky='w')
        self.__lbl_device_commands_flex_io_initialize3 = Label(self.__frame_device_commands_for_flex_io,text='Upper')
        self.__lbl_device_commands_flex_io_initialize3.grid(column=3,row=0,sticky='w')
        self.__lbl_device_commands_flex_io_initialize4 = Label(self.__frame_device_commands_for_flex_io,text='Lower')
        self.__lbl_device_commands_flex_io_initialize4.grid(column=4,row=0,sticky='w')
        self.__btn_cmd_flex_io_initialize = Button(self.__frame_device_commands_for_flex_io,text='Initialize',width=15,command=self.__cmd_initialize_selected_device)
        self.__btn_cmd_flex_io_initialize.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_flex_io_initialize1 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_initialize1.grid(column=1,row=1,sticky='w')
        self.__tb_cmd_flex_io_initialize2 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_initialize2.grid(column=2,row=1,sticky='w')
        self.__tb_cmd_flex_io_initialize3 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_initialize3.grid(column=3,row=1,sticky='w')
        self.__tb_cmd_flex_io_initialize4 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_initialize4.grid(column=4,row=1,sticky='w')
        #Pulse(duration)
        self.__lbl_device_commands_flex_io_pulse1 = Label(self.__frame_device_commands_for_flex_io,text='Duration')
        self.__lbl_device_commands_flex_io_pulse1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_flex_io_pulse = Button(self.__frame_device_commands_for_flex_io,text='Pulse',width=15,command=self.__cmd_pulse_selected_device)
        self.__btn_cmd_flex_io_pulse.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_flex_io_pulse1 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_pulse1.grid(column=1,row=3,sticky='w')
        #State('On' or 'Off')
        self.__lbl_device_commands_flex_io_state1 = Label(self.__frame_device_commands_for_flex_io,text='On or Off')
        self.__lbl_device_commands_flex_io_state1.grid(column=1,row=4,sticky='w')
        self.__btn_cmd_flex_io_state = Button(self.__frame_device_commands_for_flex_io,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_flex_io_state.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_flex_io_state1 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_state1.grid(column=1,row=5,sticky='w')
        #Toggle
        self.__btn_cmd_flex_io_toggle = Button(self.__frame_device_commands_for_flex_io,text='Toggle',width=15,command=self.__cmd_toggle_selected_device)
        self.__btn_cmd_flex_io_toggle.grid(column=0,row=6,sticky='w')

        ''' ir '''
        self.__frame_device_commands_for_ir = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_ir.grid(column=0,row=6,sticky='w')
        #PlayContinuous(command)
        self.__lbl_device_commands_ir_playcontinuous1 = Label(self.__frame_device_commands_for_ir,text='Command')
        self.__lbl_device_commands_ir_playcontinuous1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_ir_playcontinuous = Button(self.__frame_device_commands_for_ir,text='PlayContinuous',width=15,command=self.__cmd_playcontinuous_selected_device)
        self.__btn_cmd_ir_playcontinuous.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_ir_playcontinuous1 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_playcontinuous1.grid(column=1,row=1,sticky='w')
        #PlayTime(command,duration)
        self.__lbl_device_commands_ir_playtime1 = Label(self.__frame_device_commands_for_ir,text='Command')
        self.__lbl_device_commands_ir_playtime1.grid(column=1,row=2,sticky='w')
        self.__lbl_device_commands_ir_playtime2 = Label(self.__frame_device_commands_for_ir,text='Duration')
        self.__lbl_device_commands_ir_playtime2.grid(column=2,row=2,sticky='w')
        self.__btn_cmd_ir_playtime = Button(self.__frame_device_commands_for_ir,text='PlayTime',width=15,command=self.__cmd_playtime_selected_device)
        self.__btn_cmd_ir_playtime.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_ir_playtime1 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_playtime1.grid(column=1,row=3,sticky='w')
        self.__tb_cmd_ir_playtime2 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_playtime2.grid(column=2,row=3,sticky='w')
        #PlayCount(comand,count)
        self.__lbl_device_commands_ir_playcount1 = Label(self.__frame_device_commands_for_ir,text='Command')
        self.__lbl_device_commands_ir_playcount1.grid(column=1,row=4,sticky='w')
        self.__lbl_device_commands_ir_playcount2 = Label(self.__frame_device_commands_for_ir,text='Count')
        self.__lbl_device_commands_ir_playcount2.grid(column=2,row=4,sticky='w')
        self.__btn_cmd_ir_playcount = Button(self.__frame_device_commands_for_ir,text='PlayCount',width=15,command=self.__cmd_playcount_selected_device)
        self.__btn_cmd_ir_playcount.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_ir_playcount1 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_playcount1.grid(column=1,row=5,sticky='w')
        self.__tb_cmd_ir_playcount2 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_playcount2.grid(column=2,row=5,sticky='w')
        #Stop
        self.__btn_cmd_ir_stop = Button(self.__frame_device_commands_for_ir,text='Stop',width=15,command=self.__cmd_stop_selected_device)
        self.__btn_cmd_ir_stop.grid(column=0,row=6,sticky='w')
        #Initialize(file)
        self.__lbl_device_commands_ir_initialize1 = Label(self.__frame_device_commands_for_ir,text='Command')
        self.__lbl_device_commands_ir_initialize1.grid(column=1,row=7,sticky='w')
        self.__btn_cmd_ir_initialize = Button(self.__frame_device_commands_for_ir,text='Initialize',width=15,command=self.__cmd_initialize_selected_device)
        self.__btn_cmd_ir_initialize.grid(column=0,row=8,sticky='w')
        self.__tb_cmd_ir_initialize1 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_initialize1.grid(column=1,row=8,sticky='w')

        ''' PoE '''
        self.__frame_device_commands_for_poe = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_poe.grid(column=0,row=7,sticky='w')
        #State('On' or 'Off')
        self.__lbl_device_commands_poe_state1 = Label(self.__frame_device_commands_for_poe,text='On or Off')
        self.__lbl_device_commands_poe_state1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_poe_state = Button(self.__frame_device_commands_for_poe,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_poe_state.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_poe_state1 = Text(self.__frame_device_commands_for_poe,height=1,width=20,wrap='none')
        self.__tb_cmd_poe_state1.grid(column=1,row=1,sticky='w')
        #Toggle
        self.__btn_cmd_poe_toggle = Button(self.__frame_device_commands_for_poe,text='Toggle',width=15,command=self.__cmd_toggle_selected_device)
        self.__btn_cmd_poe_toggle.grid(column=0,row=2,sticky='w')

        ''' relay '''
        self.__frame_device_commands_for_relay = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_relay.grid(column=0,row=8,sticky='w')
        #Pulse(duration)
        self.__lbl_device_commands_relay_pulse1 = Label(self.__frame_device_commands_for_relay,text='Duration')
        self.__lbl_device_commands_relay_pulse1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_relay_pulse = Button(self.__frame_device_commands_for_relay,text='Pulse',width=15,command=self.__cmd_pulse_selected_device)
        self.__btn_cmd_relay_pulse.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_relay_pulse1 = Text(self.__frame_device_commands_for_relay,height=1,width=20,wrap='none')
        self.__tb_cmd_relay_pulse1.grid(column=1,row=1,sticky='w')
        #State('Open' or 'Close')
        self.__lbl_device_commands_relay_state1 = Label(self.__frame_device_commands_for_relay,text='Open or Close')
        self.__lbl_device_commands_relay_state1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_relay_state = Button(self.__frame_device_commands_for_relay,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_relay_state.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_relay_state1 = Text(self.__frame_device_commands_for_relay,height=1,width=20,wrap='none')
        self.__tb_cmd_relay_state1.grid(column=1,row=3,sticky='w')
        #Toggle
        self.__btn_cmd_relay_toggle = Button(self.__frame_device_commands_for_relay,text='Toggle',width=15,command=self.__cmd_toggle_selected_device)
        self.__btn_cmd_relay_toggle.grid(column=0,row=4,sticky='w')

        ''' swac receptacle '''
        self.__frame_device_commands_for_swac_receptacle = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_swac_receptacle.grid(column=0,row=9,sticky='w')
        #State('On' or 'Off')
        self.__lbl_device_commands_swac_receptacle_state1 = Label(self.__frame_device_commands_for_swac_receptacle,text='On or Off')
        self.__lbl_device_commands_swac_receptacle_state1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_swac_receptacle_state = Button(self.__frame_device_commands_for_swac_receptacle,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_swac_receptacle_state.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_swac_receptacle_state1 = Text(self.__frame_device_commands_for_swac_receptacle,height=1,width=20,wrap='none')
        self.__tb_cmd_swac_receptacle_state1.grid(column=1,row=1,sticky='w')
        #Toggle
        self.__btn_cmd_swac_receptacle_toggle = Button(self.__frame_device_commands_for_swac_receptacle,text='Toggle',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_swac_receptacle_toggle.grid(column=0,row=2,sticky='w')

        ''' sw power '''
        self.__frame_device_commands_for_sw_power = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_sw_power.grid(column=0,row=10,sticky='w')
        #Pulse(duration)
        self.__lbl_device_commands_sw_power_pulse1 = Label(self.__frame_device_commands_for_sw_power,text='Duration')
        self.__lbl_device_commands_sw_power_pulse1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_sw_power_pulse = Button(self.__frame_device_commands_for_sw_power,text='Pulse',width=15,command=self.__cmd_pulse_selected_device)
        self.__btn_cmd_sw_power_pulse.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_sw_power_pulse1 = Text(self.__frame_device_commands_for_sw_power,height=1,width=20,wrap='none')
        self.__tb_cmd_sw_power_pulse1.grid(column=1,row=1,sticky='w')
        #State('Open' or 'Close')
        self.__lbl_device_commands_sw_power_state1 = Label(self.__frame_device_commands_for_sw_power,text='Open or Close')
        self.__lbl_device_commands_sw_power_state1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_sw_power_state = Button(self.__frame_device_commands_for_sw_power,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_sw_power_state.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_sw_power_state1 = Text(self.__frame_device_commands_for_sw_power,height=1,width=20,wrap='none')
        self.__tb_cmd_sw_power_state1.grid(column=1,row=3,sticky='w')
        #Toggle
        self.__btn_cmd_sw_power_toggle = Button(self.__frame_device_commands_for_sw_power,text='Toggle',width=15,command=self.__cmd_toggle_selected_device)
        self.__btn_cmd_sw_power_toggle.grid(column=0,row=4,sticky='w')

        ''' tally '''
        self.__frame_device_commands_for_tally = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_tally.grid(column=0,row=11,sticky='w')
        #Pulse(duration)
        self.__lbl_device_commands_tally_pulse1 = Label(self.__frame_device_commands_for_tally,text='Duration')
        self.__lbl_device_commands_tally_pulse1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_tally_pulse = Button(self.__frame_device_commands_for_tally,text='Pulse',width=15,command=self.__cmd_pulse_selected_device)
        self.__btn_cmd_tally_pulse.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_tally_pulse1 = Text(self.__frame_device_commands_for_tally,height=1,width=20,wrap='none')
        self.__tb_cmd_tally_pulse1.grid(column=1,row=1,sticky='w')
        #State('On' or 'Off')
        self.__lbl_device_commands_tally_state1 = Label(self.__frame_device_commands_for_tally,text='On or Off')
        self.__lbl_device_commands_tally_state1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_tally_state = Button(self.__frame_device_commands_for_tally,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_tally_state.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_tally_state1 = Text(self.__frame_device_commands_for_tally,height=1,width=20,wrap='none')
        self.__tb_cmd_tally_state1.grid(column=1,row=3,sticky='w')
        #Toggle
        self.__btn_cmd_tally_toggle = Button(self.__frame_device_commands_for_tally,text='Toggle',width=15,command=self.__cmd_toggle_selected_device)
        self.__btn_cmd_tally_toggle.grid(column=0,row=4,sticky='w')

        ''' volume '''
        self.__frame_device_commands_for_volume = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_volume.grid(column=0,row=12,sticky='w')
        #Level(value)
        self.__lbl_device_commands_volume_level1 = Label(self.__frame_device_commands_for_volume,text='Number')
        self.__lbl_device_commands_volume_level1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_volume_level = Button(self.__frame_device_commands_for_volume,text='Volume',width=15,command=self.__cmd_level_selected_device)
        self.__btn_cmd_volume_level.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_volume_level1 = Text(self.__frame_device_commands_for_volume,height=1,width=20,wrap='none')
        self.__tb_cmd_volume_level1.grid(column=1,row=1,sticky='w')
        #Mute('On' or 'Off')
        self.__lbl_device_commands_volume_mute1 = Label(self.__frame_device_commands_for_volume,text='On or Off')
        self.__lbl_device_commands_volume_mute1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_volume_mute = Button(self.__frame_device_commands_for_volume,text='Mute',width=15,command=self.__cmd_mute_selected_device)
        self.__btn_cmd_volume_mute.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_volume_mute1 = Text(self.__frame_device_commands_for_volume,height=1,width=20,wrap='none')
        self.__tb_cmd_volume_mute1.grid(column=1,row=3,sticky='w')
        #Range(min,max)
        self.__lbl_device_commands_volume_range1 = Label(self.__frame_device_commands_for_volume,text='Min')
        self.__lbl_device_commands_volume_range1.grid(column=1,row=4,sticky='w')
        self.__lbl_device_commands_volume_range1 = Label(self.__frame_device_commands_for_volume,text='Max')
        self.__lbl_device_commands_volume_range1.grid(column=2,row=4,sticky='w')
        self.__btn_cmd_volume_range = Button(self.__frame_device_commands_for_volume,text='Range',width=15,command=self.__cmd_range_selected_device)
        self.__btn_cmd_volume_range.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_volume_range1 = Text(self.__frame_device_commands_for_volume,height=1,width=20,wrap='none')
        self.__tb_cmd_volume_range1.grid(column=1,row=5,sticky='w')
        self.__tb_cmd_volume_range2 = Text(self.__frame_device_commands_for_volume,height=1,width=20,wrap='none')
        self.__tb_cmd_volume_range2.grid(column=2,row=5,sticky='w')
        #SoftStart('Enabled' or 'Disabled')
        self.__lbl_device_commands_volume_softstart1 = Label(self.__frame_device_commands_for_volume,text='Enabled or Disabled')
        self.__lbl_device_commands_volume_softstart1.grid(column=1,row=6,sticky='w')
        self.__btn_cmd_volume_softstart = Button(self.__frame_device_commands_for_volume,text='SoftStart',width=15,command=self.__cmd_softstart_selected_device)
        self.__btn_cmd_volume_softstart.grid(column=0,row=7,sticky='w')
        self.__tb_cmd_volume_softstart1 = Text(self.__frame_device_commands_for_volume,height=1,width=20,wrap='none')
        self.__tb_cmd_volume_softstart1.grid(column=1,row=7,sticky='w')

        ''' processor '''
        self.__frame_device_commands_for_processor = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_processor.grid(column=0,row=13,sticky='w')
        #Reboot()
        self.__btn_cmd_processor_reboot = Button(self.__frame_device_commands_for_processor,text='Reboot',width=15,command=self.__cmd_reboot_selected_device)
        self.__btn_cmd_processor_reboot.grid(column=0,row=0,sticky='w')
        #SaveProgramLog()
        self.__btn_cmd_processor_savepgmlog = Button(self.__frame_device_commands_for_processor,text='SaveProgramLog',width=15,command=self.__cmd_savepgmlog_selected_device)
        self.__btn_cmd_processor_savepgmlog.grid(column=0,row=1,sticky='w')
        #ExecutiveMode(int)
        self.__lbl_device_commands_processor_executivemode1 = Label(self.__frame_device_commands_for_processor,text='Only available on PCS1 models')
        self.__lbl_device_commands_processor_executivemode1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_processor_executivemode = Button(self.__frame_device_commands_for_processor,text='ExecutiveMode',width=15,command=self.__cmd_executivemode_selected_device)
        self.__btn_cmd_processor_executivemode.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_processor_executivemode1 = Text(self.__frame_device_commands_for_processor,height=1,width=20,wrap='none')
        self.__tb_cmd_processor_executivemode1.grid(column=1,row=3,sticky='w')

        ''' ui '''
        self.__frame_device_commands_for_ui = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_ui.grid(column=0,row=14,sticky='w')
        #ShowPage(str)
        self.__lbl_device_commands_ui_showpage1 = Label(self.__frame_device_commands_for_ui,text='Page Name')
        self.__lbl_device_commands_ui_showpage1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_ui_showpage = Button(self.__frame_device_commands_for_ui,text='ShowPage',width=15,command=self.__cmd_showpage_selected_device)
        self.__btn_cmd_ui_showpage.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_ui_showpage1 = Text(self.__frame_device_commands_for_ui,height=1,width=20,wrap='none')
        self.__tb_cmd_ui_showpage1.grid(column=1,row=1,sticky='w')
        #ShowPopup(str,int)
        self.__lbl_device_commands_ui_showpopup1 = Label(self.__frame_device_commands_for_ui,text='Popup Name')
        self.__lbl_device_commands_ui_showpopup1.grid(column=1,row=2,sticky='w')
        self.__lbl_device_commands_ui_showpopup2 = Label(self.__frame_device_commands_for_ui,text='Duration(int,optional)')
        self.__lbl_device_commands_ui_showpopup2.grid(column=2,row=2,sticky='w')
        self.__btn_cmd_ui_showpopup = Button(self.__frame_device_commands_for_ui,text='ShowPopup',width=15,command=self.__cmd_showpopup_selected_device)
        self.__btn_cmd_ui_showpopup.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_ui_showpopup1 = Text(self.__frame_device_commands_for_ui,height=1,width=20,wrap='none')
        self.__tb_cmd_ui_showpopup1.grid(column=1,row=3,sticky='w')
        self.__tb_cmd_ui_showpopup2 = Text(self.__frame_device_commands_for_ui,height=1,width=20,wrap='none')
        self.__tb_cmd_ui_showpopup2.grid(column=2,row=3,sticky='w')
        #HidePopup(str)
        self.__lbl_device_commands_ui_hidepopup1 = Label(self.__frame_device_commands_for_ui,text='Page Name')
        self.__lbl_device_commands_ui_hidepopup1.grid(column=1,row=4,sticky='w')
        self.__btn_cmd_ui_hidepopup = Button(self.__frame_device_commands_for_ui,text='HidePopup',width=15,command=self.__cmd_hidepopup_selected_device)
        self.__btn_cmd_ui_hidepopup.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_ui_hidepopup1 = Text(self.__frame_device_commands_for_ui,height=1,width=20,wrap='none')
        self.__tb_cmd_ui_hidepopup1.grid(column=1,row=5,sticky='w')
        #HidePopupGroup(int)
        self.__lbl_device_commands_ui_hidepopupgroup1 = Label(self.__frame_device_commands_for_ui,text='Group ID(int)')
        self.__lbl_device_commands_ui_hidepopupgroup1.grid(column=1,row=4,sticky='w')
        self.__btn_cmd_ui_hidepopupgroup = Button(self.__frame_device_commands_for_ui,text='HidePopupGroup',width=15,command=self.__cmd_hidepopupgroup_selected_device)
        self.__btn_cmd_ui_hidepopupgroup.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_ui_hidepopupgroup1 = Text(self.__frame_device_commands_for_ui,height=1,width=20,wrap='none')
        self.__tb_cmd_ui_hidepopupgroup1.grid(column=1,row=5,sticky='w')
        #HideAllPopups()
        self.__btn_cmd_ui_hideallpopups = Button(self.__frame_device_commands_for_ui,text='HideAllPopups',width=15,command=self.__cmd_hideallpopups_selected_device)
        self.__btn_cmd_ui_hideallpopups.grid(column=0,row=6,sticky='w')
        #Wake()
        self.__btn_cmd_ui_wake = Button(self.__frame_device_commands_for_ui,text='Wake',width=15,command=self.__cmd_wake_selected_device)
        self.__btn_cmd_ui_wake.grid(column=0,row=7,sticky='w')
        #Sleep()
        self.__btn_cmd_ui_sleep = Button(self.__frame_device_commands_for_ui,text='Sleep',width=15,command=self.__cmd_sleep_selected_device)
        self.__btn_cmd_ui_sleep.grid(column=0,row=8,sticky='w')
        #Reboot()
        self.__btn_cmd_ui_reboot = Button(self.__frame_device_commands_for_ui,text='Reboot',width=15,command=self.__cmd_reboot_selected_device)
        self.__btn_cmd_ui_reboot.grid(column=0,row=9,sticky='w')


        ''' virtual ui '''
        self.__frame_device_virtualui = Frame(self.__frame_device_commands)
        self.__frame_device_virtualui.grid(column=0,row=15,sticky='w')

        self.__frame_device_modes_for_virtualui = Frame(self.__frame_device_virtualui)
        self.__frame_device_modes_for_virtualui.grid(column=0,row=0,sticky='w')
        self.__btn_mode_virtualui_navigation = Button(self.__frame_device_modes_for_virtualui,text='Navigation',width=15,command=self.__set_device_virtualui_mode('Navigation'))
        self.__btn_mode_virtualui_navigation.grid(column=0,row=0,sticky='w')
        self.__btn_mode_virtualui_buttons = Button(self.__frame_device_modes_for_virtualui,text='Button',width=15,command=self.__set_device_virtualui_mode('Button'))
        self.__btn_mode_virtualui_buttons.grid(column=1,row=0,sticky='w')
        self.__btn_mode_virtualui_knobs = Button(self.__frame_device_modes_for_virtualui,text='Knob',width=15,command=self.__set_device_virtualui_mode('Knob'))
        self.__btn_mode_virtualui_knobs.grid(column=2,row=0,sticky='w')
        self.__btn_mode_virtualui_labels = Button(self.__frame_device_modes_for_virtualui,text='Label',width=15,command=self.__set_device_virtualui_mode('Label'))
        self.__btn_mode_virtualui_labels.grid(column=3,row=0,sticky='w')
        self.__btn_mode_virtualui_levels = Button(self.__frame_device_modes_for_virtualui,text='Level',width=15,command=self.__set_device_virtualui_mode('Level'))
        self.__btn_mode_virtualui_levels.grid(column=4,row=0,sticky='w')
        self.__btn_mode_virtualui_sliders = Button(self.__frame_device_modes_for_virtualui,text='Slider',width=15,command=self.__set_device_virtualui_mode('Slider'))
        self.__btn_mode_virtualui_sliders.grid(column=5,row=0,sticky='w')

        self.__frame_device_commands_for_virtualui_navigation = Frame(self.__frame_device_virtualui)
        self.__frame_device_commands_for_virtualui_navigation.grid(column=0,row=1,sticky='w')
        #ShowPage(str)
        self.__lbl_device_commands_virtualui_showpage1 = Label(self.__frame_device_commands_for_virtualui_navigation,text='Page Name')
        self.__lbl_device_commands_virtualui_showpage1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_virtualui_showpage = Button(self.__frame_device_commands_for_virtualui_navigation,text='ShowPage',width=15,command=self.__cmd_showpage_selected_device)
        self.__btn_cmd_virtualui_showpage.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_virtualui_showpage1 = Text(self.__frame_device_commands_for_virtualui_navigation,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_showpage1.grid(column=1,row=1,sticky='w')
        #ShowPopup(str,int)
        self.__lbl_device_commands_virtualui_showpopup1 = Label(self.__frame_device_commands_for_virtualui_navigation,text='Popup Name')
        self.__lbl_device_commands_virtualui_showpopup1.grid(column=1,row=2,sticky='w')
        self.__lbl_device_commands_virtualui_showpopup2 = Label(self.__frame_device_commands_for_virtualui_navigation,text='Duration(int,optional)')
        self.__lbl_device_commands_virtualui_showpopup2.grid(column=2,row=2,sticky='w')
        self.__btn_cmd_virtualui_showpopup = Button(self.__frame_device_commands_for_virtualui_navigation,text='ShowPopup',width=15,command=self.__cmd_showpopup_selected_device)
        self.__btn_cmd_virtualui_showpopup.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_virtualui_showpopup1 = Text(self.__frame_device_commands_for_virtualui_navigation,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_showpopup1.grid(column=1,row=3,sticky='w')
        self.__tb_cmd_virtualui_showpopup2 = Text(self.__frame_device_commands_for_virtualui_navigation,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_showpopup2.grid(column=2,row=3,sticky='w')
        #HidePopup(str)
        self.__lbl_device_commands_virtualui_hidepopup1 = Label(self.__frame_device_commands_for_virtualui_navigation,text='Page Name')
        self.__lbl_device_commands_virtualui_hidepopup1.grid(column=1,row=4,sticky='w')
        self.__btn_cmd_virtualui_hidepopup = Button(self.__frame_device_commands_for_virtualui_navigation,text='HidePopup',width=15,command=self.__cmd_hidepopup_selected_device)
        self.__btn_cmd_virtualui_hidepopup.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_virtualui_hidepopup1 = Text(self.__frame_device_commands_for_virtualui_navigation,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_hidepopup1.grid(column=1,row=5,sticky='w')
        #HidePopupGroup(int)
        self.__lbl_device_commands_virtualui_hidepopupgroup1 = Label(self.__frame_device_commands_for_virtualui_navigation,text='Group ID(int)')
        self.__lbl_device_commands_virtualui_hidepopupgroup1.grid(column=1,row=6,sticky='w')
        self.__btn_cmd_virtualui_hidepopupgroup = Button(self.__frame_device_commands_for_virtualui_navigation,text='HidePopupGroup',width=15,command=self.__cmd_hidepopupgroup_selected_device)
        self.__btn_cmd_virtualui_hidepopupgroup.grid(column=0,row=7,sticky='w')
        self.__tb_cmd_virtualui_hidepopupgroup1 = Text(self.__frame_device_commands_for_virtualui_navigation,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_hidepopupgroup1.grid(column=1,row=7,sticky='w')
        #HideAllPopups()
        self.__btn_cmd_virtualui_hideallpopups = Button(self.__frame_device_commands_for_virtualui_navigation,text='HideAllPopups',width=15,command=self.__cmd_hideallpopups_selected_device)
        self.__btn_cmd_virtualui_hideallpopups.grid(column=0,row=8,sticky='w')

        self.__frame_device_commands_for_virtualui_button = Frame(self.__frame_device_virtualui)
        self.__frame_device_commands_for_virtualui_button.grid(column=0,row=2,sticky='w')
        #SetState(list[int],int)
        self.__lbl_device_commands_virtualui_button_setstate1 = Label(self.__frame_device_commands_for_virtualui_button,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_button_setstate1.grid(column=1,row=0,sticky='w')
        self.__lbl_device_commands_virtualui_button_setstate2 = Label(self.__frame_device_commands_for_virtualui_button,text='State(int)')
        self.__lbl_device_commands_virtualui_button_setstate2.grid(column=2,row=0,sticky='w')
        self.__btn_cmd_virtualui_button_setstate = Button(self.__frame_device_commands_for_virtualui_button,text='SetState',width=15,command=self.__cmd_setstate_selected_device)
        self.__btn_cmd_virtualui_button_setstate.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_virtualui_button_setstate1 = Text(self.__frame_device_commands_for_virtualui_button,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_button_setstate1.grid(column=1,row=1,sticky='w')
        self.__tb_cmd_virtualui_button_setstate2 = Text(self.__frame_device_commands_for_virtualui_button,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_button_setstate2.grid(column=2,row=1,sticky='w')
        #SetText(list[int],str)
        self.__lbl_device_commands_virtualui_button_settext1 = Label(self.__frame_device_commands_for_virtualui_button,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_button_settext1.grid(column=1,row=2,sticky='w')
        self.__lbl_device_commands_virtualui_button_settext2 = Label(self.__frame_device_commands_for_virtualui_button,text='Text')
        self.__lbl_device_commands_virtualui_button_settext2.grid(column=2,row=2,sticky='w')
        self.__btn_cmd_virtualui_button_settext = Button(self.__frame_device_commands_for_virtualui_button,text='SetText',width=15,command=self.__cmd_settext_selected_device)
        self.__btn_cmd_virtualui_button_settext.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_virtualui_button_settext1 = Text(self.__frame_device_commands_for_virtualui_button,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_button_settext1.grid(column=1,row=3,sticky='w')
        self.__tb_cmd_virtualui_button_settext2 = Text(self.__frame_device_commands_for_virtualui_button,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_button_settext2.grid(column=2,row=3,sticky='w')
        #SetVisible(list[int],bool)
        self.__lbl_device_commands_virtualui_button_setvisible1 = Label(self.__frame_device_commands_for_virtualui_button,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_button_setvisible1.grid(column=1,row=4,sticky='w')
        self.__lbl_device_commands_virtualui_button_setvisible2 = Label(self.__frame_device_commands_for_virtualui_button,text='True or False')
        self.__lbl_device_commands_virtualui_button_setvisible2.grid(column=2,row=4,sticky='w')
        self.__btn_cmd_virtualui_button_setvisible = Button(self.__frame_device_commands_for_virtualui_button,text='SetVisible',width=15,command=self.__cmd_setvisible_selected_device)
        self.__btn_cmd_virtualui_button_setvisible.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_virtualui_button_setvisible1 = Text(self.__frame_device_commands_for_virtualui_button,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_button_setvisible1.grid(column=1,row=5,sticky='w')
        self.__tb_cmd_virtualui_button_setvisible2 = Text(self.__frame_device_commands_for_virtualui_button,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_button_setvisible2.grid(column=2,row=5,sticky='w')
        #SetEnable(list[int],bool)
        self.__lbl_device_commands_virtualui_button_setenable1 = Label(self.__frame_device_commands_for_virtualui_button,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_button_setenable1.grid(column=1,row=6,sticky='w')
        self.__lbl_device_commands_virtualui_button_setenable2 = Label(self.__frame_device_commands_for_virtualui_button,text='True or False')
        self.__lbl_device_commands_virtualui_button_setenable2.grid(column=2,row=6,sticky='w')
        self.__btn_cmd_virtualui_button_setenable = Button(self.__frame_device_commands_for_virtualui_button,text='SetEnable',width=15,command=self.__cmd_setenable_selected_device)
        self.__btn_cmd_virtualui_button_setenable.grid(column=0,row=7,sticky='w')
        self.__tb_cmd_virtualui_button_setenable1 = Text(self.__frame_device_commands_for_virtualui_button,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_button_setenable1.grid(column=1,row=7,sticky='w')
        self.__tb_cmd_virtualui_button_setenable2 = Text(self.__frame_device_commands_for_virtualui_button,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_button_setenable2.grid(column=2,row=7,sticky='w')
        #SetBlinking(list[int],str,list[int])
        self.__lbl_device_commands_virtualui_button_setblinking1 = Label(self.__frame_device_commands_for_virtualui_button,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_button_setblinking1.grid(column=1,row=8,sticky='w')
        self.__lbl_device_commands_virtualui_button_setblinking2 = Label(self.__frame_device_commands_for_virtualui_button,text='Rate(Slow,Medium,Fast)')
        self.__lbl_device_commands_virtualui_button_setblinking2.grid(column=2,row=8,sticky='w')
        self.__lbl_device_commands_virtualui_button_setblinking3 = Label(self.__frame_device_commands_for_virtualui_button,text='States(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_button_setblinking3.grid(column=3,row=8,sticky='w')
        self.__btn_cmd_virtualui_button_setblinking = Button(self.__frame_device_commands_for_virtualui_button,text='SetBlinking',width=15,command=self.__cmd_setblinking_selected_device)
        self.__btn_cmd_virtualui_button_setblinking.grid(column=0,row=9,sticky='w')
        self.__tb_cmd_virtualui_button_setblinking1 = Text(self.__frame_device_commands_for_virtualui_button,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_button_setblinking1.grid(column=1,row=9,sticky='w')
        self.__tb_cmd_virtualui_button_setblinking2 = Text(self.__frame_device_commands_for_virtualui_button,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_button_setblinking2.grid(column=2,row=9,sticky='w')
        self.__tb_cmd_virtualui_button_setblinking3 = Text(self.__frame_device_commands_for_virtualui_button,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_button_setblinking3.grid(column=3,row=9,sticky='w')

        self.__frame_device_commands_for_virtualui_knob = Frame(self.__frame_device_virtualui)
        self.__frame_device_commands_for_virtualui_knob.grid(column=0,row=3,sticky='w')

        self.__frame_device_commands_for_virtualui_label = Frame(self.__frame_device_virtualui)
        self.__frame_device_commands_for_virtualui_label.grid(column=0,row=4,sticky='w')
        #SetText(list[int],str)
        self.__lbl_device_commands_virtualui_label_settext1 = Label(self.__frame_device_commands_for_virtualui_label,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_label_settext1.grid(column=1,row=0,sticky='w')
        self.__lbl_device_commands_virtualui_label_settext2 = Label(self.__frame_device_commands_for_virtualui_label,text='Text')
        self.__lbl_device_commands_virtualui_label_settext2.grid(column=2,row=0,sticky='w')
        self.__btn_cmd_virtualui_label_settext = Button(self.__frame_device_commands_for_virtualui_label,text='SetText',width=15,command=self.__cmd_settext_selected_device)
        self.__btn_cmd_virtualui_label_settext.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_virtualui_label_settext1 = Text(self.__frame_device_commands_for_virtualui_label,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_label_settext1.grid(column=1,row=1,sticky='w')
        self.__tb_cmd_virtualui_label_settext2 = Text(self.__frame_device_commands_for_virtualui_label,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_label_settext2.grid(column=2,row=1,sticky='w')
        #SetVisible(list[int],bool)
        self.__lbl_device_commands_virtualui_label_setvisible1 = Label(self.__frame_device_commands_for_virtualui_label,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_label_setvisible1.grid(column=1,row=2,sticky='w')
        self.__lbl_device_commands_virtualui_label_setvisible2 = Label(self.__frame_device_commands_for_virtualui_label,text='True or False')
        self.__lbl_device_commands_virtualui_label_setvisible2.grid(column=2,row=2,sticky='w')
        self.__btn_cmd_virtualui_label_setvisible = Button(self.__frame_device_commands_for_virtualui_label,text='SetVisible',width=15,command=self.__cmd_setvisible_selected_device)
        self.__btn_cmd_virtualui_label_setvisible.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_virtualui_label_setvisible1 = Text(self.__frame_device_commands_for_virtualui_label,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_label_setvisible1.grid(column=1,row=3,sticky='w')
        self.__tb_cmd_virtualui_label_setvisible2 = Text(self.__frame_device_commands_for_virtualui_label,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_label_setvisible2.grid(column=2,row=3,sticky='w')

        self.__frame_device_commands_for_virtualui_level = Frame(self.__frame_device_virtualui)
        self.__frame_device_commands_for_virtualui_level.grid(column=0,row=4,sticky='w')
        #SetLevel(list[int],bool)
        self.__lbl_device_commands_virtualui_level_setlevel1 = Label(self.__frame_device_commands_for_virtualui_level,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_level_setlevel1.grid(column=1,row=0,sticky='w')
        self.__lbl_device_commands_virtualui_level_setlevel2 = Label(self.__frame_device_commands_for_virtualui_level,text='Value(int)')
        self.__lbl_device_commands_virtualui_level_setlevel2.grid(column=2,row=0,sticky='w')
        self.__btn_cmd_virtualui_level_setlevel = Button(self.__frame_device_commands_for_virtualui_level,text='SetLevel',width=15,command=self.__cmd_setlevel_selected_device)
        self.__btn_cmd_virtualui_level_setlevel.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_virtualui_level_setlevel1 = Text(self.__frame_device_commands_for_virtualui_level,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_level_setlevel1.grid(column=1,row=1,sticky='w')
        self.__tb_cmd_virtualui_level_setlevel2 = Text(self.__frame_device_commands_for_virtualui_level,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_level_setlevel2.grid(column=2,row=1,sticky='w')
        #SetVisible(list[int],bool)
        self.__lbl_device_commands_virtualui_level_setvisible1 = Label(self.__frame_device_commands_for_virtualui_level,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_level_setvisible1.grid(column=1,row=2,sticky='w')
        self.__lbl_device_commands_virtualui_level_setvisible2 = Label(self.__frame_device_commands_for_virtualui_level,text='True or False')
        self.__lbl_device_commands_virtualui_level_setvisible2.grid(column=2,row=2,sticky='w')
        self.__btn_cmd_virtualui_level_setvisible = Button(self.__frame_device_commands_for_virtualui_level,text='SetVisible',width=15,command=self.__cmd_setvisible_selected_device)
        self.__btn_cmd_virtualui_level_setvisible.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_virtualui_level_setvisible1 = Text(self.__frame_device_commands_for_virtualui_level,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_level_setvisible1.grid(column=1,row=3,sticky='w')
        self.__tb_cmd_virtualui_level_setvisible2 = Text(self.__frame_device_commands_for_virtualui_level,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_level_setvisible2.grid(column=2,row=3,sticky='w')
        #SetRange(list[int],int,int,int)
        self.__lbl_device_commands_virtualui_level_setrange1 = Label(self.__frame_device_commands_for_virtualui_level,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_level_setrange1.grid(column=1,row=4,sticky='w')
        self.__lbl_device_commands_virtualui_level_setrange2 = Label(self.__frame_device_commands_for_virtualui_level,text='Min(int)')
        self.__lbl_device_commands_virtualui_level_setrange2.grid(column=2,row=4,sticky='w')
        self.__lbl_device_commands_virtualui_level_setrange3 = Label(self.__frame_device_commands_for_virtualui_level,text='Max(int)')
        self.__lbl_device_commands_virtualui_level_setrange3.grid(column=3,row=4,sticky='w')
        self.__lbl_device_commands_virtualui_level_setrange4 = Label(self.__frame_device_commands_for_virtualui_level,text='Step(int,optional)')
        self.__lbl_device_commands_virtualui_level_setrange4.grid(column=4,row=4,sticky='w')
        self.__btn_cmd_virtualui_level_setrange = Button(self.__frame_device_commands_for_virtualui_level,text='SetRange',width=15,command=self.__cmd_setrange_selected_device)
        self.__btn_cmd_virtualui_level_setrange.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_virtualui_level_setrange1 = Text(self.__frame_device_commands_for_virtualui_level,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_level_setrange1.grid(column=1,row=5,sticky='w')
        self.__tb_cmd_virtualui_level_setrange2 = Text(self.__frame_device_commands_for_virtualui_level,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_level_setrange2.grid(column=2,row=5,sticky='w')
        self.__tb_cmd_virtualui_level_setrange3 = Text(self.__frame_device_commands_for_virtualui_level,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_level_setrange3.grid(column=3,row=5,sticky='w')
        self.__tb_cmd_virtualui_level_setrange4 = Text(self.__frame_device_commands_for_virtualui_level,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_level_setrange4.grid(column=4,row=5,sticky='w')
        #Inc()
        self.__lbl_device_commands_virtualui_level_inc1 = Label(self.__frame_device_commands_for_virtualui_level,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_level_inc1.grid(column=1,row=6,sticky='w')
        self.__btn_cmd_virtualui_level_inc = Button(self.__frame_device_commands_for_virtualui_level,text='Increment',width=15,command=self.__cmd_inc_selected_device)
        self.__btn_cmd_virtualui_level_inc.grid(column=0,row=7,sticky='w')
        self.__tb_cmd_virtualui_level_inc1 = Text(self.__frame_device_commands_for_virtualui_level,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_level_inc1.grid(column=1,row=7,sticky='w')
        #Dec()
        self.__lbl_device_commands_virtualui_level_dec1 = Label(self.__frame_device_commands_for_virtualui_level,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_level_dec1.grid(column=1,row=8,sticky='w')
        self.__btn_cmd_virtualui_level_dec = Button(self.__frame_device_commands_for_virtualui_level,text='Decrement',width=15,command=self.__cmd_dec_selected_device)
        self.__btn_cmd_virtualui_level_dec.grid(column=0,row=9,sticky='w')
        self.__tb_cmd_virtualui_level_dec1 = Text(self.__frame_device_commands_for_virtualui_level,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_level_dec1.grid(column=1,row=9,sticky='w')


        self.__frame_device_commands_for_virtualui_slider = Frame(self.__frame_device_virtualui)
        self.__frame_device_commands_for_virtualui_slider.grid(column=0,row=5,sticky='w')
        #setfill(list[int],bool)
        self.__lbl_device_commands_virtualui_slider_setfill1 = Label(self.__frame_device_commands_for_virtualui_slider,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_slider_setfill1.grid(column=1,row=0,sticky='w')
        self.__lbl_device_commands_virtualui_slider_setfill2 = Label(self.__frame_device_commands_for_virtualui_slider,text='Value(int)')
        self.__lbl_device_commands_virtualui_slider_setfill2.grid(column=2,row=0,sticky='w')
        self.__btn_cmd_virtualui_slider_setfill = Button(self.__frame_device_commands_for_virtualui_slider,text='Setfill',width=15,command=self.__cmd_setfill_selected_device)
        self.__btn_cmd_virtualui_slider_setfill.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_virtualui_slider_setfill1 = Text(self.__frame_device_commands_for_virtualui_slider,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_slider_setfill1.grid(column=1,row=1,sticky='w')
        self.__tb_cmd_virtualui_slider_setfill2 = Text(self.__frame_device_commands_for_virtualui_slider,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_slider_setfill2.grid(column=2,row=1,sticky='w')
        #SetVisible(list[int],bool)
        self.__lbl_device_commands_virtualui_slider_setvisible1 = Label(self.__frame_device_commands_for_virtualui_slider,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_slider_setvisible1.grid(column=1,row=2,sticky='w')
        self.__lbl_device_commands_virtualui_slider_setvisible2 = Label(self.__frame_device_commands_for_virtualui_slider,text='True or False')
        self.__lbl_device_commands_virtualui_slider_setvisible2.grid(column=2,row=2,sticky='w')
        self.__btn_cmd_virtualui_slider_setvisible = Button(self.__frame_device_commands_for_virtualui_slider,text='SetVisible',width=15,command=self.__cmd_setvisible_selected_device)
        self.__btn_cmd_virtualui_slider_setvisible.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_virtualui_slider_setvisible1 = Text(self.__frame_device_commands_for_virtualui_slider,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_slider_setvisible1.grid(column=1,row=3,sticky='w')
        self.__tb_cmd_virtualui_slider_setvisible2 = Text(self.__frame_device_commands_for_virtualui_slider,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_slider_setvisible2.grid(column=2,row=3,sticky='w')
        #SetEnable(list[int],bool)
        self.__lbl_device_commands_virtualui_slider_setenable1 = Label(self.__frame_device_commands_for_virtualui_slider,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_slider_setenable1.grid(column=1,row=4,sticky='w')
        self.__lbl_device_commands_virtualui_slider_setenable2 = Label(self.__frame_device_commands_for_virtualui_slider,text='True or False')
        self.__lbl_device_commands_virtualui_slider_setenable2.grid(column=2,row=4,sticky='w')
        self.__btn_cmd_virtualui_slider_setenable = Button(self.__frame_device_commands_for_virtualui_slider,text='SetEnable',width=15,command=self.__cmd_setenable_selected_device)
        self.__btn_cmd_virtualui_slider_setenable.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_virtualui_slider_setenable1 = Text(self.__frame_device_commands_for_virtualui_slider,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_slider_setenable1.grid(column=1,row=5,sticky='w')
        self.__tb_cmd_virtualui_slider_setenable2 = Text(self.__frame_device_commands_for_virtualui_slider,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_slider_setenable2.grid(column=2,row=5,sticky='w')
        #SetRange(list[int],int,int,int)
        self.__lbl_device_commands_virtualui_slider_setrange1 = Label(self.__frame_device_commands_for_virtualui_slider,text='IDs(comma separated list of ints)')
        self.__lbl_device_commands_virtualui_slider_setrange1.grid(column=1,row=6,sticky='w')
        self.__lbl_device_commands_virtualui_slider_setrange2 = Label(self.__frame_device_commands_for_virtualui_slider,text='Min(int)')
        self.__lbl_device_commands_virtualui_slider_setrange2.grid(column=2,row=6,sticky='w')
        self.__lbl_device_commands_virtualui_slider_setrange3 = Label(self.__frame_device_commands_for_virtualui_slider,text='Max(int)')
        self.__lbl_device_commands_virtualui_slider_setrange3.grid(column=3,row=6,sticky='w')
        self.__lbl_device_commands_virtualui_slider_setrange4 = Label(self.__frame_device_commands_for_virtualui_slider,text='Step(int,optional)')
        self.__lbl_device_commands_virtualui_slider_setrange4.grid(column=4,row=6,sticky='w')
        self.__btn_cmd_virtualui_slider_setrange = Button(self.__frame_device_commands_for_virtualui_slider,text='SetRange',width=15,command=self.__cmd_setrange_selected_device)
        self.__btn_cmd_virtualui_slider_setrange.grid(column=0,row=7,sticky='w')
        self.__tb_cmd_virtualui_slider_setrange1 = Text(self.__frame_device_commands_for_virtualui_slider,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_slider_setrange1.grid(column=1,row=7,sticky='w')
        self.__tb_cmd_virtualui_slider_setrange2 = Text(self.__frame_device_commands_for_virtualui_slider,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_slider_setrange2.grid(column=2,row=7,sticky='w')
        self.__tb_cmd_virtualui_slider_setrange3 = Text(self.__frame_device_commands_for_virtualui_slider,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_slider_setrange3.grid(column=3,row=7,sticky='w')
        self.__tb_cmd_virtualui_slider_setrange4 = Text(self.__frame_device_commands_for_virtualui_slider,height=1,width=20,wrap='none')
        self.__tb_cmd_virtualui_slider_setrange4.grid(column=4,row=7,sticky='w')

        self.__device_commands_frames = {
            'Circuit Breaker':self.__frame_device_commands_for_circuit_breaker,
            'Contact':self.__frame_device_commands_for_contact,
            'Digital Input':self.__frame_device_commands_for_digital_input,
            'Digital IO':self.__frame_device_commands_for_digital_io,
            'Flex IO':self.__frame_device_commands_for_flex_io,
            'IR':self.__frame_device_commands_for_ir,
            'Serial':self.__frame_device_commands_for_modules,
            'SerialOverEthernet':self.__frame_device_commands_for_modules,
            'Ethernet':self.__frame_device_commands_for_modules,
            'SSH':self.__frame_device_commands_for_modules,
            'SPI':self.__frame_device_commands_for_modules,
            'PoE':self.__frame_device_commands_for_poe,
            'Relay':self.__frame_device_commands_for_relay,
            'SW Power':self.__frame_device_commands_for_sw_power,
            'SWAC Receptacle':self.__frame_device_commands_for_swac_receptacle,
            'Tally':self.__frame_device_commands_for_tally,
            'Volume':self.__frame_device_commands_for_volume,
            'Processor':self.__frame_device_commands_for_processor,
            'UI':self.__frame_device_commands_for_ui,
            'VirtualUI':self.__frame_device_virtualui}
        self.__device_virtualui_mode_frames = {
            'Navigation':self.__frame_device_commands_for_virtualui_navigation,
            'Button':self.__frame_device_commands_for_virtualui_button,
            'Knob':self.__frame_device_commands_for_virtualui_knob,
            'Label':self.__frame_device_commands_for_virtualui_label,
            'Level':self.__frame_device_commands_for_virtualui_level,
            'Slider':self.__frame_device_commands_for_virtualui_slider}

        self.__hide_device_commands()
        self.Hide(self.__frame_print_to_trace)
        self.Hide(self.__frame_device_reinit)
        self.Hide(self.__frame_log)
        self.Hide(self.__frame_status)
        self.Hide(self.__frame_controller_clear_logs)
        self.__controller_rxtx_view_enable()
    #class methods

    def __selected_device_changed(self):
        def e(*args):
            selected_device = self.__selected_device.get()

            try:
                print('select device {}'.format(selected_device))
                self.__selected_module = self.__device_list.index(selected_device)
            except:
                self.__selected_module = None
                return
            print('select module {}'.format(self.__selected_module))
            self.__set_device_communication_details(self.__selected_module)
            self.__show_device_log(self.__selected_module)
            self.__show_device_status(self.__selected_module)
            self.__show_device_commands(self.__selected_module)
        return e

    def __cmd_reinitialize_selected_module(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd reinit module{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd = '~Command~:{}:Reinit()'.format(device_id)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_update_selected_module(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd update module{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['command'] = self.__tb_update_command1.get('1.0',END)
            cmd_dict['command'] = cmd_dict['command'].strip()
            cmd_dict['qualifier'] = self.__tb_update_command2.get('1.0',END)
            cmd_dict['qualifier'] = cmd_dict['qualifier'].strip()
            try:
                cmd_dict['qualifier'] = json.loads(cmd_dict['qualifier'])
            except:
                cmd_dict['qualifier'] = None
            if cmd_dict['command'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Update({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_set_selected_module(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd set module{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['command'] = self.__tb_set_command1.get('1.0',END)
            cmd_dict['command'] = cmd_dict['command'].strip()
            cmd_dict['value'] = self.__tb_set_command2.get('1.0',END)
            cmd_dict['value'] = cmd_dict['value'].strip()
            cmd_dict['valuetype'] = self.__sv_commands_module_set_value_type.get()
            cmd_dict['qualifier'] = self.__tb_set_command3.get('1.0',END)
            cmd_dict['qualifier'] = cmd_dict['qualifier'].strip()
            try:
                cmd_dict['qualifier'] = json.loads(cmd_dict['qualifier'])
            except:
                cmd_dict['qualifier'] = None
            if cmd_dict['command'] == '' or cmd_dict['value'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Set({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_writestatus_selected_module(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd writestatus module{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['command'] = self.__tb_writestatus_command1.get('1.0',END)
            cmd_dict['command'] = cmd_dict['command'].strip()
            cmd_dict['value'] = self.__tb_writestatus_command2.get('1.0',END)
            cmd_dict['value'] = cmd_dict['value'].strip()
            cmd_dict['valuetype'] = self.__sv_commands_module_writestatus_value_type.get()
            cmd_dict['qualifier'] = self.__tb_writestatus_command3.get('1.0',END)
            cmd_dict['qualifier'] = cmd_dict['qualifier'].strip()
            try:
                cmd_dict['qualifier'] = json.loads(cmd_dict['qualifier'])
            except:
                cmd_dict['qualifier'] = None
            if cmd_dict['command'] == '' or cmd_dict['value'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:WriteStatus({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_passthrough_selected_module(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd passthrough module{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            txt = self.__tb_passthrough_command.get('1.0',END)
            txt = txt.strip()
            txt = self.__eval_string(txt)
            cmd = '~Command~:{}:passthru("{}")'.format(device_id,txt)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_initialize_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd initialize device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.vars.device_info[device_id]['type']
            tbs = {'Flex IO':[self.__tb_cmd_flex_io_initialize1,self.__tb_cmd_flex_io_initialize2,self.__tb_cmd_flex_io_initialize3,self.__tb_cmd_flex_io_initialize4],
                    'Digital IO':[self.__tb_cmd_digital_io_initialize1,self.__tb_cmd_digital_io_initialize2],
                    'Digital Input':[self.__tb_cmd_digital_input_initialize1],
                    'Digital IO':[self.__tb_cmd_ir_initialize1]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if device_type in ['Digital IO','Flex IO']:
                cmd_dict['value2'] = tbs[device_type][1].get('1.0',END)
                cmd_dict['value2'] = cmd_dict['value2'].strip()
                if device_type == 'Flex IO':
                    cmd_dict['value3'] = tbs[device_type][2].get('1.0',END)
                    cmd_dict['value3'] = cmd_dict['value3'].strip()
                    cmd_dict['value4'] = tbs[device_type][3].get('1.0',END)
                    cmd_dict['value4'] = cmd_dict['value4'].strip()
            for key in cmd_dict:
                if len(cmd_dict[key]) < 1:
                    cmd_dict[key] = None
                elif cmd_dict[key] == 'True':
                    cmd_dict[key] = True
                elif cmd_dict[key] == 'False':
                    cmd_dict[key] = False
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Initialize({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_pulse_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd pulse device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.vars.device_info[device_id]['type']
            tbs = {'Relay':[self.__tb_cmd_relay_pulse1],
                    'Tally':[self.__tb_cmd_tally_pulse1],
                    'Flex IO':[self.__tb_cmd_flex_io_pulse1],
                    'SW Power':[self.__tb_cmd_sw_power_pulse1],
                    'Digital IO':[self.__tb_cmd_digital_io_pulse1]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Pulse({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_state_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd state device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.vars.device_info[device_id]['type']
            tbs = {'PoE':[self.__tb_cmd_poe_state1],
                    'Relay':[self.__tb_cmd_relay_state1],
                    'Tally':[self.__tb_cmd_tally_state1],
                    'Flex IO':[self.__tb_cmd_flex_io_state1],
                    'SW Power':[self.__tb_cmd_sw_power_state1],
                    'Digital IO':[self.__tb_cmd_digital_io_state1],
                    'SWAC Receptacle':[self.__tb_cmd_swac_receptacle_state1]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:State({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_toggle_selected_device(self):
        device_id = self.__get_device_log_id(self.__selected_module)
        print('cmd Toggle device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
        cmd = '~Command~:{}:Toggle()'.format(device_id)
        self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_level_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd Level device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_volume_level1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Level({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_mute_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd Mute device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_volume_mute1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Mute({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_range_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd Range device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_volume_range1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = self.__tb_cmd_volume_range2.get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Range({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_softstart_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd SoftStart device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_volume_softstart1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['command'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:SoftStart({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_playcontinuous_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd PlayContinuous device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_ir_playcontinuous1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:PlayContinuous({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_playcount_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd PlayCount device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_ir_playcount1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = self.__tb_cmd_ir_playcount1.get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2']:
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:PlayCount({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_playtime_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd PlayTime device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_ir_playtime1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = self.__tb_cmd_ir_playtime2.get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2']:
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:PlayTime({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_stop_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd Stop device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd = '~Command~:{}:Stop()'.format(device_id)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_reboot_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd reboot device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd = '~Command~:{}:Reboot()'.format(device_id)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_savepgmlog_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd saveprogramlog device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd = '~Command~:{}:SaveProgramLog()'.format(device_id)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_executivemode_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd executivemode device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_processor_executivemode1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:ExecutiveMode({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_showpage_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd showpage device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.vars.device_info[device_id]['type']
            tbs = {'UI':[self.__tb_cmd_ui_showpage1],
                    'VirtualUI':[self.__tb_cmd_virtualui_showpage1]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:ShowPage({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_showpopup_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd showpopup device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.vars.device_info[device_id]['type']
            tbs = {'UI':[self.__tb_cmd_ui_showpopup1,self.__tb_cmd_ui_showpopup2],
                    'VirtualUI':[self.__tb_cmd_virtualui_showpopup1,self.__tb_cmd_virtualui_showpopup2]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = tbs[device_type][1].get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '':
                return
            if cmd_dict['value2'] == '':
                cmd_dict['value2'] = '0'
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:ShowPopup({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_hidepopup_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd hidepopup device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.vars.device_info[device_id]['type']
            tbs = {'UI':[self.__tb_cmd_ui_hidepopup1],
                    'VirtualUI':[self.__tb_cmd_virtualui_hidepopup1]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:HidePopup({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_hidepopupgroup_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd hidepopupgroup device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.vars.device_info[device_id]['type']
            tbs = {'UI':[self.__tb_cmd_ui_hidepopupgroup1],
                    'VirtualUI':[self.__tb_cmd_virtualui_hidepopupgroup1]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:HidePopupGroup({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_hideallpopups_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd hideallpopups device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd = '~Command~:{}:HideAllPopups()'.format(device_id)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_wake_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd wake device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd = '~Command~:{}:Wake()'.format(device_id)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_sleep_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd sleep device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd = '~Command~:{}:Sleep()'.format(device_id)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_setstate_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd setstate device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.__selected_virtualui_mode
            tbs = {'Button':[self.__tb_cmd_virtualui_button_setstate1,self.__tb_cmd_virtualui_button_setstate2]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = tbs[device_type][1].get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2'] == '':
                return
            cmd_dict['value1'] = cmd_dict['value1'].split(',')
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:SetState({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_settext_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd settext device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.__selected_virtualui_mode
            tbs = {'Button':[self.__tb_cmd_virtualui_button_settext1,self.__tb_cmd_virtualui_button_settext2],
                    'Label':[self.__tb_cmd_virtualui_label_settext1,self.__tb_cmd_virtualui_label_settext2]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = tbs[device_type][1].get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict['value1'] = cmd_dict['value1'].split(',')
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:SetText({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_setblinking_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd setblinking device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.__selected_virtualui_mode
            tbs = {'Button':[self.__tb_cmd_virtualui_button_setblinking1,self.__tb_cmd_virtualui_button_setblinking2,self.__tb_cmd_virtualui_button_setblinking3]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = tbs[device_type][1].get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            cmd_dict['value3'] = tbs[device_type][2].get('1.0',END)
            cmd_dict['value3'] = cmd_dict['value3'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2'] == '' or cmd_dict['value3'] == '':
                return
            cmd_dict['value1'] = cmd_dict['value1'].split(',')
            cmd_dict['value3'] = cmd_dict['value3'].split(',')
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:SetBlinking({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_setlevel_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd setlevel device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.__selected_virtualui_mode
            tbs = {'Level':[self.__tb_cmd_virtualui_level_setlevel1,self.__tb_cmd_virtualui_level_setlevel2]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = tbs[device_type][1].get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2'] == '':
                return
            cmd_dict['value1'] = cmd_dict['value1'].split(',')
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:SetLevel({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_setfill_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd setfill device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.__selected_virtualui_mode
            tbs = {'Slider':[self.__tb_cmd_virtualui_slider_setfill1,self.__tb_cmd_virtualui_slider_setfill2]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = tbs[device_type][1].get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2'] == '':
                return
            cmd_dict['value1'] = cmd_dict['value1'].split(',')
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:SetFill({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_setenable_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd setenable device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.__selected_virtualui_mode
            tbs = {'Button':[self.__tb_cmd_virtualui_button_setenable1,self.__tb_cmd_virtualui_button_setenable2],
                'Slider':[self.__tb_cmd_virtualui_slider_setenable1,self.__tb_cmd_virtualui_slider_setenable2]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = tbs[device_type][1].get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2'] not in ['True','False']:
                return
            cmd_dict['value1'] = cmd_dict['value1'].split(',')
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:SetEnable({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_setvisible_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd setvisible device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.__selected_virtualui_mode
            tbs = {'Button':[self.__tb_cmd_virtualui_button_setvisible1,self.__tb_cmd_virtualui_button_setvisible2],
                'Label':[self.__tb_cmd_virtualui_label_setvisible1,self.__tb_cmd_virtualui_label_setvisible2],
                'Level':[self.__tb_cmd_virtualui_level_setvisible1,self.__tb_cmd_virtualui_level_setvisible2],
                'Slider':[self.__tb_cmd_virtualui_slider_setvisible1,self.__tb_cmd_virtualui_slider_setvisible2]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = tbs[device_type][1].get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2'] not in ['True','False']:
                return
            cmd_dict['value1'] = cmd_dict['value1'].split(',')
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:SetVisible({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_setrange_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd setrange device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.__selected_virtualui_mode
            tbs = {'Level':[self.__tb_cmd_virtualui_level_setrange1,self.__tb_cmd_virtualui_level_setrange2,self.__tb_cmd_virtualui_level_setrange3,self.__tb_cmd_virtualui_level_setrange4],
                'Slider':[self.__tb_cmd_virtualui_slider_setrange1,self.__tb_cmd_virtualui_slider_setrange2,self.__tb_cmd_virtualui_slider_setrange3,self.__tb_cmd_virtualui_slider_setrange4]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = tbs[device_type][1].get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            cmd_dict['value3'] = tbs[device_type][2].get('1.0',END)
            cmd_dict['value3'] = cmd_dict['value3'].strip()
            cmd_dict['value4'] = tbs[device_type][3].get('1.0',END)
            cmd_dict['value4'] = cmd_dict['value4'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2'] == '' or cmd_dict['value3'] == '':
                return
            if cmd_dict['value4'] == '':
                cmd_dict['value4'] = '1'
            cmd_dict['value1'] = cmd_dict['value1'].split(',')
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:SetRange({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_inc_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd inc device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.__selected_virtualui_mode
            tbs = {'Level':[self.__tb_cmd_virtualui_level_inc1]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict['value1'] = cmd_dict['value1'].split(',')
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Inc({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_dec_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd dec device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.__selected_virtualui_mode
            tbs = {'Level':[self.__tb_cmd_virtualui_level_inc1]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict['value1'] = cmd_dict['value1'].split(',')
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Dec({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)

    def __set_device_virtualui_mode(self,mode):
        def f():
            self.__selected_virtualui_mode = mode
            for frame in self.__device_virtualui_mode_frames:
                self.Hide(self.__device_virtualui_mode_frames[frame])
            self.Show(self.__device_virtualui_mode_frames[mode])
        return f

    def __eval_string(self,text:'str'):
        text.replace('\\r','\\x0d')
        text.replace('\\n','\\x0a')
        while '\\x' in text:
            pos = text.find('\\x')
            temp = text[pos:pos+4]
            val = int(temp[2:],16)
            char = chr(val)
            text = text.replace(temp,char)
        return text
    def __get_device_log_id(self,pos):
        device_id = None
        pos = int(pos)
        key_list = []
        for cur in self.vars.device_info:
            key_list.append(int(cur))
        key_list.sort()
        if len(key_list) > pos:
            device_id = key_list[pos]
        return str(device_id)
    def __get_device_log_pos(self,device_id):
        key_list = list(self.vars.device_info.keys())
        key_list.sort()
        pos = None
        if device_id in key_list:
            pos = str(key_list.index(device_id))
        return pos
    def __show_device_log(self,pos):
        device_id = self.__get_device_log_id(pos)
        self.__current_tb_log = ''
        if device_id in self.__device_logs.keys():
            for log in self.__device_logs[device_id]:
                self.__current_tb_log += self.__set_device_log_hex_format(log)+'\n'
        self.__tb_log.delete('1.0','end')
        self.__tb_log.insert(END,self.__current_tb_log)
        self.__tb_log.update()
    def __show_device_status(self,pos):
        device_id = self.__get_device_log_id(pos)
        txt = ''
        if device_id in self.vars.device_info:
            txt = json.dumps(self.vars.device_info[device_id]['status'],sort_keys=True,indent=2)
        posy = self.__scrollb_statusy.get()
        self.__tb_status.delete('1.0','end')
        self.__tb_status.insert(END,txt)
        self.__tb_status.yview_moveto(posy[0])
        self.__tb_status.update()

    def __hide_device_commands(self):
        for f in self.__device_commands_frames:
            self.Hide(self.__device_commands_frames[f])
        for f in self.__device_virtualui_mode_frames:
            self.Hide(self.__device_virtualui_mode_frames[f])
    def __show_device_commands(self,pos):
        device_id = self.__get_device_log_id(pos)
        device_type = None
        self.__hide_device_commands()
        if device_id in self.vars.device_info:
            device_type = self.vars.device_info[device_id]['type']
        if device_type in self.__device_commands_frames:
            self.Show(self.__device_commands_frames[device_type])

    def __cmd_device_print_to_trace(self):
        def e():
            if self.__selected_module is None:
                return
            device_id = self.__get_device_log_id(self.__selected_module)
            val = self.__var_device_print_to_trace.get()
            cmd_dict = {'option':'print to trace'}
            if val == 1:
                cmd_dict['value'] = True
            else:
                cmd_dict['value'] = False
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Option~:{}:Option({})'.format(device_id,cmd_dict_str)
            print('checked:{}'.format(cmd))
            self.vars.processor_communication.SendToSystem(cmd)
        return e

    def __toggle_tb_timestamp(self):
        self.__timestamp_newest_first = not self.__timestamp_newest_first

        vals = {True:'Newest',False:'Oldest'}
        self.__btn_tb_sort_timestamp['text'] = 'Timestamp:{}'.format(vals[self.__timestamp_newest_first])
        print('sort the log:{}'.format(self.__timestamp_newest_first))
        for key in self.__device_logs:
            self.__device_logs[key].sort(reverse=self.__timestamp_newest_first)
        self.__show_device_log(self.__selected_module)

    def __clear_device_communication_details(self):
        self.__lbl_selected_device_name.config(text= ' Selected: None')
        self.__lbl_device_comm_detail1.config(text= ' ')
        self.__lbl_device_comm_detail2.config(text= ' ')
        self.__lbl_device_comm_detail3.config(text= ' ')
        self.__lbl_device_comm_detail4.config(text= ' ')
        self.__lbl_device_comm_detail5.config(text= ' ')
        self.__lbl_device_comm_detail6.config(text= ' ')
        self.__lbl_device_comm_detail7.config(text= ' ')
    def __set_device_communication_details(self,pos):
        self.__clear_device_communication_details()
        device_id = self.__get_device_log_id(pos)
        self.__lbl_selected_device_name.config(text= ' Selected: {} '.format(self.vars.device_info[device_id]['name']))
        self.Show(self.__frame_print_to_trace)
        if self.vars.device_info[device_id]['options']['print to trace']:
            self.__var_device_print_to_trace.set(1)
        else:
            self.__var_device_print_to_trace.set(0)
        if 'communication' in self.vars.device_info[device_id]:
            self.Hide(self.__frame_device_reinit)
            conn_details = self.vars.device_info[device_id]['communication']
            dtype = conn_details['type']
            self.__lbl_device_comm_detail1.config(text= ' Type: {} '.format(conn_details['type']))
            if dtype not in ['Processor','UI','VirtualUI']:
                self.__lbl_device_comm_detail2.config(text= ' Host: {} '.format(conn_details['host']))
            if dtype in ['Processor','UI']:
                self.__lbl_device_comm_detail2.config(text= ' Alias: {} '.format(conn_details['alias']))
            if dtype == 'SPI':
                pass
            if dtype == 'Serial':
                self.Show(self.__frame_device_reinit)
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Mode: {} '.format(conn_details['mode']))
                self.__lbl_device_comm_detail5.config(text= ' Baud: {} '.format(conn_details['baud']))
            elif dtype == 'Ethernet' or dtype == 'SerialOverEthernet':
                self.Show(self.__frame_device_reinit)
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Mode: {} '.format(conn_details['mode']))
                if conn_details['mode'] == 'UDP':
                    self.__lbl_device_comm_detail5.config(text= ' Service Port: {} '.format(conn_details['serviceport']))
            elif dtype == 'SSH':
                self.Show(self.__frame_device_reinit)
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Mode: {} '.format(conn_details['mode']))
                self.__lbl_device_comm_detail5.config(text= ' Credentials: {} '.format(conn_details['credentials']))
            elif dtype == 'Circuit Breaker':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'Contact':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'Digital Input':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Pullup: {} '.format(conn_details['pullup']))
            elif dtype == 'Digital IO':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Mode: {} '.format(conn_details['mode']))
                self.__lbl_device_comm_detail5.config(text= ' Pullup: {} '.format(conn_details['pullup']))
            elif dtype == 'Flex IO':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Mode: {} '.format(conn_details['mode']))
                self.__lbl_device_comm_detail5.config(text= ' Pullup: {} '.format(conn_details['pullup']))
                self.__lbl_device_comm_detail6.config(text= ' Upper: {} '.format(conn_details['upper']))
                self.__lbl_device_comm_detail7.config(text= ' Lower: {} '.format(conn_details['lower']))
            elif dtype == 'IR':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' File: {} '.format(conn_details['file']))
            elif dtype == 'Relay':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'SWAC Receptacle':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'SW Power':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'Tally':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'Volume':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'Processor':
                pass
            elif dtype == 'UI':
                pass
            elif dtype == 'VirtualUI':
                pass

    def __clear_current_device_log(self):
        print('clear current device log')
        device_id = self.__get_device_log_id(self.__selected_module)
        self.__device_logs[device_id] = []
        self.__show_device_log(self.__selected_module)

    def __clear_all_device_logs(self):
        print('clear all device logs')
        for selected_module in range(len(self.__device_list)):
            device_id = self.__get_device_log_id(selected_module)
            self.__device_logs[device_id] = []
            self.__show_device_log(0)

    def __pause_current_device_log(self):
        self.__tb_pause_flag = not self.__tb_pause_flag
        if self.__tb_pause_flag:
            self.__btn_tb_pause_log['text'] = 'Resume Log'
            self.__btn_tb_pause_log['bg'] = 'sky blue'
        else:
            self.__btn_tb_pause_log['text'] = 'Pause Log'
            self.__btn_tb_pause_log['bg'] = '#f0f0f0'
            if self.__selected_module != None:
                self.__show_device_log(self.__selected_module)

    def __format_device_log(self):
        self.__tb_hex_flag = not self.__tb_hex_flag
        if self.__tb_hex_flag:
            self.__btn_tb_hex_format['bg'] = 'sky blue'
        else:
            self.__btn_tb_hex_format['bg'] = '#f0f0f0'
        if self.__selected_module != None:
            self.__show_device_log(self.__selected_module)

    def __format_new_log(self,log:'str'):
        log = log.replace('\\\\','\\')
        log = log.replace("-'<<",'-<<')
        log = log.replace("-'>>",'->>')
        if log[-2:] == '\'"':
            log = log[:-2]
        elif log[-1:] == '\'':
            log = log[:-1]
        return log
    def __set_device_log_hex_format(self,log:'str'):
        if self.__tb_hex_flag:
            log = log.replace('\\r','\x0d')
            log = log.replace('\\n','\x0a')
            matches = re.findall('\\\\x(..)',log)
            for match in matches:
                match_str = '0x{}'.format(match.upper())
                an_integer = int(match_str,16)
                log = log.replace('\\x{}'.format(match),chr(an_integer))
            temp = '\\x'
            if '>>' in log:
                parts = log.split(">>")
                temp += "\x5Cx".join("{:02x}".format(ord(c)) for c in parts[1])
                return('{}>>{}'.format(parts[0],temp))
            elif '<<' in log:
                parts = log.split("<<")
                temp += "\x5Cx".join("{:02x}".format(ord(c)) for c in parts[1])
                return('{}<<{}'.format(parts[0],temp))
            else:
                return(log)
        return(log)

    def __controller_rxtx_view_enable(self):
        self.__current_device_view = 0
        self.Hide(self.__frame_status)
        self.Show(self.__frame_log)
        self.Show(self.__frame_controller_clear_logs)
        self.__btn_tb_view_status_view['bg'] = '#f0f0f0'
        self.__btn_tb_view_rxtx_view['bg'] = 'sky blue'
    def __controller_status_view_enable(self):
        self.__current_device_view = 1
        self.Hide(self.__frame_log)
        self.Show(self.__frame_status)
        self.Hide(self.__frame_controller_clear_logs)
        self.__btn_tb_view_rxtx_view['bg'] = '#f0f0f0'
        self.__btn_tb_view_status_view['bg'] = 'sky blue'


    #public functions
    def SetDeviceInfo(self,device_info):
        self.vars.device_info.update(device_info)
    def UpdateDeviceLog(self,device:'str',data:'str'):
        data = self.__format_new_log(data)
        if device not in self.__device_logs.keys():
            self.__device_logs[device] = []
        if self.__timestamp_newest_first:
            self.__device_logs[device].insert(0,data)
        else:
            self.__device_logs[device].append(data)
        pos = self.__get_device_log_pos(device)
        if pos and not self.__tb_pause_flag:
            if pos == str(self.__selected_module):
                self.__show_device_log(pos)
    def UpdateDeviceInfo(self,key,update_is_online=False):
        id = self.__get_device_log_pos(key)
        if id == str(self.__selected_module):
            self.__show_device_status(id)
        if update_is_online and self.__device_color_wait:
            self.__device_color_wait.Restart()
    def UpdateDeviceOption(self,key,option,value):
        id = self.__get_device_log_pos(key)
        self.vars.device_info[key]['options'][option] = value


    def SetDeviceList(self):
        self.__clear_device_communication_details()
        self.__hide_device_commands()
        self.Hide(self.__frame_print_to_trace)
        self.__tb_log.delete('1.0','end')
        self.__tb_status.delete('1.0','end')
        self.__selected_module = None
        menu = self.__om_devices.children['menu']
        menu.delete(0,END)
        self.__device_list = []
        self.__selected_device.set('Select Device')
        key_list = list(self.vars.device_info.keys()) #type:list
        for i in key_list:
            key_list[key_list.index(i)] = int(i)
        key_list.sort()
        self.__device_list = []
        for i in key_list:
            value = self.vars.device_info[str(i)]['name']
            self.__device_list.append(value)
            menu.add_command(label=value, command=lambda v=value: self.__selected_device.set(v))
        self.__set_device_list_colors()
        self.__clear_all_device_logs()
    def __set_device_list_colors(self):
        def w():
            if self.__device_color_wait_busy:
                return
            self.__device_color_wait_busy = True
            key_list = list(self.vars.device_info.keys()) #type:list
            for key in key_list:
                i = self.__get_device_log_pos(key)
                color = 'blue'
                device_id=self.__get_device_log_id(i)
                status = self.vars.device_info[device_id]['status']
                print('device{} actualname:{} status {}'.format(i,self.vars.device_info[device_id]['name'],status))
                if 'ConnectionStatus' in status:
                    connectionstatus = status['ConnectionStatus']['Status']
                    if 'Live' in connectionstatus:
                        if connectionstatus['Live'] == 'Connected':
                            color = 'green'
                        if connectionstatus['Live'] == 'Not Connected':
                            color = 'red'
                        if connectionstatus['Live'] == 'Disconnected':
                            color = 'red'
                elif 'OnlineStatus' in status:
                    onlinestatus = status['OnlineStatus']['Status']
                    if 'Live' in onlinestatus:
                        if onlinestatus['Live'] == 'Online':
                            color = 'green'
                        if onlinestatus['Live'] == 'Offline':
                            color = 'red'
                print('device{} actualname:{} set to color {}'.format(i,self.vars.device_info[device_id]['name'],color))
                menu = self.__om_devices.children['menu']
                menu.entryconfig(i,foreground=color)
            self.__device_color_wait_busy = False
        if self.__device_color_wait is None:
            self.__device_color_wait = Wait(5,w)
        self.__device_color_wait.Restart()
    def SetConnectStatus(self,txt):
        self.__lbl_controller_status['text'] = 'Status : {} {}'.format(self.vars.ip_address,txt)
    def Hide(self,frame=None):
        if frame:
            frame._grid_info = frame.grid_info()
            frame.grid_remove()
        else:
            self.__frame._grid_info = self.__frame.grid_info()
            self.__frame.grid_remove()
    def Show(self,frame=None):
        if frame:
            frame.grid(**frame._grid_info)
        else:
            self.__frame.grid(**self.__frame._grid_info)

    def GetAllLogs(self):
        all_logs = []
        for device_key in self.__device_logs:
            device_name = self.vars.device_info[device_key]['name']
            cur_logs = copy.copy(self.__device_logs[device_key]) #type:list[str]
            for cur_log in cur_logs:
                index = cur_logs.index(cur_log)
                if '>>' in cur_log:
                    cur_logs[index] = cur_logs[index].replace('>>','{} >>'.format(device_name))
                if '<<' in cur_log:
                    cur_logs[index] = cur_logs[index].replace('<<','{} <<'.format(device_name))
            all_logs.extend(cur_logs)
        all_logs.sort()
        all_logs_txt = '\r\n'.join(all_logs)
        return all_logs_txt
    def GetAllStatus(self):
        all_status = []
        for device_key in self.vars.device_info:
            device_name = self.vars.device_info[device_key]['name']
            cur_status = self.vars.device_info[device_key]['status']
            cur_status_txt = '{}\r\n{}'.format(device_name,pprint.pformat(cur_status,indent=5))
            all_status.append(cur_status_txt)
        all_status_txt = '\r\n\r\n'.join(all_status)
        return all_status_txt

    def GetCurrentLog(self):
        if self.__selected_module:
            all_logs = []
            device_key = self.__get_device_log_id(self.__selected_module)
            if device_key in self.__device_logs:
                device_name = self.vars.device_info[device_key]['name']
                cur_logs = copy.copy(self.__device_logs[device_key]) #type:list[str]
                for cur_log in cur_logs:
                    index = cur_logs.index(cur_log)
                    if '>>' in cur_log:
                        cur_logs[index] = cur_logs[index].replace('>>','{} >>'.format(device_name))
                    if '<<' in cur_log:
                        cur_logs[index] = cur_logs[index].replace('<<','{} <<'.format(device_name))
                all_logs.extend(cur_logs)
            all_logs.sort()
            all_logs_txt = '\r\n'.join(all_logs)
            return all_logs_txt
    def GetCurrentStatus(self):
        if self.__selected_module:
            all_status = []
            device_key = self.__get_device_log_id(self.__selected_module)
            if device_key in self.__device_logs:
                device_name = self.vars.device_info[device_key]['name']
                cur_status = self.vars.device_info[device_key]['status']
                cur_status_txt = '{}\r\n{}'.format(device_name,pprint.pformat(cur_status,indent=5))
                all_status.append(cur_status_txt)
            all_status_txt = '\r\n\r\n'.join(all_status)
            return all_status_txt
