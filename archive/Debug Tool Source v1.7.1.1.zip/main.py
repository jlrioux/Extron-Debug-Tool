'''
Version: 1.0

Created By: Jean-Luc Rioux

Last Modified: 2024-04-13

Description: Provides debugging solutions to Extron control system programs that have implemented the InterfaceWrapper class located in tools.py

Changelog:
    https://docs.google.com/spreadsheets/d/1v7Mcngqx15kRCHPC9GCGSz0uw6Fbn0OK-kflxdNUjv4/edit#gid=0


'''





import os
from tkinter import *
from tkinter import messagebox
from ProgramDebugger import ProgramDebuggerClass
from ProgramLogger import ProgramLoggerClass
from variables import variablesclass

vars = variablesclass()

def on_closing():
    if messagebox.askokcancel("Quit", "Do you want to quit?"):
        if vars.ui_view1.processor_communication:
            vars.ui_view1.processor_communication.EndConnections()
        window.destroy()
        os._exit(1)


def show_view(view_num:'int'):
    def f():
        alt_view_num_dict = {1:0,0:1}
        alt_view_num = alt_view_num_dict[view_num]
        try:
            i = 0
            for ui in vars.ui_views:
                ui.HideUIView()
                i+=1
            window.config(menu=menus[view_num])
            vars.ui_views[view_num].ShowUIView()
        except:
            i = 0
            for ui in vars.ui_views:
                ui.HideUIView()
                i+=1
            window.config(menu=menus[alt_view_num])
            vars.ui_views[alt_view_num].ShowUIView()

            i = 0
            for ui in vars.ui_views:
                ui.HideUIView()
                i+=1
            window.config(menu=menus[view_num])
            vars.ui_views[view_num].ShowUIView()
    return f


window = Tk()
window.title(' Global Scripter Debugger ')
window.geometry('1024x600')
window.rowconfigure(0,weight=1)
window.columnconfigure(0,weight=1)

mainframe = Frame(window,pady=0,padx=0)
mainframe.grid(column=0,row=0,sticky='news')
mainframe.rowconfigure(0,weight=1)
mainframe.columnconfigure(0,weight=1)

frame_view1 = Frame(mainframe,pady=5,padx=5)
frame_view1.grid(column=0,row=0,sticky='news')
frame_view2 = Frame(mainframe,pady=5,padx=5)
frame_view2.grid(column=0,row=0,sticky='news')

vars.ui_view1 = ProgramDebuggerClass(frame_view1,vars)
vars.ui_view2 = ProgramLoggerClass(frame_view2,vars)
vars.ui_views = [vars.ui_view1,vars.ui_view2]

if True:
    debugmenubar = Menu(frame_view1, background='#ff8000', foreground='black', activebackground='white', activeforeground='black')
    debugfile = Menu(debugmenubar, tearoff=0, background='#ffcc99', foreground='black')
    debugfile.add_command(label="Connect", command=vars.ui_view1.open_connect_window)
    debugfile.add_command(label="Disconnect", command=vars.ui_view1.disconnect_from_system)
    debugfile.add_command(label="Exit", command=on_closing)
    debugsave = Menu(debugmenubar, tearoff=0, background='#ffcc99', foreground='black')
    debugsave.add_command(label="Save Selected Logs", command=vars.ui_view1.save_current_log)
    debugsave.add_command(label="Save Selected Status", command=vars.ui_view1.save_current_status)
    debugsave.add_command(label="Save All Logs", command=vars.ui_view1.save_all_logs)
    debugsave.add_command(label="Save All Status", command=vars.ui_view1.save_all_status)
    debugview = Menu(debugmenubar, tearoff=0, background='#ffcc99', foreground='black')
    debugview.add_command(label="Processor Debug Log", command=show_view(1))
    debugmenubar.add_cascade(label="File", menu=debugfile)
    debugmenubar.add_cascade(label="Save", menu=debugsave)
    debugmenubar.add_cascade(label="View", menu=debugview)

    pgmlogmenubar = Menu(frame_view2, background='#ff8000', foreground='black', activebackground='white', activeforeground='black')
    pgmlogfile = Menu(pgmlogmenubar, tearoff=0, background='#ffcc99', foreground='black')
    pgmlogfile.add_command(label="Exit", command=on_closing)
    pgmlogsave = Menu(pgmlogmenubar, tearoff=0, background='#ffcc99', foreground='black')
    pgmlogsave.add_command(label="Save Selected Logs", command=vars.ui_view2.save_selected_logs)
    pgmlogsave.add_command(label="Save All Logs", command=vars.ui_view2.save_all_logs)
    pgmlogview = Menu(debugmenubar, tearoff=0, background='#ffcc99', foreground='black')
    pgmlogview.add_command(label="Live Debug Log", command=show_view(0))
    pgmlogmenubar.add_cascade(label="File", menu=pgmlogfile)
    pgmlogmenubar.add_cascade(label="Save", menu=pgmlogsave)
    pgmlogmenubar.add_cascade(label="View", menu=pgmlogview)


menus = [debugmenubar,pgmlogmenubar]
window.config(menu=debugmenubar)

for widget in window.winfo_children():
    try:
        widget.pack(fill='both',expand=1)
    except Exception as e:
        print('error resizing for {}:{}'.format(str(widget),e))

window.protocol("WM_DELETE_WINDOW", on_closing)

window.mainloop()