'''
Version: 1.0

Created By: Jean-Luc Rioux

Last Modified: 2022-01-11

Description: Provides debugging solutions to Extron control system programs that have implemented the InterfaceWrapper class located in tools.py

Changelog:
    - 2022/01/11 - initial release 1.0




'''






from tkinter import *
from UI_EthernetAndSerialDevices import EthernetAndSerialDevices
from ProcessorCommunication import ProcessorCommunicationClass
from variables import variablesclass
from Timer import Timer
from EthernetClientInterface import EthernetClientInterface

vars = variablesclass()
vars.processor_communication = ProcessorCommunicationClass(vars)

def open_connect_window():
    window2 = Tk()
    window2.title(' Connect To System ')
    window2.geometry('250x75')

    lbl_instructions = Label(window2,text = ' Enter the IP address of the Extron Controller:  ')
    lbl_instructions.grid(column=0,row=0)

    def clear_tb_ip():
        vars.ip_address = tb_ip.get(1.0,'end')
        vars.ip_address = vars.ip_address.strip()
        print('recieved ip address of controller:{}'.format(vars.ip_address))
        window2.destroy()
        vars.processor_communication.system_connection_start()
    def clear_tb_enter(event):
        clear_tb_ip()
    tb_ip = Text(window2,height=1,width=20)
    tb_ip.grid(column=0,row=2)
    tb_ip.bind('<Return>',clear_tb_enter)
    tb_ip.insert(END,vars.ip_address)
    tb_ip.update()
    btn_submit = Button(window2,text='Submit',width=10,height=1,command=clear_tb_ip)
    btn_submit.grid(column=0,row=4)
    #apply focus
    window2.wm_deiconify()
    tb_ip.focus_set()


def show_view(btn_num:'int'):
    def f():
        for ui in vars.ui_views:
            ui.Hide()
        vars.ui_views[btn_num].Show()
    return f


window = Tk()
window.title(' Global Scripter Debugger ')
window.geometry('800x600')

menubar = Menu(window, background='#ff8000', foreground='black', activebackground='white', activeforeground='black')
file = Menu(menubar, tearoff=0, background='#ffcc99', foreground='black')
file.add_command(label="Connect", command=open_connect_window)
file.add_command(label="Exit", command=window.quit)
menubar.add_cascade(label="File", menu=file)



#frame_views = Frame(window)
#frame_views.grid(column=0,row=1,sticky='ew')
#btn_view1 = Button(frame_views,text='Ethernet and Serial Devices',width=20,height = 1,command=show_view(0))
#btn_view1.grid(column=0,row=0)
#btn_view2 = Button(frame_views,text='Touch Panels',width=20,height = 1,command=show_view(1))
#btn_view2.grid(column=1,row=0)
#btn_views=[btn_view1,btn_view2]


frame_view1 = Frame(window,pady=5,padx=10)
frame_view1.grid(column=0,row=2,sticky='nw')
frame_view2 = Frame(window,pady=5,padx=10)
#frame_view2.grid(column=0,row=2,sticky='nw')
#frame_views = [frame_view1,frame_view2]

vars.ui_view1 = EthernetAndSerialDevices(frame_view1,vars)
#ui_view1.Hide()

#ui_view2 = TouchPanelDevices(frame_view2)
#ui_view2.Hide()

vars.ui_views = [vars.ui_view1]#,ui_view2]


window.config(menu=menubar)




























window.mainloop()