## Begin ControlScript Import --------------------------------------------------
from extronlib import event
from extronlib.device import UIDevice
from extronlib.interface import EthernetServerInterfaceEx,SerialInterface, EthernetClientInterface, SPInterface
from extronlib.ui import Button, Knob, Label, Level, Slider
from extronlib.system import Timer, Wait, File, SaveProgramLog
from datetime import datetime

import json

"""
Author: Jean-Luc Rioux
Company: Valley Communications
Date: 2022-01-14
Version: 1.1

Changelog:
    v 1.0 - initial release
    v 1.1 - InterfaceWrapper : added support for SPIInterface

































This class creates a listening server to assist in debugging communication.
This module supports MULTIPLE receivedata functions.
This can be useful if you wish to parse feedback outside the module.
It also automatically impliments the subscribe helper class.
For Ethernet, SSH, and Serial Over Ethernet connections, this class automatically maintains the connection for you.
reattempting every 10 seconds.


INSTRUCTIONS on integrating with an Extron authored module, top-down:
1.  No modifications to Extron's device module.
2.  Implement the module as below:
    from tools import InterfaceWrapper
    InterfaceWrapper.EnableDebugServer('LAN') # include this line to enable collective debugging on a single port. options 'LAN','AVLAN'
    from opto_vp_UHD60_v1_0_1_0 import DeviceClass as projector_mod
    dev_projector = InterfaceWrapper(projector_mod,listening_port=2001,friendly_name='Projector')
    dev_projector.Create_Ethernet_Device('10.0.0.87',2023,Model='UHD60')
3.  Implement control and feedback normally.
4.  Call Connect() for network devices to begin the connection handling or to connect to the device.
    Do this after subscribing to feedback for the device.

NOTES:
 - The listening_port must be unique for each device implemented this way.
 - In constructor, set auto_maintain_connection to False if you wish to handle network connections yourself.
 - In constructor, set time_between_commands to an integer > 0 to force command pacing to prevent device from choking on input.

"""



class InterfaceWrapper():
    #class code
    __debug_server = None #type:EthernetServerInterfaceEx
    __debug_instances = {}
    __debug_server_buffer = ''
    __debug_server_password = 'p9oai23jr09p8fmvw98foweivmawthapw4t'
    __debug_server_logged_in = False
    __delim = '~END~\x0a'

    def EnableDebugServer(Interface='AVLAN'):
        if not InterfaceWrapper.__debug_server:
            InterfaceWrapper.__debug_server = EthernetServerInterfaceEx(1988,'TCP',Interface=Interface,MaxClients=5)
            __debug_res = InterfaceWrapper.__debug_server.StartListen()
            if __debug_res != 'Listening':
                print('InterfaceWrapper EnableDebugServer: Failed : {}'.format(__debug_res))
            else:
                print('InterfaceWrapper EnableDebugServer: Succeeded on port {}'.format(Interface))

            @event(InterfaceWrapper.__debug_server, 'ReceiveData')
            def HandheReceiveFromServer(client,data:'bytes'):
                InterfaceWrapper.__debug_server_buffer += data.decode()
                while InterfaceWrapper.__delim in InterfaceWrapper.__debug_server_buffer:
                    pos = InterfaceWrapper.__debug_server_buffer.index(InterfaceWrapper.__delim)
                    temp = InterfaceWrapper.__debug_server_buffer[:pos]
                    InterfaceWrapper.__debug_server_buffer = InterfaceWrapper.__debug_server_buffer[pos+len(InterfaceWrapper.__delim)-1]
                    if 'ping()' not in temp:
                        print('Debug Tool Rx:{}'.format(temp))
                    if InterfaceWrapper.__debug_server_logged_in and '~Command~:' in temp:
                        pos = temp.index(':')
                        temp = temp[pos+1:]
                        pos = temp.index(':')
                        id = int(temp[:pos])
                        if id in InterfaceWrapper.__debug_instances.keys():
                            temp = temp[pos+1:]
                            InterfaceWrapper.__debug_instances[id]['instance'].__HandleReceiveFromServer(None,temp)
                    elif InterfaceWrapper.__debug_server_logged_in and 'exit()' in temp:
                        for client in InterfaceWrapper.__debug_server.Clients:
                            client.Send('Disconnecting...{}'.format(InterfaceWrapper.__delim))
                            client.Disconnect()
                    elif InterfaceWrapper.__debug_server_password in temp:
                        InterfaceWrapper.__debug_server_logged_in = True
                        InterfaceWrapper.__send_interface_list()

                InterfaceWrapper.__debug_server_buffer = ''


            @event(InterfaceWrapper.__debug_server, 'Connected')
            def HandleClientConnect(interface, state):
                InterfaceWrapper.client_count = len(InterfaceWrapper.__debug_server.Clients)


            @event(InterfaceWrapper.__debug_server, 'Disconnected')
            def HandleClientDisconnect(interface, state):
                InterfaceWrapper.client_count = len(InterfaceWrapper.__debug_server.Clients)
                #InterfaceWrapper.__debug_server.StopListen()
                #InterfaceWrapper.__debug_server_logged_in = False
                #__debug_res = InterfaceWrapper.__debug_server.StartListen()
                #if __debug_res != 'Listening':
                #    print('failed to launch InterfaceWrapper __debug server:{}'.format(__debug_res))
    def DisableDebugServer():
        if InterfaceWrapper.__debug_server:
            InterfaceWrapper.__debug_server_logged_in = False
            InterfaceWrapper.__debug_server.StopListen()
            for client in InterfaceWrapper.__debug_server.Clients:
                client.Disconnect()
            InterfaceWrapper.__debug_sever = None
        print('InterfaceWrapper:DisableDebug: Complete')

    def __send_interface_list():
        result = {}
        for key in InterfaceWrapper.__debug_instances:
            result[key] = {}
            result[key]['name'] = InterfaceWrapper.__debug_instances[key]['name']
            result[key]['status'] = InterfaceWrapper.__debug_instances[key]['instance'].device.Commands
            result[key]['communication'] = {}
            interface = InterfaceWrapper.__debug_instances[key]['instance'].__interface
            comm_type = InterfaceWrapper.__debug_instances[key]['instance'].__interface_type
            result[key]['communication']['type'] = str(comm_type)
            if comm_type == 'Serial':
                result[key]['communication']['host'] = str(interface.Host)
                result[key]['communication']['mode'] = str(interface.Mode)
                result[key]['communication']['port'] = str(interface.Port)
                result[key]['communication']['baud'] = '{},{},{},{}'.format(str(interface.Baud),str(interface.Data),str(interface.Parity),str(interface.Stop))
            elif comm_type in ['SerialOverEthernet','Ethernet','SSH']:
                result[key]['communication']['host'] = str(interface.Hostname)
                result[key]['communication']['mode'] = str(interface.Protocol)
                result[key]['communication']['port'] = str(interface.IPPort)
                result[key]['communication']['serviceport'] = str(interface.ServicePort)
                result[key]['communication']['credentials'] = str(interface.Credentials)
            elif comm_type == 'SPI':
                result[key]['communication']['host'] = str(interface.Host)
        result = json.dumps(result)
        if InterfaceWrapper.__debug_server:
            for client in InterfaceWrapper.__debug_server.Clients:
                client.Send('~RegisterDevices~:{}{}'.format(result,InterfaceWrapper.__delim))
    def __send_interface_status(listening_port):
        result = {}
        result[listening_port] = InterfaceWrapper.__debug_instances[listening_port]['instance'].device.Commands
        result = json.dumps(result)
        if InterfaceWrapper.__debug_server:
            for client in InterfaceWrapper.__debug_server.Clients:
                client.Send('~UpdateDevices~:{}{}'.format(result,InterfaceWrapper.__delim))

    def __add_instance(listening_port,instance,friendly_name):
        if listening_port not in InterfaceWrapper.__debug_instances.keys():
            InterfaceWrapper.__debug_instances[listening_port] = {}
            InterfaceWrapper.__debug_instances[listening_port]['name'] = friendly_name
            InterfaceWrapper.__debug_instances[listening_port]['instance'] = instance
            InterfaceWrapper.__send_interface_list()


    #instance code
    def __init__(self,device_module,listening_port=2000,friendly_name='',auto_maintain_connection=True,time_between_commands=0):
        self.friendly_name = friendly_name
        self.__device_module = device_module
        self.__sendandwait_busy = False
        self.commands_to_send = [] #type:list[str]
        self.__t_command_pacer = None #type:Timer
        self.__interface_allow_connection = False
        self.__interface_connect_status = ''
        self.__auto_maintain_connection = auto_maintain_connection
        self.__interface_type = None

        if time_between_commands > 0:
            self.__t_command_pacer = Timer(time_between_commands,self.__fn_t_command_pacer())
            self.__t_command_pacer.Restart()

        self.device = None

        self.receiveBufferCallbacks = []

        self.listeningPort = listening_port
        self.displayFormat = 'mixed'


    def __fn_device_init(self,connectiontype:'str',mod):
        class devclass(mod):
            def __init__(self):
                self.ConnectionType = connectiontype
                mod.__init__(self)
        self.device = devclass()
        self.device.Send = self.Send
        self.device.SendAndWait = self.SendAndWait
        self.__subscriber = ModuleSubscribeWrapper(self.device)
        self.device.SubscribeStatus = self.__subscriber.SubscribeStatus
        self.device.NewStatus = self.__replacement_newstatus
        self.device.Update = self.__replacement_update
        self.device.Set = self.__replacement_set
        self.device.Error = self.__replacement_error
        self.device.Discard = self.__replacement_discard
        if hasattr(self.device,'ReceiveData'):
            self.receiveBufferCallbacks.append(self.device.ReceiveData)
        InterfaceWrapper.__add_instance(self.listeningPort,self,self.friendly_name)

    def __fn_t_command_pacer(self):
        def t(timer,count):
            if self.__sendandwait_busy:
                return
            if len(self.commands_to_send):
                cmd = self.commands_to_send.pop()
                self.__printToServer('>>{0}'.format(cmd))
                self.__interface.Send(cmd)
        return t

    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = ''
        if self.displayFormat == 'ascii':
            str_to_send = string
        elif self.displayFormat == 'hex':
            dir = string[:2]
            string = string[2:]
            temp = "\x5Cx".join("{:02x}".format(ord(c)) for c in string)
            str_to_send = temp
        elif self.displayFormat == 'mixed':
            str_to_send = repr(string)
        if InterfaceWrapper.__debug_server and InterfaceWrapper.__debug_server_logged_in:
            data = {self.listeningPort:'{}-{}'.format(timestamp,str_to_send)}
            for client in InterfaceWrapper.__debug_server.Clients:
                client.Send('~UpdateDeviceComs~:{}{}'.format(json.dumps(data),InterfaceWrapper.__delim))
    def __eval_string(self,text:'str'):
        text.replace('\\r','\\x0d')
        text.replace('\\n','\\x0a')
        while '\\x' in text:
            pos = text.find('\\x')
            temp = text[pos:pos+4]
            val = int(temp[2:],16)
            char = chr(val)
            text = text.replace(temp,char)
        return text

    def __startInterfaceEvents(self):
        if self.__interface is not None:
            #@event(self.__interface, 'ReceiveData')
            def HandleReceiveFromInterface(interface,data):
                if data == None:
                    data = b''
                if data == None:
                    data = b''
                try:
                    decoded_data = data.decode()
                except:
                    data = b'failed to decode data'
                self.__printToServer('<<{}'.format(data.decode()))
                for function in self.receiveBufferCallbacks:
                    function(self.__interface,data)
            self.__interface.ReceiveData = HandleReceiveFromInterface
    def __startNetworkInterfaceEvents(self):
        @event(self.__interface,'Connected')
        def connecthandler(interface,state):
            self.__interface_connect_status = state
            print('InterfaceWrapper:{}:network device {} {}'.format(self.friendly_name,interface.Hostname,state))
            self.device.OnConnected()
        #self.__interface.Disconnected = self.__network_connection_disconnected()
        @event(self.__interface,'Disconnected')
        def connecthandler(interface,state):
            self.__interface_connect_status = state
            print('InterfaceWrapper:{}:network device {} {}'.format(self.friendly_name,interface.Hostname,state))
            self.device.OnDisconnected()

        if self.__auto_maintain_connection:
            self.__t_network_maintain = Timer(10,self.__network_connection_timer_function())

    def __HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
            #print('module recieve data:{}'.format(data.decode()))
        except:
            serverBuffer += data
            #print('module recieve data:{}'.format(data))
        if 'Reinit()' in serverBuffer:
            try:
                if self.device.ConnectionType == 'Serial':
                    self.device.OnDisconnected()
                else:
                    self.__interface.Disconnect()
            except:
                self.device.OnDisconnected()
        elif 'Set(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            temp_dict = {}
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse set command:{}'.format(e))
            cmd = ''
            if 'command' in temp_dict:
                cmd = temp_dict['command']
            value = ''
            if 'value' in temp_dict:
                value = temp_dict['value']
            qualifier = None
            if 'qualifier' in temp_dict:
                qualifier = temp_dict['qualifier']
            if self.device != None:
                if qualifier is not None:
                    self.device.Set(cmd,value,qualifier)
                else:
                    self.device.Set(cmd,value)
        elif 'Update(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            temp_dict = {}
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse set command:{}'.format(e))
            cmd = ''
            if 'command' in temp_dict:
                cmd = temp_dict['command']
            value = ''
            if 'value' in temp_dict:
                value = temp_dict['value']
            qualifier = None
            if 'qualifier' in temp_dict:
                qualifier = temp_dict['qualifier']
            if self.device != None:
                if qualifier is not None:
                    self.device.Update(cmd,value,qualifier)
                else:
                    self.device.Update(cmd,value)
        elif 'WriteStatus(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            temp_dict = {}
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse set command:{}'.format(e))
            cmd = ''
            if 'command' in temp_dict:
                cmd = temp_dict['command']
            value = ''
            if 'value' in temp_dict:
                value = temp_dict['value']
            qualifier = None
            if 'qualifier' in temp_dict:
                qualifier = temp_dict['qualifier']
            if self.device != None:
                if qualifier is not None:
                    self.device.WriteStatus(cmd,value,qualifier)
                else:
                    self.device.WriteStatus(cmd,value)
        elif 'exit()' in serverBuffer:
            for client in self.serv.Clients:
                client.Send('Disconnecting...{}'.format(InterfaceWrapper.__delim))
                client.Disconnect()
        elif 'hex()' in serverBuffer:
            self.displayFormat = 'hex'
            for client in self.serv.Clients:
                client.Send('now using hex display format{}'.format(InterfaceWrapper.__delim))
        elif 'ascii()' in serverBuffer:
            self.displayFormat = 'ascii'
            for client in self.serv.Clients:
                client.Send('now using ascii display format{}'.format(InterfaceWrapper.__delim))
        elif 'mixed()' in serverBuffer:
            self.displayFormat = 'mixed'
            for client in self.serv.Clients:
                client.Send('now using mixed display format{}'.format(InterfaceWrapper.__delim))
        elif 'passthru(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('"')+1:serverBuffer.rfind('"')]
            temp = self.__eval_string(temp)
            self.Send(temp)
        elif 'help()' in serverBuffer:
            for client in self.serv.Clients:
                client.Send('command list:\r\n    exit() : ends session.\r\n    passthru() : pass command to device format = passthru("examplecommand\\x0d")\r\n        special characters (such as \\r\\n) should be used as their hex values \\x0d\\x0a\r\n    ascii() : display as ascii string\r\n    hex() : display as hex.\r\n    mixed() : display as a mix of asci and hex string\r\n\r\n    You can also use .Set, .Update and .WriteStatus methods as formatted in Extron\'s modules. ex: Set(\'Power\',\'On\',{\'Device ID\':\'1\'})\r\n  Reinit() to reinitialize the device module communcation to the device{}'.format(InterfaceWrapper.__delim))

    def __network_connection_timer_function(self):
        def t(timer,count):
            if self.__interface:
                if self.__interface_connect_status != 'Connected' and self.__interface_allow_connection:
                    self.__interface.Connect()
        return t

    def Create_Serial_Device(self, Host, Port, Baud=9600, Data=8, Parity='None', Stop=1, FlowControl='Off', CharDelay=0, Mode='RS232', Model =None):
        self.__interface_type = 'Serial'
        self.__interface = SerialClass(Host, Port, Baud, Data, Parity, Stop, FlowControl, CharDelay, Mode)
        self.__fn_device_init('Serial',self.__device_module)
        # Check if Model belongs to a subclass
        if len(self.device.Models) > 0:
            if Model not in self.device.Models:
                print('Model mismatch')
            else:
                self.device.Models[Model]()
        self.device.OnDisconnected()
        self.__startInterfaceEvents()
    def Create_SerialOverEthernet_Device(self, Hostname, IPPort, Protocol='TCP', ServicePort=0, Model=None):
        self.__interface_type = 'SerialOverEthernet'
        self.__interface = SerialOverEthernetClass(Hostname, IPPort, Protocol, ServicePort)
        self.__fn_device_init('Serial',self.__device_module)
        # Check if Model belongs to a subclass
        if len(self.device.Models) > 0:
            if Model not in self.device.Models:
                print('Model mismatch')
            else:
                self.device.Models[Model]()
        self.device.OnDisconnected()
        self.__startNetworkInterfaceEvents()
        self.__startInterfaceEvents()
    def Create_Ethernet_Device(self, Hostname, IPPort, Protocol='TCP', ServicePort=0, Model=None):
        self.__interface_type = 'Ethernet'
        self.__interface = EthernetClass(Hostname, IPPort, Protocol, ServicePort)
        self.__fn_device_init('Ethernet',self.__device_module)
        # Check if Model belongs to a subclass
        if len(self.device.Models) > 0:
            if Model not in self.device.Models:
                print('Model mismatch')
            else:
                self.device.Models[Model]()
        self.device.OnDisconnected()
        self.__startNetworkInterfaceEvents()
        self.__startInterfaceEvents()
    def Create_SSH_Device(self, Hostname, IPPort, Protocol='SSH', ServicePort=0, Credentials=(None), Model=None):
        self.__interface_type = 'SSH'
        self.__interface = SSHClass(Hostname, IPPort, Protocol, ServicePort, Credentials)
        self.__fn_device_init('Ethernet',self.__device_module)
        # Check if Model belongs to a subclass
        if len(self.device.Models) > 0:
            if Model not in self.device.Models:
                print('Model mismatch')
            else:
                self.device.Models[Model]()
        self.device.OnDisconnected()
        self.__startNetworkInterfaceEvents()
        self.__startInterfaceEvents()
    def Create_SPI_Device(self, spi, Model=None):
        self.__interface_type = 'SPI'
        self.__interface = SPIClass(spi)
        self.__fn_device_init('Serial',self.__device_module) #spi modules use serial type apparently
        # Check if Model belongs to a subclass
        if len(self.device.Models) > 0:
            if Model not in self.device.Models:
                print('Model mismatch')
            else:
                self.device.Models[Model]()
        self.device.OnDisconnected()
        self.__startInterfaceEvents()

    def __replacement_newstatus(self,command,value,qualifier):
        InterfaceWrapper.__send_interface_status(self.listeningPort)
        self.__subscriber.NewStatus(command,value,qualifier)
    def __replacement_error(self,message:'str'):
        print('Module: {}'.format(self.friendly_name), 'Error Message: {}'.format(message), sep='\r\n')
    def __replacement_discard(self,message:'str'):
        print('Module: {}'.format(self.friendly_name), 'Error Message: {}'.format(message), sep='\r\n')
    def __replacement_set(self, command, value, qualifier=None):
        try:
            method = getattr(self.device, 'Set%s' % command)
        except:
            print('Module: {} : No method found for Set:{}'.format(self.friendly_name.command))
            return
        if method is not None and callable(method):
            if isinstance(self.__interface,SerialClass):
                method(value, qualifier)
            elif self.device.connectionFlag:
                method(value, qualifier)
        else:
            print(command, 'does not support Set.')
    def __replacement_update(self, command, qualifier=None):
        try:
            method = getattr(self.device, 'Update%s' % command)
        except:
            print('Module: {} : No method found for Update:{}'.format(self.friendly_name.command))
            return
        if method is not None and callable(method):
            if isinstance(self.__interface,SerialClass):
                method(None, qualifier)
            elif self.device.connectionFlag:
                method(None, qualifier)
        else:
            print(command, 'does not support Update.')

    def Send(self, data):
        if self.__interface is not None:
            if self.__t_command_pacer:
                self.commands_to_send.insert(0,data)
                return
            self.__printToServer('>>{0}'.format(data))
            self.__interface.Send(data)
        else:
            print('attempting to send but interface for port {} not defined'.format(self.listeningPort))
    def SendAndWait(self,commandstring,timeout=0.5,**args):
        if self.__interface is not None:
            self.__sendandwait_busy = True
            self.__printToServer('>>{0}'.format(commandstring))
            ret = self.__interface.SendAndWait(commandstring,timeout,**args)
            try:
                ret2 = ret.decode()
            except:
                ret2 = ''
            self.__printToServer('<<{0}'.format(ret2))
            self.__sendandwait_busy = False
        else:
            print('attempting to send and wait but interface for port {} not defined'.format(self.listeningPort))
            return b''
        return ret
    def Disconnect(self):
        if self.device:
            if self.device.ConnectionType in ['Ethernet','SerialOverEthernet','SSH']:
                self.__interface.Disconnect()
            self.device.OnDisconnected()
    def Connect(self):
        if self.device:
            if self.device.ConnectionType in ['Ethernet','SerialOverEthernet','SSH']:
                self.__interface_allow_connection = True
                self.__interface.Connect()
    def OnConnected(self):
        self.device.OnConnected()
    def OnDisconnected(self):
        self.device.OnDisconnected()
    def Set(self, command, value, qualifier=None):
        self.device.Set(command,value,qualifier)
    def Update(self, command, qualifier=None):
        self.device.Update(command,qualifier)
    def ReadStatus(self, command, qualifier=None):
        value = self.device.ReadStatus(command,qualifier)
        return value
    def SubscribeStatus(self, command, qualifier=None, callback=None):
        if callback is not None:
            self.device.SubscribeStatus(command,qualifier,callback)

    def addReceiveBufferCallback(self,function):
        self.receiveBufferCallbacks.append(function)
    def removeReceiveBufferCallback(self,function):
        self.receiveBufferCallbacks.remove(function)

# these interface classes are used by the interface wrapper class
class SerialClass(SerialInterface):

    def __init__(self, Host, Port, Baud=9600, Data=8, Parity='None', Stop=1, FlowControl='Off', CharDelay=0, Mode='RS232'):
        SerialInterface.__init__(self, Host, Port, Baud, Data, Parity, Stop, FlowControl, CharDelay, Mode)

    def Error(self, message):
        portInfo = 'Host Alias: {0}, Port: {1}'.format(self.Host.DeviceAlias, self.Port)
        print('Module: {}'.format(__name__), portInfo, 'Error Message: {}'.format(message[0]), sep='\r\n')

    def Discard(self, message):
        self.Error([message])
class SerialOverEthernetClass(EthernetClientInterface):

    def __init__(self, Hostname, IPPort, Protocol='TCP', ServicePort=0):
        EthernetClientInterface.__init__(self, Hostname, IPPort, Protocol, ServicePort)

    def Error(self, message):
        portInfo = 'IP Address/Host: {0}:{1}'.format(self.Hostname, self.IPPort)
        print('Module: {}'.format(__name__), portInfo, 'Error Message: {}'.format(message[0]), sep='\r\n')

    def Discard(self, message):
        self.Error([message])

    def Disconnect(self):
        EthernetClientInterface.Disconnect(self)
class EthernetClass(EthernetClientInterface):

    def __init__(self, Hostname, IPPort, Protocol='TCP', ServicePort=0):
        EthernetClientInterface.__init__(self, Hostname, IPPort, Protocol, ServicePort)

    def Error(self, message):
        portInfo = 'IP Address/Host: {0}:{1}'.format(self.Hostname, self.IPPort)
        print('Module: {}'.format(__name__), portInfo, 'Error Message: {}'.format(message[0]), sep='\r\n')

    def Discard(self, message):
        self.Error([message])

    def Disconnect(self):
        EthernetClientInterface.Disconnect(self)
class SSHClass(EthernetClientInterface):

    def __init__(self, Hostname, IPPort, Protocol='SSH', ServicePort=0, Credentials=(None)):
        EthernetClientInterface.__init__(self, Hostname, IPPort, Protocol, ServicePort, Credentials)

    def Error(self, message):
        portInfo = 'IP Address/Host: {0}:{1}'.format(self.Hostname, self.IPPort)
        print('Module: {}'.format(__name__), portInfo, 'Error Message: {}'.format(message[0]), sep='\r\n')

    def Discard(self, message):
        self.Error([message])

    def Disconnect(self):
        EthernetClientInterface.Disconnect(self)
        self.OnDisconnected()
class SPIClass(SPInterface):

    def __init__(self, spd):
        SPInterface.__init__(self, spd)

    def Error(self, message):
        print('Module: {}'.format(__name__), 'Error Message: {}'.format(message[0]), sep='\r\n')

    def Discard(self, message):
        self.Error([message])

    def Disconnect(self):
        self.OnDisconnected()




























'''
creates a dictionary of devices with their values.  upon connection to the given ip port, prints the dictionary in json format to telnet interface.
also prints updates to these values as they occur.

example:

from tools import status_report


sr = status_report(3001)
sr.update('Display','ConnectionStatus','Connected')


'''


class status_report():
    def __init__(self,listening_port=2000,interface='AVLAN'):
        self.listeningPort = listening_port
        self.serverBuffer = ''
        self.clientCount = 0
        self.cmdflag = False
        self.interface = interface
        self.info = {}
        self.serv= EthernetServerInterfaceEx(self.listeningPort,'TCP',Interface=interface,MaxClients=5)
        self.__startServer()
        self.__startEvents()
    def __register(self,d:'str',s:'str'):
        self.info[d] = {'statuses':{s:''}}
    def __send_single(self,d:'str',s:'str'):
        j = {}
        j[d] = {'statuses':{s:self.info[d]['statuses'][s]}}
        data = json.dumps(j)
        self.__send(data)
    def __send_all(self):
        data = json.dumps(self.info)
        self.__send(data)
    def __startServer(self):
        """Start the server.  Reattempt on failure after 1s."""
        print('InterfaceWrapper:startServer: port {0} starting'.format(self.listeningPort))
        if self.serv.StartListen() != 'Listening':   # Port unavailable
            print('InterfaceWrapper:startServer: port {0} unavailable'.format(self.listeningPort))
            Wait(1, self.startServer)
    def __send(self, string):
        if(self.clientCount > 0):
            for client in self.serv.Clients:
                client.Send('{0}'.format(string))
    def __startEvents(self):
        @event(self.serv, 'ReceiveData')
        def HandheReceiveFromServer(client,data):
            pass
        @event(self.serv, 'Connected')
        def HandleClientConnect(interface, state):
            self.clientCount += 1
            print('status_report:Client connected to {0} ({1}).'.format(self.listeningPort,interface.IPAddress))
            self.__send_all()
        @event(self.serv, 'Disconnected')
        def HandleClientDisconnect(interface, state):
            self.clientCount = 0
            print('status_report:Client disconnected from {0}).'.format(self.listeningPort))
            self.serv.StopListen()
            self.__startServer()

    def Update(self,d:'str',s:'str',v):
        if d not in self.info:
            self.__register(d,s)
        self.info[d]['statuses'][s] = v
        if self.clientCount > 0:
            self.__send_single(d,s)































"""
It is highly advised that after each combination of panels re-send indirect
Text fields,button states, visibility, other settings, popups, and page flips.
Items in combined panels do NOT sync with the combination process unless a sync
function is supplied.
Time required varies depending on how many items there are to combine.

Any panel or ID can be supplied either one at a time or as a list


example: adds panels to room, creates button events for 15 buttons, removes one of the panels from room,
adds new panel to room


Rm = TPManagerClass()
Rm.AddPanel([tp1,tp2])

def foo1(button,state):
    pass
Rm.SetFunction(1,foo1,'Pressed')

def foo2(button,state):
    pass
Rm.SetFunction([range(2,16)],foo2,'Pressed',isMomentary=True)  #isMomentary is optional, default is false
Rm.SetFunction([range(2,16)],foo2,'Repeated')

Rm.RemovePanel(tp2)
Rm.AddPanel(tp3)

"""

class TPManager():
    def __init__(self):
        self.devTPs = []

        self.btns = []
        self.btnIDs = []
        self.btnHoldTimes = {}
        self.btnRepeatTimes = {}
        self.btnPushFunctions = {}
        self.btnReleaseFunctions = {}
        self.btnHoldFunctions = {}
        self.btnTapFunctions = {}
        self.btnRepeatFunctions = {}

        self.knobs = []
        self.knobIDs = []
        self.knobTurnFunctions = {}

        self.lbls = []
        self.lblIDs = []

        self.lvls = []
        self.lvlIDs = []


        self.sliders =[]
        self.sliderIDs = []
        self.sliderChangedFunctions = {}
        self.sliderPressedFunctions = {}
        self.sliderReleasedFunctions = {}


        self.SyncFunction = None



    def SetSyncFunction(self,function):
        self.SyncFunction = function

    # this function adds a panel or list of panels to the virtual panel, then defines the buttons actions for the newly added panel
    def AddPanel(self,tps:'UIDevice'):
        tpList = []
        if type(tps) is type([]):
            tpList.extend(tps)
        else:
            tpList.append(tps)

        for tp in tpList:
            self.devTPs.append(tp)
            self.btns.append({})
            self.knobs.append({})
            self.lbls.append({})
            self.lvls.append({})
            self.sliders.append({})
            print('adding panel : {0}'.format(self.devTPs.index(tp)))
            #create the button list for the new panel
            for itemID in self.btnIDs:
                print('adding button : {0}'.format(itemID))
                self.btns[self.devTPs.index(tp)][itemID] = Button(tp,itemID,self.btnHoldTimes[itemID],self.btnRepeatTimes[itemID])
            #define button events for new panel based on virtual panel vars
            for itemID in self.btnPushFunctions.keys():
                @event(self.btns[self.devTPs.index(tp)][itemID],'Pressed')
                def stuff(button,state):
                    for func in self.btnPushFunctions[button.ID]:
                        try:
                            func(button,state)
                        except Exception as e:
                            print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))
            for itemID in self.btnReleaseFunctions.keys():
                @event(self.btns[self.devTPs.index(tp)][itemID],'Released')
                def stuff(button,state):
                    for func in self.btnReleaseFunctions[button.ID]:
                        try:
                            func(button,state)
                        except Exception as e:
                            print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))
            for itemID in self.btnHoldFunctions.keys():
                @event(self.btns[self.devTPs.index(tp)][itemID],'Held')
                def stuff(button,state):
                    for func in self.btnHoldFunctions[button.ID]:
                        try:
                            func(button,state)
                        except Exception as e:
                            print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))
            for itemID in self.btnTapFunctions.keys():
                @event(self.btns[self.devTPs.index(tp)][itemID],'Tapped')
                def stuff(button,state):
                    for func in self.btnTapFunctions[button.ID]:
                        try:
                            func(button,state)
                        except Exception as e:
                            print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))
            for itemID in self.btnRepeatFunctions.keys():
                @event(self.btns[self.devTPs.index(tp)][itemID],'Repeated')
                def stuff(button,state):
                    for func in self.btnRepeatFunctions[button.ID]:
                        try:
                            func(button,state)
                        except Exception as e:
                            print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))

            #create the knob list for the new panel
            for itemID in self.knobIDs:
                print('adding knob : {0}'.format(itemID))
                self.knobs[self.devTPs.index(tp)][itemID] = Knob(tp,itemID)
                #define knob events for new panel based on virtual panel vars
                if itemID in self.knobTurnFunctions.keys():
                    @event(self.knobs[self.devTPs.index(tp)][itemID],'Turned')
                    def stuff(knob,direction):
                        for func in self.knobTurnFunctions[knob.ID]:
                            try:
                                func(knob,direction)
                            except Exception as e:
                                print('exception calling function for knob {} state:{} :{}'.format(knob.ID,direction,e))


            #create the label list for the new panel
            for itemID in self.lblIDs:
                print('adding label : {0}'.format(itemID))
                self.lbls[self.devTPs.index(tp)][itemID] = Label(tp,itemID)

            #create the level list for the new panel
            for itemID in self.lvlIDs:
                print('adding level : {0}'.format(itemID))
                self.lvls[self.devTPs.index(tp)][itemID] = Level(tp,itemID)

            #create the slider list for the new panel
            for itemID in self.sliderIDs:
                print('adding slider : {0}'.format(itemID))
                self.sliders[self.devTPs.index(tp)][itemID] = Slider(tp,itemID)
                #define slider events for new panel based on virtual panel vars
                if itemID in self.sliderChangedFunctions.keys():
                    @event(self.sliders[self.devTPs.index(tp)][itemID],'Changed')
                    def stuff(slider,state,value):
                        for func in self.sliderChangedFunctions[slider.ID]:
                            try:
                                func(slider,state,value)
                            except Exception as e:
                                print('exception calling function for slider {} state:{} :{}'.format(slider.ID,state,e))

                if itemID in self.sliderPressedFunctions.keys():
                    @event(self.sliders[self.devTPs.index(tp)][itemID],'Pressed')
                    def stuff(slider,state,value):
                        for func in self.sliderPressedFunctions[slider.ID]:
                            try:
                                func(slider,state,value)
                            except Exception as e:
                                print('exception calling function for slider {} state:{} :{}'.format(slider.ID,state,e))
                if itemID in self.sliderReleasedFunctions.keys():
                    @event(self.sliders[self.devTPs.index(tp)][itemID],'Released')
                    def stuff(slider,state,value):
                        for func in self.sliderReleasedFunctions[slider.ID]:
                            try:
                                func(slider,state,value)
                            except Exception as e:
                                print('exception calling function for slider {} state:{} :{}'.format(slider.ID,state,e))

        #resync panels for virtual panel
        if self.SyncFunction != None:
            self.SyncFunction()

    # this function removes a panel or list of panels from the virtual panel
    def RemovePanel(self,tps:'UIDevice'):
        tpList = []
        if type(tps) is type([]):
            tpList.extend(tps)
        else:
            tpList.append(tps)
        for tp in tpList:
            del self.btns[self.devTPs.index(tp)]
            del self.knobs[self.devTPs.index(tp)]
            del self.lbls[self.devTPs.index(tp)]
            del self.lvls[self.devTPs.index(tp)]
            del self.sliders[self.devTPs.index(tp)]
            self.devTPs.remove(tp)

    def RemoveAllPanels(self):
        for tp in self.devTPs:
            del self.btns[self.devTPs.index(tp)]
            del self.knobs[self.devTPs.index(tp)]
            del self.lbls[self.devTPs.index(tp)]
            del self.lvls[self.devTPs.index(tp)]
            del self.sliders[self.devTPs.index(tp)]
            self.devTPs.remove(tp)

    # panel navigation functions
    def HideAllPopups(self):
        for tp in self.devTPs:
            tp.HideAllPopups()
    def HidePopup(self,value:str):
        for tp in self.devTPs:
            tp.HidePopup(value)
    def HidePopupGroup(self,value:str):
        for tp in self.devTPs:
            tp.HidePopupGroup(value)
    def ShowPage(self,value:str):
        for tp in self.devTPs:
            tp.ShowPage(value)
    def ShowPopup(self,value:str):
        for tp in self.devTPs:
            tp.ShowPopup(value)

    # this function adds buttons to the data for the virtual panel
    def AddButton(self,itemIDs,holdTime:float=None,repeatTime:float=None,isMomentary:bool=False):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            self.btnIDs.append(itemID)
            self.btnHoldTimes[itemID] = holdTime
            self.btnRepeatTimes[itemID] = repeatTime
            self.btnPushFunctions[itemID] = []
            self.btnReleaseFunctions[itemID] = []
            self.btnHoldFunctions[itemID] = []
            self.btnTapFunctions[itemID] = []
            self.btnRepeatFunctions[itemID] = []

            for tp in self.devTPs:
                self.btns[self.devTPs.index(tp)][itemID] = Button(tp,itemID,holdTime,repeatTime)
            if isMomentary:
                def pressed(button,state):
                    button.SetState(1)
                def released(button,state):
                    button.SetState(0)
                self.SetFunction(itemID,pressed,'Pressed')
                self.SetFunction(itemID,released,'Released')
                self.SetFunction(itemID,released,'Held')
                self.SetFunction(itemID,released,'Tapped')

    # this function adds knobs to the data for the virtual panel
    def AddKnob(self,itemIDs):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            self.knobIDs.append(itemID)
            self.knobTurnFunctions[itemID] = []
            for tp in self.devTPs:
                self.knobs[self.devTPs.index(tp)][itemID] = Knob(tp,itemID)

    # this function adds knobs to the data for the virtual panel
    def AddLevel(self,itemIDs):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            self.lvlIDs.append(itemID)
            for tp in self.devTPs:
                self.lvls[self.devTPs.index(tp)][itemID] = Level(tp,itemID)

    # this function adds sliders to the date for the virtual panel
    def AddSlider(self,itemIDs):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            self.sliderIDs.append(itemID)
            self.sliderChangedFunctions[itemID] = []
            self.sliderPressedFunctions[itemID] = []
            self.sliderRelesedFunctions[itemID] = []
            for tp in self.devTPs:
                self.sliders[self.devTPs.index(tp)][itemID] = Slider(tp,itemID)


    # this function adds knobs to the data for the virtual panel
    def AddLabel(self,itemIDs):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            self.lblIDs.append(itemID)
            for tp in self.devTPs:
                self.lbls[self.devTPs.index(tp)][itemID] = Label(tp,itemID)

    # associates a button with given ID with a function for pressed action for each TP in virtual panel
    def SetFunction(self,itemIDs,function,trigger:str):
        idList = []
        func_list = None
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.btnIDs:
                if trigger == 'Pressed':
                    if itemID in self.btnPushFunctions.keys():
                        if function not in self.btnPushFunctions[itemID]:
                            self.btnPushFunctions[itemID].append(function)
                    else:
                        self.btnPushFunctions[itemID] = [function]
                    func_list = self.btnPushFunctions[itemID]
                elif trigger == 'Released':
                    if itemID in self.btnReleaseFunctions.keys():
                        if function not in self.btnReleaseFunctions[itemID]:
                            self.btnReleaseFunctions[itemID].append(function)
                    else:
                        self.btnReleaseFunctions[itemID] = [function]
                    func_list = self.btnReleaseFunctions[itemID]
                elif trigger == 'Held':
                    if itemID in self.btnHoldFunctions.keys():
                        if function not in self.btnHoldFunctions[itemID]:
                            self.btnHoldFunctions[itemID].append(function)
                    else:
                        self.btnHoldFunctions[itemID] = [function]
                    func_list = self.btnHoldFunctions[itemID]
                elif trigger == 'Tapped':
                    if itemID in self.btnTapFunctions.keys():
                        if function not in self.btnTapFunctions[itemID]:
                            self.btnTapFunctions[itemID].append(function)
                    else:
                        self.btnTapFunctions[itemID] = [function]
                    func_list = self.btnTapFunctions[itemID]
                elif trigger == 'Repeated':
                    if itemID in self.btnRepeatFunctions.keys():
                        if function not in self.btnRepeatFunctions[itemID]:
                            self.btnRepeatFunctions[itemID].append(function)
                    else:
                        self.btnRepeatFunctions[itemID] = [function]
                    func_list = self.btnRepeatFunctions[itemID]
                for tp in self.devTPs:
                    @event(self.btns[self.devTPs.index(tp)][itemID],trigger)
                    def stuff(button,state):
                        print('there are {} functions for btn {} state:{}'.format(len(func_list),button.ID,state))
                        for func in func_list:
                            try:
                                func(button,state)
                            except Exception as e:
                                print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))
            elif itemID in self.knobIDs:
                if trigger == 'Turned':
                    if itemID in self.knobTurnFunctions.keys():
                        if function not in self.knobTurnFunctions[itemID]:
                            self.knobTurnFunctions[itemID].append(function)
                    else:
                        self.knobTurnFunctions[itemID] = [function]
                    func_list = self.knobTurnFunctions[itemID]
                for tp in self.devTPs:
                    @event(self.knobs[self.devTPs.index(tp)][itemID],trigger)
                    def stuff(knob,direction):
                        for func in func_list:
                            try:
                                func(knob,direction)
                            except Exception as e:
                                print('exception calling function for knob {} state:{} :'.format(knob.ID,direction,e))
            elif itemID in self.sliderIDs:
                if trigger == 'Changed':
                    if itemID in self.sliderChangedFunctions.keys():
                        if function not in self.sliderChangedFunctions[itemID]:
                            self.sliderChangedFunctions[itemID].append(function)
                    else:
                        self.sliderChangedFunctions[itemID] = [function]
                    func_list = self.sliderChangedFunctions[itemID]
                if trigger == 'Pressed':
                    if itemID in self.sliderPressedFunctions.keys():
                        if function not in self.sliderPressedFunctions[itemID]:
                            self.sliderPressedFunctions[itemID].append(function)
                    else:
                        self.sliderPressedFunctions[itemID] = [function]
                    func_list = self.sliderPressedFunctions[itemID]
                if trigger == 'Released':
                    if itemID in self.sliderRelesedFunctions.keys():
                        if function not in self.sliderRelesedFunctions[itemID]:
                            self.sliderRelesedFunctions[itemID].append(function)
                    else:
                        self.sliderRelesedFunctions[itemID] = [function]
                    func_list = self.sliderRelesedFunctions[itemID]
                for tp in self.devTPs:
                    @event(self.sliders[self.devTPs.index(tp)][itemID],trigger)
                    def stuff(slider,state,value):
                        for func in func_list:
                            try:
                                func(slider,state)
                            except Exception as e:
                                print('exception calling function for slider {} state:{} :{}'.format(slider.ID,state,e))
            else:
                print('Addfunction Failed : invalid ID ',str(itemID))

    # modify values of items for each panel by ID number or name
    def SetState(self,itemIDs,value:int):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.btnIDs:
                for tp in self.devTPs:
                    self.btns[self.devTPs.index(tp)][itemID].SetState(value)
            else:
                print('SetState Failed : invalid ID ',str(itemID))
    def SetText(self,itemIDs,value:str):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.btnIDs:
                for tp in self.devTPs:
                    self.btns[self.devTPs.index(tp)][itemID].SetText(value)
            elif itemID in self.lblIDs:
                for tp in self.devTPs:
                    self.lbls[self.devTPs.index(tp)][itemID].SetText(value)
            else:
                print('SetText Failed : invalid ID ',str(itemID))
    def SetBlinking(self,itemIDs,rate:str,value:list):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.btnIDs:
                for tp in self.devTPs:
                    self.btns[self.devTPs.index(tp)][itemID].SetBlinking(rate,[value])
            else:
                print('SetBlinking Failed : invalid ID ',str(itemID))
    def SetLevel(self,itemIDs,value:int):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.lvlIDs:
                for tp in self.devTPs:
                    self.lvls[self.devTPs.index(tp)][itemID].SetLevel(value)
            else:
                print('SetLevel Failed : invalid ID ',str(itemID))
    def SetFill(self,itemIDs,value:int):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.sliderIDs:
                for tp in self.devTPs:
                    self.sliders[self.devTPs.index(tp)][itemID].SetFill(value)
            else:
                print('SetFill Failed : invalid ID ',str(itemID))

    def SetEnable(self,itemIDs,value:bool):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.btnIDs:
                for tp in self.devTPs:
                    self.btns[self.devTPs.index(tp)][itemID].SetEnable(value)
            else:
                print('SetEnable Failed : invalid ID ',str(itemID))
    def SetVisible(self,itemIDs,value:bool):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.btnIDs:
                for tp in self.devTPs:
                    self.btns[self.devTPs.index(tp)][itemID].SetVisible(value)
            elif itemID in self.lblIDs:
                for tp in self.devTPs:
                    self.lbls[self.devTPs.index(tp)][itemID].SetVisible(value)
            elif itemID in self.lvlIDs:
                for tp in self.devTPs:
                    self.lvls[self.devTPs.index(tp)][itemID].SetVisible(value)
            else:
                print('SetVisible Failed : invalid ID ',str(itemID))
    def SetRange(self,itemIDs,minimum:int,maximum:int,step:int = 1):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.lvlIDs:
                for tp in self.devTPs:
                    self.lvls[self.devTPs.index(tp)][itemID].SetRange(minimum,maximum,step)
            elif itemID in self.sliderIDs:
                for tp in self.devTPs:
                    self.sliders[self.devTPs.index(tp)][itemID].SetRange(minimum,maximum,step)
            else:
                print('SetRange Failed : invalid ID ',str(itemID))
    def Dec(self,itemIDs):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.lvlIDs:
                for tp in self.devTPs:
                    self.lvls[self.devTPs.index(tp)][itemID].Dec()
            else:
                print('Dec Failed : invalid ID ',str(itemID))
    def Inc(self,itemIDs):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.lvlsIDs:
                for tp in self.devTPs:
                    self.lvls[self.devTPs.index(tp)][itemID].Inc()
            else:
                print('Inc Failed : invalid ID ',str(itemID))

    def SimulateAction(self,itemID,action):
        if itemID in self.btnIDs:
            try:
                getattr(self.btns[0][itemID], '%s' % action)()
            except AttributeError:
                print('{0} does not support {1}.'.format(self.btns[0][itemID].ID,action))

    def SetCurrent(self,btnIDs,item:int):
        for btnID in btnIDs:
            if btnID == item:
                self.SetState(btnID,1)
            else:
                self.SetState(btnID,0)















'''
to allow for more dynamic programs, this class allows multiple event handlers to be attached to a status.  It will execute the handlers in the order that was subscribed

ex:
module.SubscribeStatus('EventName',qualifier,function1)
module.SubscribeStatus('EventName',qualifier,function2)

'''





class ModuleSubscribeWrapper():
    def __init__(self,mod,__debug_info=None):
        self.__debug_info = __debug_info
        self.mod = mod

    def NewStatus(self, command, value, qualifier):
        if self.__debug_info:
            print("{} : subscriber new status: {} {} {}".format(self.__debug_info,command,value,qualifier))
        if command in self.mod.Subscription:
            Subscribe = self.mod.Subscription[command]
            Method = Subscribe['method']
            Command = self.mod.Commands[command]
            if qualifier:
                for Parameter in Command['Parameters']:
                    try:
                        Method = Method[qualifier[Parameter]]
                    except:
                        break
            if 'callback' in Method and Method['callback']:
                if self.__debug_info:
                    print("{} : subscriber new status callbacks{}: {} {} {}".format(self.__debug_info,len(Method['callback']),command,value,qualifier))
                for callback in Method['callback']:
                    callback(command, value, qualifier)

    def SubscribeStatus(self, command, qualifier, callback):

        Command = self.mod.Commands.get(command)
        if Command:
            if command not in self.mod.Subscription:
                self.mod.Subscription[command] = {'method': {}}

            Subscribe = self.mod.Subscription[command]
            Method = Subscribe['method']

            if qualifier:
                for Parameter in Command['Parameters']:
                    try:
                        Method = Method[qualifier[Parameter]]
                    except:
                        if Parameter in qualifier:
                            Method[qualifier[Parameter]] = {}
                            Method = Method[qualifier[Parameter]]
                        else:
                            return
            if 'callback' in Method.keys():
                Method['callback'].append(callback)
                if self.__debug_info:
                    print("{} : subscriber callback add {}: {} {}".format(self.__debug_info,len(Method['callback']),command,qualifier))
            else:
                Method['callback'] = [callback]
                if self.__debug_info:
                    print("{} : subscriber callback add {}: {} {}".format(self.__debug_info,len(Method['callback']),command,qualifier))
            Method['qualifier'] = qualifier
        else:
            print(command, 'does not exist in the module')



























'''
saves a dictionary of values (basic types only) to file as a json object, allows for manipulation of them and recovery.
the optional parameter 'auto_sync_time' allows for saving of the variables to file automatically on a regular interval. (in seconds)

multiple callback functions may be added as needed to make code more readable, not all variables need to be handled in the same callback.

example:

from tools import NonvolatileValues

#default startup values
var1 = ''
var2 = 0
var3 = [False,False]

nvram = NonvolatileValues('filename.dat')
def handle_nvram_var1_var2(values:'dict'):
    global var1
    global var2

    if 'var1key' in values:
        var1 = values['var1key']
    if 'var2key' in values:
        var2 = values['var2key']

def handle_nvram_var3(values:'dict'):
    global var3
    if 'var3key' in values:
        var3 = values['var3key']

nvram.AddSyncValuesFunction(handle_nvram_var1_var2)
nvram.AddSyncValuesFunction(handle_nvram_var3)
nvram.ReadValues()


def update_nvram():
    global var1
    global var2
    global var3
    var1 = 'new value'
    var2 = 1
    var3[1] = True

    nvram.SetValue('var1key',var1)
    nvram.SetValue('var2key',var2)
    nvram.SetValue('var3key',var3)
    nvram.SaveValues() # must be explicitly saved after updating if 'auto_sync_time' not used.


'''


class NonvolatileValues():
    def __init__(self,filename:'str',auto_sync_time:'float'= None) -> None:
        self.__filename = filename
        self.__auto_sync_time = auto_sync_time
        self.values = {}
        self.__syncvaluesfunctions = []

        if self.__auto_sync_time:
            @Timer(self.__auto_sync_time)
            def auto_sync_function(timer,count):
                self.SaveValues()


    def ReadValues(self):
        f = None
        values = {}
        try:
            f = File(self.__filename,'rt')
        except Exception as e:
            print('NonvolatileValues: failed to open and read file:{}'.format(e))
        if f:
            try:
                values = json.load(f)
            except Exception as e:
                print('NonvolatileValues: failed to convert to dict, deleting file:{}'.format(e))
                File.DeleteFile(self.__filename)
            f.close()
        self.values = values
        if self.__syncvaluesfunctions:
            for f in self.__syncvaluesfunctions:
                f(self.values)

    def SetValue(self,id:'str',value):
        self.values[id] = value

    def GetValue(self,id:'str'):
        return self.values[id]

    def GetAllValues(self):
        if self.__syncvaluesfunctions:
            for f in self.__syncvaluesfunctions:
                f(self.values)

    def SaveValues(self):
        f = None
        try:
            f = File(self.__filename,'wt') #try writing
        except Exception as e:
            f = File(self.__filename,'x') #create file and open for writing
            f = File(self.__filename,'wt')
        if f:
            try:
                print('NonvolatileValues: dumping dictionary:{}'.format(self.values))
                json.dump(self.values,f)
            except Exception as e:
                print('NonvolatileValues: unable to dump dictionary:{}:{}'.format(e,self.values))
            f.close()
        self.ReadValues()


    def AddSyncValuesFunction(self,func):
        self.__syncvaluesfunctions.append(func)











class ProgramLogSaver():
    now = datetime.now()
    nowstr = now.strftime('%Y-%m-%d-%H-%M-%S')
    __filename = '{}-{}.log'.format('ProgramLog',nowstr)
    cur_log = ''

    def __readdummyprogramlog():
        f = None
        log = None
        try:
            f = File('temp.log','r')
        except Exception as e:
            print('ProgramLogSaver: failed to open file:{}'.format(e))
        if f:
            try:
                log = f.read()
            except Exception as e:
                print('ProgramLogSaver: failed to read file:{}'.format(e))
            f.close()
        return log


    def __saveprogramlog():
        with File(ProgramLogSaver.__filename, 'w') as f:
            SaveProgramLog(f)
    def __savedummyprogramlog():
        with File('temp.log', 'w') as f:
            SaveProgramLog(f)

    def __checkprogramlog(timer,count):
        ProgramLogSaver.__savedummyprogramlog()
        log = ProgramLogSaver.__readdummyprogramlog()
        if log != ProgramLogSaver.cur_log:
            ProgramLogSaver.cur_log = log
            ProgramLogSaver.__saveprogramlog()
            print('ProgramLogSaver: new log saved')
    __save_timer = Timer(60,__checkprogramlog)
    __save_timer.Restart()