from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from EthernetClientInterface import EthernetClientInterface
    from UI_EthernetAndSerialDevices import EthernetAndSerialDevices
    from ProcessorCommunication import ProcessorCommunicationClass

class variablesclass():
    def __init__(self):
        self.ip_address = ''
        self.system_connected_status = ''
        self.devices_client = None #type:EthernetClientInterface
        self.device_info = {}

        self.ui_view1 = None #type:EthernetAndSerialDevices
        self.ui_view2 = None #type:EthernetAndSerialDevices
        self.ui_views = [] #type:list[EthernetAndSerialDevices]
        self.processor_communication = None #type:ProcessorCommunicationClass