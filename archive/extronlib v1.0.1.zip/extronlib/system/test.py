import time

from threading import Thread


time.sleep(3)
def func():
    print('func_starting')
    time.sleep(1)
    print('func_running')
    time.sleep(1)

def func_finished():
    print('done')

print('func starting')
task = Thread(target=func)
task.__stop__()
task.start()
print('after func call')
