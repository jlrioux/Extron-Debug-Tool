

from tkinter import *
from Timer import Timer
import json
import re
from EthernetClientInterface import EthernetClientInterface
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from variables import variablesclass

class ProcessorCommunicationClass():
    def __init__(self,vars:'variablesclass'):
        self.vars = vars
        self.t_keep_client_connected = Timer(10,self.fn_keep_client_connected())
        self.t_keep_client_connected.Stop()
        self.__devices_clientbuffer = ''

        self.__connect_to_system = False
        self.__system_is_connected = False
        self.__connection_manager = Timer(5,self.__f_connection_manager())
        self.__connection_manager.Restart()
        self.__delim = '~END~\x0a'
        self.__rxmatchpattern = '~(RegisterDevices|UpdateDeviceComs|UpdateDevices)~:\d*:?(.*)~END~'

    def open_connect_window(self):
        window2 = Tk()
        window2.title(' Connect To System ')
        window2.geometry('250x75')

        lbl_instructions = Label(window2,text = ' Enter the IP address of the Extron Controller:  ')
        lbl_instructions.grid(column=0,row=0)

        def clear_tb_ip():
            self.vars.ip_address = tb_ip.get(1.0,'end')
            self.vars.ip_address = self.vars.ip_address.strip()
            print('recieved ip address of controller:{}'.format(self.vars.ip_address))
            window2.destroy()
            self.system_connection_start()
        def clear_tb_enter(event):
            clear_tb_ip()
        tb_ip = Text(window2,height=1,width=20)
        tb_ip.grid(column=0,row=2)
        tb_ip.bind('<Return>',clear_tb_enter)
        tb_ip.insert(END,self.vars.ip_address)
        tb_ip.update()
        btn_submit = Button(window2,text='Submit',width=10,height=1,command=clear_tb_ip)
        btn_submit.grid(column=0,row=4)
        #apply focus
        window2.wm_deiconify

    def system_connection_start(self):
        if self.vars.devices_client:
            self.system_connection_stop()
        if not self.vars.devices_client:
            self.vars.ui_view1.SetConnectStatus('Connecting...')
            self.vars.devices_client = EthernetClientInterface(self.vars.ip_address,1988)
            self.SetClient()
        if 'Connected' not in self.vars.system_connected_status:
            self.t_keep_client_connected.Restart()
        self.__connect_to_system = True
    def system_connection_stop(self):
        if self.vars.devices_client:
            if 'Connected' in self.vars.system_connected_status:
                self.vars.devices_client.Disconnect()
            self.vars.devices_client = None
            self.vars.system_connected_status = ''
        self.t_keep_client_connected.Stop()
        self.__connect_to_system = False

    def fn_keep_client_connected(self):
        def t(timer,count):
            if not self.__system_is_connected and self.vars.devices_client:
                self.vars.ui_view1.SetConnectStatus('Connecting...')
                self.vars.system_connected_status = self.vars.devices_client.Connect()
                if not self.__system_is_connected:
                    self.vars.ui_view1.SetConnectStatus('Timeout')
                elif self.vars.system_connected_status != 'Connected':
                    self.vars.ui_view1.SetConnectStatus('Timeout')
                    self.t_keep_client_connected.Stop()
            elif self.__system_is_connected and self.vars.devices_client:
                self.t_keep_client_connected.Stop()
        return t


    def __f_connection_manager(self):
        def t(timer,count):
            if not self.vars.devices_client:
                return
            if self.__connect_to_system and not self.__system_is_connected:
                self.vars.devices_client.Connect()
            elif self.__system_is_connected and not self.__connect_to_system:
                self.vars.devices_client.Disconnect()
        return t

    def __removesuffix(self,data:'str',end:'str'):
        try:
            return data[data.index(end)+len(end):]
        except:
            return data
    def __HandleRecieveFromClient(self,client,data:'bytes'):
        self.__devices_clientbuffer += data.decode()
        while self.__delim in self.__devices_clientbuffer:
            delim_pos = self.__devices_clientbuffer.index(self.__delim)
            temp_buf = self.__devices_clientbuffer[:delim_pos+len(self.__delim)]
            print('system rx:{}'.format(temp_buf))
            self.__devices_clientbuffer = self.__removesuffix(self.__devices_clientbuffer,self.__delim)
            matches = re.findall(self.__rxmatchpattern,temp_buf)
            for match in matches:
                match_type = match[0]
                if 'RegisterDevices' == match_type:
                    json_data = match[1]
                    while '~RegisterDevices~:' in json_data:
                        json_data = json_data[json_data.index('~RegisterDevices~:')+len('~RegisterDevices~:')+1:]
                    try:
                        device_info = json.loads(json_data)
                        self.vars.ui_view1.SetDeviceInfo(device_info)
                        self.vars.ui_view1.SetDeviceList()
                    except Exception as e:
                        print('error decoding register devices json from system, error:' + str(e))
                        self.vars.ui_view1.SetDeviceInfo({})
                if 'UpdateDeviceComs' == match_type:
                    json_data = match[1]
                    update = None
                    try:
                        update = json.loads(json_data)
                    except Exception as e:
                        print('error decoding update devices json from system, error:' + e)
                    if update:
                        for key in update:
                            self.vars.ui_view1.UpdateDeviceLog(key,update[key])
                if 'UpdateDevices' == match_type:
                    json_data = match[1]

                    update = None
                    try:
                        update = json.loads(json_data)
                    except Exception as e:
                        print('error decoding update devices json from system, error:' + str(e))
                        continue
                    if update:
                        for key in update:
                            if key in self.vars.device_info:
                                #self.vars.device_info[key]['status'].update(update[key])
                                Command = self.vars.device_info[key]['status'][update[key]['command']]
                                Qualifier = update[key]['qualifier']
                                Value = update[key]['value']
                                Status = Command['Status']
                                if Qualifier:
                                    for Parameter in Command['Parameters']:
                                        try:
                                            Status = Status[Qualifier[Parameter]]
                                        except KeyError:
                                            if Parameter in Qualifier:
                                                Status[Qualifier[Parameter]] = {}
                                                Status = Status[Qualifier[Parameter]]
                                            else:
                                                return
                                try:
                                    if Status['Live'] != str(Value):
                                        Status['Live'] = str(Value)
                                        self.vars.ui_view1.UpdateDeviceInfo(key)
                                except:
                                    Status['Live'] = str(Value)
                                    self.vars.ui_view1.UpdateDeviceInfo(key)
    def __HandleConnected(self,client,state:'str'):
        print('devices connected')
        self.__system_is_connected = True
        self.vars.system_connected_status = state
        self.vars.ui_view1.SetConnectStatus(state)
        self.SendToSystem('p9oai23jr09p8fmvw98foweivmawthapw4t')
        self.vars.devices_client.StartKeepAlive(5,'ping(){}'.format(self.__delim))
    def __HandleDisconnected(self,client,state:'str'):
        print('devices disconnected')
        self.__system_is_connected = False
        self.vars.system_connected_status = state
        self.vars.ui_view1.SetConnectStatus(state)

    def EndConnections(self):
        self.t_keep_client_connected.Stop()
        self.__connect_to_system = False
        self.__connection_manager.Stop()
        if self.vars.devices_client:
            self.vars.devices_client.Disconnect()

    def SetClient(self):
        self.vars.devices_client.Connected = self.__HandleConnected
        self.vars.devices_client.Disconnected = self.__HandleDisconnected
        self.vars.devices_client.ReceiveData = self.__HandleRecieveFromClient

    def SendToSystem(self,cmd:'str'):
        if self.vars.devices_client:
            print('sending to system:{}'.format(cmd))
            if len(cmd):
                self.vars.devices_client.Send('{}{}'.format(cmd,self.__delim))