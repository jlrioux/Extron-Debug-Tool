## Begin ControlScript Import --------------------------------------------------
from extronlib import event
from extronlib.device import UIDevice
from extronlib.device import ProcessorDevice
from extronlib.interface import *
from extronlib.ui import *
from extronlib.system import Timer, Wait, File, SaveProgramLog
from datetime import datetime

import json

"""
Author: Jean-Luc Rioux
Company: Valley Communications
Last Modified Date: 2022-01-25
Version: 1.3

Changelog:
    v 1.0 - initial release
    v 1.1 - InterfaceWrapper : added support for SPIInterface
    v 1.2 - severe reworking :
        + added support for all interfaces in extronlib.interface except ClientObject and DanteInterface
        + reworked interface modules to make them easier to use, no longer require listening_port or friendly_name
            - these will be auto-generated for you if not supplied
    v 1.2.1 - some corrections to interface type handling.
    v 1.2.2 - added pacing when registering interfaces with debug client.
    v 1.3   - debug tool.py and client modifications.
        - debug client program now closes more gracefully upon exit.
        - for writestatus and set commands in debug tool, we now have type selection
        - corrected an issue preventing options from showing for SSH connections in client
        - corrected a typo in StatusReport class preventing the server from starting
    v 1.4   - debug tool.py and client modifications
        -added support for ProcessorDevice
        -added support for UIDevice
        -added support for VirtualUI
        -added disconnect function
        -added 'Save Current Logs' and 'Save Current Status' functions
        -added 'Save All Logs' and 'Save All Status' functions
        -cleaned up some formatting

"""






"""
This class creates a listening server to assist in debugging communication.
This module supports MULTIPLE receivedata functions.
This can be useful if you wish to parse feedback outside the module.
It also automatically impliments the subscribe helper class.
For Ethernet, SSH, and Serial Over Ethernet connections, this class automatically maintains the connection for you.
reattempting every 10 seconds.


INSTRUCTIONS on integrating with an Extron authored module, top-down:
1.  No modifications to Extron's device module in nearly all cases.
2.  Implement the module as below:
    from tools import DebugServer,EthernetModuleWrapper
    DebugServer.EnableDebugServer('LAN') # include this line to enable collective debugging on a single port. options 'LAN','AVLAN'
    from opto_vp_UHD60_v1_0_1_0 import DeviceClass as projector_mod
    dev_projector = EthernetModuleWrapper(projector_mod,friendly_name='Projector')
    dev_projector.Create_Device('10.0.0.87',2023,Model='UHD60')
3.  Implement interface ports as below:
    relay = RelayInterfaceWrapper(Processor, 'RLY1')
    fio = FlexIOInterfaceWrapper(Processor,'FIO1')
    dio = DigitalIOInterfaceWrapper(Processor,'DIO1')
    di = DigitalInputInterfaceWrapper(Processor,'DII1')
    c = ContactInterfaceWrapper(Processor,'CII1')
3.  Implement control and feedback normally.

NOTES:
 - The listening_port must be unique for each device implemented this way, the module handles this itself. the parameter still exists for backwards compatibility.
 - for module wrappers
    - In constructor, set auto_maintain_connection to False if you wish to handle network connections yourself.
    - In constructor, set time_between_commands to an integer > 0 to force command pacing to prevent device from choking on input. Do this after subscribing to feedback for the device.
"""

class DebugServer():    #class code
    __debug_server = None #type:EthernetServerInterfaceEx
    __debug_instances = {}
    __debug_server_buffer = ''
    __debug_server_password = 'p9oai23jr09p8fmvw98foweivmawthapw4t'
    __debug_server_logged_in = False
    __delim = '~END~\x0a'
    __debug_busy = False
    __debug_send_interface_list_timer = None

    def EnableDebugServer(Interface='AVLAN'):
        if not DebugServer.__debug_server:
            DebugServer.__debug_server = EthernetServerInterfaceEx(1988,'TCP',Interface=Interface,MaxClients=5)
            __debug_res = DebugServer.__debug_server.StartListen()
            if __debug_res != 'Listening':
                print('DebugServer EnableDebugServer: Failed : {}'.format(__debug_res))
            else:
                print('DebugServer EnableDebugServer: Succeeded on port {}'.format(Interface))

            @event(DebugServer.__debug_server, 'ReceiveData')
            def HandheReceiveFromServer(client,data:'bytes'):
                DebugServer.__debug_server_buffer += data.decode()
                while DebugServer.__delim in DebugServer.__debug_server_buffer:
                    pos = DebugServer.__debug_server_buffer.index(DebugServer.__delim)
                    temp = DebugServer.__debug_server_buffer[:pos]
                    DebugServer.__debug_server_buffer = DebugServer.__debug_server_buffer[pos+len(DebugServer.__delim)-1]
                    #if 'ping()' not in temp:
                    #    print('Debug Tool Rx:{}'.format(temp))
                    if DebugServer.__debug_server_logged_in and '~Command~:' in temp:
                        pos = temp.index(':')
                        temp = temp[pos+1:]
                        pos = temp.index(':')
                        id = int(temp[:pos])
                        if id in DebugServer.__debug_instances.keys():
                            temp = temp[pos+1:]
                            DebugServer.__debug_instances[id]['instance'].HandleReceiveFromServer(None,temp)
                    elif DebugServer.__debug_server_logged_in and 'exit()' in temp:
                        for client in DebugServer.__debug_server.Clients:
                            client.Send('Disconnecting...{}'.format(DebugServer.__delim))
                            client.Disconnect()
                    elif DebugServer.__debug_server_password in temp:
                        DebugServer.__debug_server_logged_in = True
                        DebugServer.__send_interface_list(None)

                DebugServer.__debug_server_buffer = ''


            @event(DebugServer.__debug_server, 'Connected')
            def HandleClientConnect(interface, state):
                DebugServer.__debug_client_count = len(DebugServer.__debug_server.Clients)


            @event(DebugServer.__debug_server, 'Disconnected')
            def HandleClientDisconnect(interface, state):
                DebugServer.__debug_client_count = len(DebugServer.__debug_server.Clients)

    def DisableDebugServer():
        if DebugServer.__debug_server:
            DebugServer.__debug_server_logged_in = False
            DebugServer.__debug_server.StopListen()
            for client in DebugServer.__debug_server.Clients:
                client.Disconnect()
            DebugServer.__debug_sever = None
        print('DebugServer:DisableDebug: Complete')

    def __send_interface_list(self):
        if self == None:
            instances = DebugServer.__debug_instances
            server = DebugServer.__debug_server
            delim = DebugServer.__delim
        else:
            instances = self._DebugServer__debug_instances
            server = self._DebugServer__debug_server
            delim = self._DebugServer__delim
        def t(timer:'Timer',count:'int'):
            DebugServer.__debug_busy = True
            count = count-1
            result = {}
            keys = instances.keys()
            keys = list(keys)
            keys.sort()
            if count < len(keys):
                key = keys[count]
                result[key] = {}
                result[key]['name'] = instances[key]['name']
                result[key]['communication'] = {}
                interface = instances[key]['instance'].GetInterface()
                comm_type = instances[key]['instance'].GetInterfaceType()
                result[key]['type'] = comm_type
                result[key]['communication']['type'] = str(comm_type)
                if comm_type == 'Serial':
                    result[key]['status'] = instances[key]['instance'].device.Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['mode'] = str(interface.Mode)
                    result[key]['communication']['port'] = str(interface.Port)
                    result[key]['communication']['baud'] = '{},{},{},{}'.format(str(interface.Baud),str(interface.Data),str(interface.Parity),str(interface.Stop))
                elif comm_type in ['SerialOverEthernet','Ethernet','SSH']:
                    result[key]['status'] = instances[key]['instance'].device.Commands
                    result[key]['communication']['host'] = str(interface.Hostname)
                    result[key]['communication']['mode'] = str(interface.Protocol)
                    result[key]['communication']['port'] = str(interface.IPPort)
                    result[key]['communication']['serviceport'] = str(interface.ServicePort)
                    result[key]['communication']['credentials'] = str(interface.Credentials)
                elif comm_type == 'SPI':
                    result[key]['status'] = instances[key]['instance'].device.Commands
                    result[key]['communication']['host'] = str(interface.Host)
                elif comm_type == 'Circuit Breaker':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                elif comm_type == 'Contact':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                elif comm_type == 'Digital Input':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                    result[key]['communication']['pullup'] = str(interface.Pullup)
                elif comm_type == 'Digital IO':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                    result[key]['communication']['mode'] = str(interface.Mode)
                    result[key]['communication']['pullup'] = str(interface.Pullup)
                elif comm_type == 'Flex IO':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                    result[key]['communication']['mode'] = str(interface.Mode)
                    result[key]['communication']['pullup'] = str(interface.Pullup)
                    result[key]['communication']['upper'] = str(interface.Upper)
                    result[key]['communication']['lower'] = str(interface.Lower)
                elif comm_type == 'IR':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                    result[key]['communication']['file'] = str(interface.File)
                elif comm_type == 'PoE':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                elif comm_type == 'Relay':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                elif comm_type == 'SWAC Receptacle':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                elif comm_type == 'SW Power':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                elif comm_type == 'Tally':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                elif comm_type == 'Volume':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['host'] = str(interface.Host)
                    result[key]['communication']['port'] = str(interface.Port)
                elif comm_type == 'Processor':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['alias'] = str(interface.DeviceAlias)
                elif comm_type == 'UI':
                    result[key]['status'] = instances[key]['instance'].Commands
                    result[key]['communication']['alias'] = str(interface.DeviceAlias)
                elif comm_type == 'VirtualUI':
                    result[key]['status'] = instances[key]['instance'].Commands
                result2 = json.dumps(result)
                if server:
                    for client in server.Clients:
                        client.Send('~RegisterDevices~:{}{}'.format(result2,delim))
            else:
                DebugServer.__debug_busy = False
                timer.Stop()
                return
        if DebugServer.__debug_send_interface_list_timer == None:
            DebugServer.__debug_send_interface_list_timer = Timer(0.2,t)
        else:
            DebugServer.__debug_busy = False
            DebugServer.__debug_send_interface_list_timer.Restart()
    def __send_interface_status(self,listening_port:'int',update:'dict'):
        to_send = {str(listening_port):update}
        result = json.dumps(to_send)
        if self._DebugServer__debug_server:
            for client in self._DebugServer__debug_server.Clients:
                client.Send('~UpdateDevices~:{}:{}{}'.format(listening_port,result,self._DebugServer__delim))
    def __send_interface_communication(self,listening_port:'int',txt:'str'):
        if self._DebugServer__debug_server and self._DebugServer__debug_server_logged_in and not self._DebugServer__debug_busy:
            data = {listening_port:txt}
            for client in self._DebugServer__debug_server.Clients:
                client.Send('~UpdateDeviceComs~:{}{}'.format(json.dumps(data),self._DebugServer__delim))
    def __add_instance(self,listening_port:'int',instance:'object',friendly_name:'str',instance_type:'str'):
        if listening_port not in self._DebugServer__debug_instances.keys():
            self._DebugServer__debug_instances[listening_port] = {}
            self._DebugServer__debug_instances[listening_port]['name'] = friendly_name
            self._DebugServer__debug_instances[listening_port]['instance'] = instance
            self._DebugServer__debug_instances[listening_port]['type'] = instance_type
            self._DebugServer__send_interface_list()
    def __create_listening_port(self):
        return 1+len(self._DebugServer__debug_instances)
class __InterfaceWrapper(DebugServer):
    def __init__(self,device_module,listening_port=0,friendly_name='',auto_maintain_connection=True,time_between_commands=0):
        self.__friendly_name = friendly_name
        self.__model = None
        self.device_module = device_module
        self.__sendandwait_busy = False
        self.__commands_to_send = [] #type:list[str]
        self.__t_command_pacer = None #type:Timer
        self.__interface_type = None
        self.__interface_allow_connection = False
        self.__interface_connect_status = ''
        self.__auto_maintain_connection = auto_maintain_connection
        self.__interface_type = None
        self.__receiveBufferCallbacks = []
        self.__listening_port = listening_port

        self.device = None

        if time_between_commands > 0:
            self.__t_command_pacer = Timer(time_between_commands,self.__fn_t_command_pacer())
            self.__t_command_pacer.Restart()

    def __fn_device_init(self,connectiontype:'str',interface):
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)
        mod = self.device_module
        self.__interface = interface
        class devclass(mod):
            def __init__(self):
                conntype = connectiontype
                if connectiontype == 'SerialOverEthernet':
                    conntype = 'Serial'
                if connectiontype == 'SSH':
                    conntype = 'Ethernet'
                self.ConnectionType = conntype
                mod.__init__(self)
        self.device = devclass()
        self.device.Send = self.Send
        self.device.SendAndWait = self.SendAndWait
        self.__subscriber = ModuleSubscribeWrapper(self.device)
        self.device.SubscribeStatus = self.__subscriber.SubscribeStatus
        self.device.NewStatus = self.__replacement_newstatus
        self.device.Update = self.__replacement_update
        self.device.Set = self.__replacement_set
        self.device.Error = self.__replacement_error
        self.device.Discard = self.__replacement_discard
        if hasattr(self.device,'ReceiveData'):
            self.__receiveBufferCallbacks.append(self.device.ReceiveData)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)
        # Check if Model belongs to a subclass
        Model = self.__model
        if len(self.device.Models) > 0:
            if Model not in self.device.Models:
                print('Model mismatch')
            else:
                self.device.Models[Model]()
        self.device.OnDisconnected()
        self._InterfaceWrapper__startInterfaceEvents()
        if self.__interface_type in ['Ethernet','SerialOverEthernet','SPI']:
            self._InterfaceWrapper__startNetworkInterfaceEvents()

    def __fn_t_command_pacer(self):
        def t(timer,count):
            if self.__sendandwait_busy:
                return
            if len(self.__commands_to_send):
                cmd = self.__commands_to_send.pop()
                self.__printToServer('>>{0}'.format(cmd))
                self.__interface.Send(cmd)
        return t

    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)
    def __eval_string(self,text:'str'):
        text.replace('\\r','\\x0d')
        text.replace('\\n','\\x0a')
        while '\\x' in text:
            pos = text.find('\\x')
            temp = text[pos:pos+4]
            val = int(temp[2:],16)
            char = chr(val)
            text = text.replace(temp,char)
        return text

    def __startInterfaceEvents(self):
        if self.__interface is not None:
            #@event(self.__interface, 'ReceiveData')
            def HandleReceiveFromInterface(interface,data):
                if data == None:
                    data = b''
                if data == None:
                    data = b''
                try:
                    decoded_data = data.decode()
                except:
                    data = b'failed to decode data'
                self.__printToServer('<<{}'.format(decoded_data))
                for function in self.__receiveBufferCallbacks:
                    function(self.__interface,data)
            self.__interface.ReceiveData = HandleReceiveFromInterface
    def __startNetworkInterfaceEvents(self):
        @event(self.__interface,'Connected')
        def connecthandler(interface,state):
            self.__interface_connect_status = state
            print('__InterfaceWrapper:{}:network device {} {}'.format(self.__friendly_name,interface.Hostname,state))
            self.device.OnConnected()
        #self.__interface.Disconnected = self.__network_connection_disconnected()
        @event(self.__interface,'Disconnected')
        def connecthandler(interface,state):
            self.__interface_connect_status = state
            print('__InterfaceWrapper:{}:network device {} {}'.format(self.__friendly_name,interface.Hostname,state))
            self.device.OnDisconnected()

        if self.__auto_maintain_connection:
            self.__t_network_maintain = Timer(10,self.__network_connection_timer_function())

    def __network_connection_timer_function(self):
        def t(timer,count):
            if self.__interface:
                if self.__interface_connect_status != 'Connected' and self.__interface_allow_connection:
                    self.__interface.Connect()
        return t

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
            #print('module recieve data:{}'.format(data.decode()))
        except:
            serverBuffer += data
            #print('module recieve data:{}'.format(data))
        if 'Reinit()' in serverBuffer:
            try:
                if self.device.ConnectionType == 'Serial':
                    self.device.OnDisconnected()
                else:
                    self.__interface.Disconnect()
            except:
                self.device.OnDisconnected()
        elif 'Set(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            temp_dict = {}
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse set command:{}'.format(e))
            cmd = ''
            if 'command' in temp_dict:
                cmd = temp_dict['command']
            value = ''
            if 'value' in temp_dict:
                value = temp_dict['value']
                if 'valuetype' in temp_dict:
                    if temp_dict['valuetype'] == 'Float':
                        try:
                            value = float(value)
                            if '-' in temp_dict['value'] and value > 0:
                                value = value * -1
                        except:
                            print('could not convert value to float')
            qualifier = None
            if 'qualifier' in temp_dict:
                qualifier = temp_dict['qualifier']
            if self.device != None:
                if qualifier is not None:
                    self.device.Set(cmd,value,qualifier)
                else:
                    self.device.Set(cmd,value)
        elif 'Update(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            temp_dict = {}
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse set command:{}'.format(e))
            cmd = ''
            if 'command' in temp_dict:
                cmd = temp_dict['command']
            value = ''
            if 'value' in temp_dict:
                value = temp_dict['value']
            qualifier = None
            if 'qualifier' in temp_dict:
                qualifier = temp_dict['qualifier']
            if self.device != None:
                if qualifier is not None:
                    self.device.Update(cmd,qualifier)
                else:
                    self.device.Update(cmd)
        elif 'WriteStatus(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            temp_dict = {}
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse set command:{}'.format(e))
            cmd = ''
            if 'command' in temp_dict:
                cmd = temp_dict['command']
            value = ''
            if 'value' in temp_dict:
                value = temp_dict['value']
                if 'valuetype' in temp_dict:
                    if temp_dict['valuetype'] == 'Float':
                        try:
                            value = float(value)
                            if '-' in temp_dict['value'] and value > 0:
                                value = value * -1
                        except:
                            print('could not convert value to float')
            qualifier = None
            if 'qualifier' in temp_dict:
                qualifier = temp_dict['qualifier']
            if self.device != None:
                if qualifier is not None:
                    self.device.WriteStatus(cmd,value,qualifier)
                else:
                    self.device.WriteStatus(cmd,value)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    @property
    def Device(self):
        return self.__interface
    @property
    def DeviceModule(self):
        return self.device_module

    def __replacement_newstatus(self,command,value,qualifier):
        update = {'command':command,'value':value,'qualifier':qualifier}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'event: Module({}) ~ {}({},{})'.format(self.__friendly_name,command,value,qualifier)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__subscriber.NewStatus(command,value,qualifier)
    def __replacement_error(self,message:'str'):
        print('Module: {}'.format(self.__friendly_name), 'Error Message: {}'.format(message), sep='\r\n')
    def __replacement_discard(self,message:'str'):
        print('Module: {}'.format(self.__friendly_name), 'Error Message: {}'.format(message), sep='\r\n')
    def __replacement_set(self, command, value, qualifier=None):
        try:
            method = getattr(self.DeviceModule, 'Set%s' % command)
        except:
            print('Module: {} : No method found for Set:{}'.format(self.__friendly_name,command))
            return
        if method is not None and callable(method):
            if self.__interface_type == 'Serial':
                method(self.device,value, qualifier)
            elif self.device.connectionFlag:
                method(self.device,value, qualifier)
        else:
            print(command, 'does not support Set.')
    def __replacement_update(self, command, qualifier=None):
        try:
            method = getattr(self.DeviceModule, 'Update%s' % command)
        except:
            print('Module: {} : No method found for Update:{}'.format(self.__friendly_name,command))
            return
        if method is not None and callable(method):
            if self.__interface_type == 'Serial':
                method(self.device,None, qualifier)
            elif self.device.connectionFlag:
                method(self.device,None, qualifier)
        else:
            print(command, 'does not support Update.')

    def Send(self, data):
        if self.__interface is not None:
            if self.__t_command_pacer:
                self.__commands_to_send.insert(0,data)
                return
            self.__printToServer('>>{0}'.format(data))
            self.__interface.Send(data)
        else:
            print('attempting to send but interface for port {} not defined'.format(self.__listening_port))
    def SendAndWait(self,commandstring,timeout=0.5,**args):
        if self.__interface is not None:
            self.__sendandwait_busy = True
            self.__printToServer('>>{0}'.format(commandstring))
            ret = self.__interface.SendAndWait(commandstring,timeout,**args)
            try:
                ret2 = ret.decode()
            except:
                ret2 = ''
            self.__printToServer('<<{0}'.format(ret2))
            self.__sendandwait_busy = False
        else:
            print('attempting to send and wait but interface for port {} not defined'.format(self.__listening_port))
            return b''
        return ret
    def Disconnect(self):
        if self.device:
            if self.device.ConnectionType in ['Ethernet','SerialOverEthernet','SSH']:
                str_to_send = 'command: Module({}) ~ Disconnect'.format(self.__friendly_name)
                print(str_to_send)
                self.__printToServer(str_to_send)
                self.__interface.Disconnect()
            self.device.OnDisconnected()
    def Connect(self):
        if self.device:
            if self.device.ConnectionType in ['Ethernet','SerialOverEthernet','SSH']:
                str_to_send = 'command: Module({}) ~ Connect'.format(self.__friendly_name)
                print(str_to_send)
                self.__printToServer(str_to_send)
                self.__interface_allow_connection = True
                self.__interface.Connect()
    def OnConnected(self):
        self.device.OnConnected()
    def OnDisconnected(self):
        self.device.OnDisconnected()
    def Set(self, command, value, qualifier=None):
        str_to_send = 'command: Module({}) ~ Set{}({},{})'.format(self.__friendly_name,command,value,qualifier)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.device.Set(command,value,qualifier)
    def Update(self, command, qualifier=None):
        str_to_send = 'command: Module({}) ~ Update{}({})'.format(self.__friendly_name,command,qualifier)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.device.Update(command,qualifier)
    def ReadStatus(self, command, qualifier=None):
        value = self.device.ReadStatus(command,qualifier)
        return value
    def SubscribeStatus(self, command, qualifier=None, callback=None):
        if callback is not None:
            self.device.SubscribeStatus(command,qualifier,callback)

    def addReceiveBufferCallback(self,function):
        self.receiveBuff__receiveBufferCallbackserCallbacks.append(function)
    def removeReceiveBufferCallback(self,function):
        self.__receiveBufferCallbacks.remove(function)
class SerialModuleWrapper(__InterfaceWrapper):
    def Create_Device(self, Host, Port, Baud=9600, Data=8, Parity='None', Stop=1, FlowControl='Off', CharDelay=0, Mode='RS232', Model =None):
        self._InterfaceWrapper__interface_type = 'Serial'
        self._InterfaceWrapper__model = Model
        class SerialClass(SerialInterface):
            def __init__(self, Host, Port, Baud=9600, Data=8, Parity='None', Stop=1, FlowControl='Off', CharDelay=0, Mode='RS232'):
                SerialInterface.__init__(self, Host, Port, Baud, Data, Parity, Stop, FlowControl, CharDelay, Mode)
            def Error(self, message):
                portInfo = 'Host Alias: {0}, Port: {1}'.format(self.Host.DeviceAlias, self.Port)
                print('Module: {}'.format(__name__), portInfo, 'Error Message: {}'.format(message[0]), sep='\r\n')
            def Discard(self, message):
                self.Error([message])
        interface = SerialClass(Host, Port, Baud, Data, Parity, Stop, FlowControl, CharDelay, Mode)
        self._InterfaceWrapper__fn_device_init('Serial',interface)
class SerialOverEthernetModuleWrapper(__InterfaceWrapper):
    def Create_Device(self, Hostname, IPPort, Protocol='TCP', ServicePort=0, Model=None):
        self._InterfaceWrapper__interface_type = 'SerialOverEthernet'
        self._InterfaceWrapper__model = Model
        class SerialOverEthernetClass(EthernetClientInterface):
            def __init__(self, Hostname, IPPort, Protocol='TCP', ServicePort=0):
                EthernetClientInterface.__init__(self, Hostname, IPPort, Protocol, ServicePort)
            def Error(self, message):
                portInfo = 'IP Address/Host: {0}:{1}'.format(self.Hostname, self.IPPort)
                print('Module: {}'.format(__name__), portInfo, 'Error Message: {}'.format(message[0]), sep='\r\n')
            def Discard(self, message):
                self.Error([message])
            def Disconnect(self):
                EthernetClientInterface.Disconnect(self)
        interface = SerialOverEthernetClass(Hostname, IPPort, Protocol, ServicePort)
        self._InterfaceWrapper__fn_device_init('SerialOverEthernet',interface)
class EthernetModuleWrapper(__InterfaceWrapper):
    def Create_Device(self, Hostname, IPPort, Protocol='TCP', ServicePort=0, Model=None):
        self._InterfaceWrapper__interface_type = 'Ethernet'
        self._InterfaceWrapper__model = Model
        class EthernetClass(EthernetClientInterface):
            def __init__(self, Hostname, IPPort, Protocol='TCP', ServicePort=0):
                EthernetClientInterface.__init__(self, Hostname, IPPort, Protocol, ServicePort)
            def Error(self, message):
                portInfo = 'IP Address/Host: {0}:{1}'.format(self.Hostname, self.IPPort)
                print('Module: {}'.format(__name__), portInfo, 'Error Message: {}'.format(message[0]), sep='\r\n')
            def Discard(self, message):
                self.Error([message])
            def Disconnect(self):
                EthernetClientInterface.Disconnect(self)
        interface = EthernetClass(Hostname, IPPort, Protocol, ServicePort)
        self._InterfaceWrapper__fn_device_init('Ethernet',interface)
class SSHModuleWrapper(__InterfaceWrapper):
    def Create_Device(self, Hostname, IPPort, Protocol='SSH', ServicePort=0, Credentials=(None), Model=None):
        self._InterfaceWrapper__interface_type = 'SSH'
        self._InterfaceWrapper__model = Model
        class SSHClass(EthernetClientInterface):
            def __init__(self, Hostname, IPPort, Protocol='SSH', ServicePort=0, Credentials=(None)):
                EthernetClientInterface.__init__(self, Hostname, IPPort, Protocol, ServicePort, Credentials)
            def Error(self, message):
                portInfo = 'IP Address/Host: {0}:{1}'.format(self.Hostname, self.IPPort)
                print('Module: {}'.format(__name__), portInfo, 'Error Message: {}'.format(message[0]), sep='\r\n')
            def Discard(self, message):
                self.Error([message])
            def Disconnect(self):
                EthernetClientInterface.Disconnect(self)
        interface = SSHClass(Hostname, IPPort, Protocol, ServicePort, Credentials)
        self._InterfaceWrapper__fn_device_init('SSH',interface)
class SPIModuleWrapper(__InterfaceWrapper):
    def Create_Device(self, spi, Model=None):
        self._InterfaceWrapper__interface_type = 'SPI'
        self._InterfaceWrapper__model = Model
        class SPIClass(SPInterface):
            def __init__(self, spd):
                SPInterface.__init__(self, spd)
            def Error(self, message):
                print('Module: {}'.format(__name__), 'Error Message: {}'.format(message[0]), sep='\r\n')
            def Discard(self, message):
                self.Error([message])
            def Disconnect(self):
                self.OnDisconnected()
        interface = SPIClass(spi)
        self._InterfaceWrapper__fn_device_init('Serial',interface) #spi modules use serial type apparently
class CircuitBreakerInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='CBR1',listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'Circuit Breaker'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []
        self.__statechanged_event_callbacks = []

        self.__interface = CircuitBreakerInterface(Host,Port)
        self.Commands = {
            'State': {'Status': {'Live':self.__interface.State}},
            'OnlineStatus':{'Status':{}}
            }


        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: CircuitBreakerInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: CircuitBreakerInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        @event(self.__interface,'StateChanged')
        def handleOnline(interface,state):
            self.Commands['State']['Status']['Live'] = state
            update = {'command':'State','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: CircuitBreakerInterface({}) ~ State {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__statechanged_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)
        if command == 'StateChanged':
            self.__statechanged_event_callbacks.append(function)

    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def State(self):
        return self.__interface.State

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
class ContactInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='CII1',listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'Contact'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []
        self.__statechanged_event_callbacks = []

        self.__interface = ContactInterface(Host,Port)
        self.Commands = {
            'State': {'Status': {'Live':self.__interface.State}},
            'OnlineStatus':{'Status':{}}
            }


        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: ContactInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: ContactInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        @event(self.__interface,'StateChanged')
        def handleOnline(interface,state):
            self.Commands['State']['Status']['Live'] = state
            update = {'command':'State','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: ContactInterface({}) ~ State {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__statechanged_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)
        if command == 'StateChanged':
            self.__statechanged_event_callbacks.append(function)

    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def State(self):
        return self.__interface.State

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
class DigitalInputInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='DII1',Pullup:'bool'=False,listening_port:'int'='',friendly_name:'str'=''):
        self.__interface_type = 'Digital Input'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []
        self.__statechanged_event_callbacks = []

        self.__interface = DigitalInputInterface(Host,Port,Pullup)
        self.Commands = {
            'State': {'Status': {'Live':self.__interface.State}},
            'OnlineStatus':{'Status':{}}
            }


        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: DigitalInputInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: DigitalInputInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        @event(self.__interface,'StateChanged')
        def handleOnline(interface,state):
            self.Commands['State']['Status']['Live'] = state
            update = {'command':'State','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: DigitalInputInterface({}) ~ State {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__statechanged_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)
        if command == 'StateChanged':
            self.__statechanged_event_callbacks.append(function)

    def Initialize(self,Pullup=None):
        if Pullup!=None:
            self.__interface.Initialize(Pullup=Pullup)
            str_to_send = 'command: DigitalInputInterface({}) ~ Initialize({})'.format(self.__friendly_name,Pullup)
            print(str_to_send)
            self.__printToServer(str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def State(self):
        return self.__interface.State
    @property
    def Pullup(self):
        return self.__interface.Pullup

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
            #print('module recieve data:{}'.format(data.decode()))
        except:
            serverBuffer += data
            #print('module recieve data:{}'.format(data))

        if 'Initialize(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temps = [temp_dict['value1']]
            if self.__interface:
                self.Initialize(temps[0])

    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)
class DigitalIOInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='DIO1',Mode:'str'='DigitalInput',Pullup:'bool'=False,listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'Digital IO'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []
        self.__statechanged_event_callbacks = []

        self.__interface = DigitalIOInterface(Host,Port,Mode,Pullup)
        self.Commands = {
            'State': {'Status': {'Live':self.__interface.State}},
            'OnlineStatus':{'Status':{}}
            }


        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: DigitalIOInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: DigitalIOInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        @event(self.__interface,'StateChanged')
        def handleOnline(interface,state):
            self.Commands['State']['Status']['Live'] = state
            update = {'command':'State','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: DigitalIOInterface({}) ~ State {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__statechanged_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def Initialize(self,Mode=None,Pullup=None):
        if Mode!=None:
            self.__interface.Initialize(Mode=Mode)
        if Pullup!=None:
            self.__interface.Initialize(Pullup=Pullup)
        str_to_send = 'command: DigitalIOInterface({}) ~ Initialize({},{})'.format(self.__friendly_name,Mode,Pullup)
        print(str_to_send)
        self.__printToServer(str_to_send)

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)
        if command == 'StateChanged':
            self.__statechanged_event_callbacks.append(function)

    def Pulse(self,duration):
        self.__interface.Pulse(duration)
        self.__printToServer('Pulse : duration {}'.format(duration))
        self.Commands['State']['Status']['Live'] = 'On'
        update = {'command':'State','value':'On','qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: DigitalIOInterface({}) ~ Pulse(On)'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        @Wait(duration)
        def w():
            self.Commands['State']['Status']['Live'] = 'Off'
            update = {'command':'State','value':'Off','qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'command: DigitalIOInterface({}) ~ Pulse(Off)'.format(self.__friendly_name)
            print(str_to_send)
            self.__printToServer(str_to_send)
    def SetState(self,State):
        self.__interface.SetState(State)
        self.__printToServer('Set {}'.format(State))
        states = {'Off':'Off','On':'On',0:'Off',1:'On'}
        self.Commands['State']['Status']['Live'] = states[State]
        update = {'command':'State','value':states[State],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: DigitalIOInterface({}) ~ SetState({})'.format(self.__friendly_name,states[State])
        print(str_to_send)
        self.__printToServer(str_to_send)
    def Toggle(self):
        self.__interface.Toggle()
        self.__printToServer('Toggle')
        states = {'On':'Off','Off':'On'}
        self.Commands['State']['Status']['Live'] = states[self.Commands['State']['Status']['Live']]
        update = {'command':'State','value':states[self.Commands['State']['Status']['Live']],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: DigitalIOInterface({}) ~ Toggle()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def State(self):
        return self.__interface.State
    @property
    def Mode(self):
        return self.__interface.Mode
    @property
    def Pullup(self):
        return self.__interface.Pullup

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
            #print('module recieve data:{}'.format(data.decode()))
        except:
            serverBuffer += data
            #print('module recieve data:{}'.format(data))
        if 'State(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp = temp_dict['value1']
            if temp in ['0','1']:
                temp = int(temp)
            if self.__interface and temp in [0,1,'On','Off']:
                self.SetState(temp)
        if 'Pulse(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp = float(temp_dict['value1'])
            if self.__interface:
                self.Pulse(temp)
        if 'Initialize(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temps = [temp_dict['value1'],temp_dict['value2']]
            if self.__interface:
                self.Initialize(temps[0],temps[1])
        if 'Toggle()' in serverBuffer:
            if self.__interface:
                self.Toggle()
class FlexIOInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='DIO1',Mode:'str'='DigitalInput',Pullup:'bool'=False,Upper:'float'=2.8,Lower:'float'=2.0,listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'Flex IO'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []
        self.__statechanged_event_callbacks = []
        self.__analogvoltagechanged_event_callbacks = []

        self.__interface = FlexIOInterface(Host,Port,Mode,Pullup,Upper,Lower)
        self.Commands = {
            'State': {'Status': {'Live':self.__interface.State}},
            'OnlineStatus':{'Status':{}},
            'AnalogVoltage':{'Status':{'Live':self.__interface.AnalogVoltage}}
            }


        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: FlexIOInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: FlexIOInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        @event(self.__interface,'StateChanged')
        def handleOnline(interface,state):
            self.Commands['State']['Status']['Live'] = state
            update = {'command':'State','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: FlexIOInterface({}) ~ State {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__statechanged_event_callbacks:
                f(interface,state)
        @event(self.__interface,'AnalogVoltageChanged')
        def handleOnline(interface,state):
            self.Commands['AnalogVoltage']['Status']['Live'] = state
            update = {'command':'AnalogVoltage','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: FlexIOInterface({}) ~ AnalogVoltage {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__statechanged_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def Initialize(self,Mode=None,Pullup=None,Upper=None,Lower=None):
        if Mode!=None:
            self.__interface.Initialize(Mode=Mode)
        if Pullup!=None:
            self.__interface.Initialize(Pullup=Pullup)
        if Upper!=None:
            self.__interface.Initialize(Upper=float(Upper))
        if Lower!=None:
            self.__interface.Initialize(Lower=float(Lower))
        self.__printToServer('Initialize : Mode:{} Pullup:{} Upper:{} Lower:{}'.format(self.__interface.Mode,self.__interface.Pullup,self.__interface.Upper,self.__interface.Lower))

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)
        if command == 'StateChanged':
            self.__statechanged_event_callbacks.append(function)
        if command == 'AnalogVoltageChanged':
            self.__analogvoltagechanged_event_callbacks.append(function)

    def Pulse(self,duration):
        self.__interface.Pulse(duration)
        self.__printToServer('Pulse : duration {}'.format(duration))
        self.Commands['State']['Status']['Live'] = 'On'
        update = {'command':'State','value':'On','qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: FlexIOInterface({}) ~ Pulse(On)'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        @Wait(duration)
        def w():
            self.Commands['State']['Status']['Live'] = 'Off'
            update = {'command':'State','value':'Off','qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'command: FlexIOInterface({}) ~ Pulse(Off)'.format(self.__friendly_name)
            print(str_to_send)
            self.__printToServer(str_to_send)
    def SetState(self,State):
        self.__interface.SetState(State)
        self.__printToServer('Set {}'.format(State))
        states = {'Off':'Off','On':'On',0:'Off',1:'On'}
        self.Commands['State']['Status']['Live'] = states[State]
        update = {'command':'State','value':states[State],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: FlexIOInterface({}) ~ SetState({})'.format(self.__friendly_name,states[State])
        print(str_to_send)
        self.__printToServer(str_to_send)
    def Toggle(self):
        self.__interface.Toggle()
        self.__printToServer('Toggle')
        states = {'Off':'On','On':'Off'}
        self.Commands['State']['Status']['Live'] = states[self.Commands['State']['Status']['Live']]
        update = {'command':'State','value':states[self.Commands['State']['Status']['Live']],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: FlexIOInterface({}) ~ Toggle()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def State(self):
        return self.__interface.State
    @property
    def Mode(self):
        return self.__interface.Mode
    @property
    def Pullup(self):
        return self.__interface.Pullup
    @property
    def Upper(self):
        return self.__interface.Upper
    @property
    def Lower(self):
        return self.__interface.Lower
    @property
    def AnalogVoltage(self):
        return self.__interface.AnalogVoltage

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
            #print('module recieve data:{}'.format(data.decode()))
        except:
            serverBuffer += data
            #print('module recieve data:{}'.format(data))
        if 'State(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp = temp_dict['value1']
            if temp in ['0','1']:
                temp = int(temp)
            if self.__interface and temp in [0,1,'On','Off']:
                self.SetState(temp)
        if 'Pulse(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp=temp_dict['value1']
            temp = float(temp)
            if self.__interface:
                self.Pulse(temp)
        if 'Initialize(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temps = [temp_dict['value1'],temp_dict['value2'],temp_dict['value3'],temp_dict['value4']]
            if self.__interface:
                self.Initialize(temps[0],temps[1],temps[2],temps[3])
        if 'Toggle()' in serverBuffer:
            if self.__interface:
                self.Toggle()
class IRInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='IRS1',File:'str'='',listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'IR'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []

        self.Commands = {
            'OnlineStatus':{'Status':{}},
            'File':{'Status':{'Live':File}}
            }

        self.__interface = IRInterface(Host,Port,File)

        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Online'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: IRInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Offline'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: IRInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def Initialize(self,File=None):
        if File!=None:
            self.__interface.Initialize(File=File)
        self.__printToServer('Initialize : Mode:{} '.format(self.__interface.File))

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)

    def PlayContinuous(self,irFunction):
        self.__interface.PlayContinuous(irFunction)
        self.Commands['LastCommand']['Status']['Live'] = irFunction
        str_to_send = 'command: IRInterface({}) ~ PlayContinuous({})'.format(self.__friendly_name,irFunction)
        print(str_to_send)
        self.__printToServer(str_to_send)
    def PlayCount(self,irFunction,repeatCount=None):
        self.__interface.PlayCount(irFunction,repeatCount)
        self.Commands['LastCommand']['Status']['Live'] = irFunction
        str_to_send = 'command: IRInterface({}) ~ PlayCount({},{})'.format(self.__friendly_name,irFunction,repeatCount)
        print(str_to_send)
        self.__printToServer(str_to_send)
    def PlayTime(self,irFunction,duration=None):
        self.__interface.PlayTime(irFunction,duration)
        self.Commands['LastCommand']['Status']['Live'] = irFunction
        str_to_send = 'command: IRInterface({}) ~ PlayTime({},{})'.format(self.__friendly_name,irFunction,duration)
        print(str_to_send)
        self.__printToServer(str_to_send)
    def Stop(self):
        self.__interface.Stop()
        self.Commands['LastCommand']['Status']['Live'] = 'Close'
        str_to_send = 'command: IRInterface({}) ~ Stop()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)

    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def File(self):
        return self.__interface.File

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
            #print('module recieve data:{}'.format(data.decode()))
        except:
            serverBuffer += data
            #print('module recieve data:{}'.format(data))
        if 'PlayContinuous(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            if self.__interface:
                self.PlayContinuous(temp_dict['value1'])
        elif 'PlayCount(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temps = [temp_dict['value1'],temp_dict['value2']]
            if len(temps) == 1:
                temps.append(None)
            elif temps[1] == 'None':
                temps[1] = None
            else:
                temps[1] = int(temps[1])
            if self.__interface:
                self.PlayCount(temps[0],temps[1])
        elif 'PlayTime(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temps = [temp_dict['value1'],temp_dict['value2']]
            if self.__interface:
                self.PlayTime(temps[0],float(temps[1]))
        elif 'Stop()' in serverBuffer:
            if self.__interface:
                self.Stop()
        elif 'Initialize(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temps = [temp_dict['value1']]
            if self.__interface:
                self.Initialize(temps[0])
class PoEInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='POE1',listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'PoE'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []
        self.__powerstatuschanged_event_callbacks = []

        self.__currentload = None

        self.__interface = PoEInterface(Host,Port)
        self.Commands = {
            'State': {'Status': {'Live':self.__interface.State}},
            'PowerStatus':{'Status':{'Live':self.__interface.PowerStatus}},
            'CurrentLoad':{'Status':{'Live':self.__interface.CurrentLoad}},
            'OnlineStatus':{'Status':{}}
            }


        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: PoEInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: PoEInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        @event(self.__interface,'PowerStatusChanged')
        def handleOnline(interface,state):
            self.Commands['PowerStatus']['Status']['Live'] = state
            update = {'command':'PowerStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: PoEInterface({}) ~ PowerStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__powerstatuschanged_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)
        @Timer(1)
        def t(timer,count):
            if self.__currentload != self.__interface.CurrentLoad:
                self.__currentload = self.__interface.CurrentLoad
                self.Commands['CurrentLoad']['Status']['Live'] = str(self.__interface.CurrentLoad)
                update = {'command':'CurrentLoad','value':str(self.__interface.CurrentLoad),'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)

    def SetState(self,State):
        self.__interface.SetState(State)
        self.__printToServer('Set {}'.format(State))
        states = {'On':'On','Off':'Off',0:'Off',1:'On'}
        self.Commands['State']['Status']['Live'] = states[State]
        update = {'command':'State','value':states[State],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: PoEInterface({}) ~ SetState({})'.format(self.__friendly_name,states[State])
        print(str_to_send)
        self.__printToServer(str_to_send)
    def Toggle(self):
        self.__interface.Toggle()
        self.__printToServer('Toggle')
        states = {'On':'Off','Off':'On'}
        self.Commands['State']['Status']['Live'] = states[self.Commands['State']['Status']['Live']]
        update = {'command':'State','value':states[self.Commands['State']['Status']['Live']],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: PoEInterface({}) ~ Toggle()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def State(self):
        return self.__interface.State
    @property
    def CurrentLoad(self):
        return self.__interface.CurrentLoad
    @property
    def PowerStatus(self):
        return self.__interface.PowerStatus

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
            #print('module recieve data:{}'.format(data.decode()))
        except:
            serverBuffer += data
            #print('module recieve data:{}'.format(data))
        if 'State(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            vals = {'0':0,'1':1,'Off':0,'On':1}
            temp=vals[temp_dict['value1']]
            if self.__interface and temp in [0,1,'On','Off']:
                self.SetState(temp)
        if 'Toggle()' in serverBuffer:
            if self.__interface:
                self.Toggle()
class RelayInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='RLY1',listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'Relay'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []

        self.__interface = RelayInterface(Host,Port)
        self.Commands = {
            'State': {'Status': {'Live':self.__interface.State}},
            'OnlineStatus':{'Status':{}}
            }


        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Online'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: RelayInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Offline'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: RelayInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)

    def Pulse(self,duration):
        self.__interface.Pulse(duration)
        self.__printToServer('Pulse : duration {}'.format(duration))
        self.Commands['State']['Status']['Live'] = 'Close'
        update = {'command':'State','value':'Close','qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: RelayInterface({}) ~ Pulse(On)'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        @Wait(duration)
        def w():
            self.Commands['State']['Status']['Live'] = 'Open'
            update = {'command':'State','value':'Open','qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'command: RelayInterface({}) ~ Pulse(Off)'.format(self.__friendly_name)
            print(str_to_send)
            self.__printToServer(str_to_send)
    def SetState(self,State):
        self.__interface.SetState(State)
        self.__printToServer('Set {}'.format(State))
        states = {'Open':'Open','Close':'Close',0:'Open',1:'Close'}
        self.Commands['State']['Status']['Live'] = states[State]
        update = {'command':'State','value':states[State],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: RelayInterface({}) ~ SetState({})'.format(self.__friendly_name,states[State])
        print(str_to_send)
        self.__printToServer(str_to_send)
    def Toggle(self):
        self.__interface.Toggle()
        self.__printToServer('Toggle')
        states = {'Open':'Close','Close':'Open'}
        self.Commands['State']['Status']['Live'] = states[self.Commands['State']['Status']['Live']]
        update = {'command':'State','value':states[self.Commands['State']['Status']['Live']],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: RelayInterface({}) ~ Toggle()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def State(self):
        return self.__interface.State

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
            #print('module recieve data:{}'.format(data.decode()))
        except:
            serverBuffer += data
            #print('module recieve data:{}'.format(data))
        if 'State(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            vals = {'0':0,'1':1,'Open':0,'Close':1}
            temp=vals[temp_dict['value1']]
            if self.__interface:
                self.SetState(temp)
        if 'Pulse(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp = float(temp_dict['value1'])
            if self.__interface:
                self.Pulse(temp)
        if 'Toggle()' in serverBuffer:
            if self.__interface:
                self.Toggle()
class SWACReceptacleInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='SAC1',listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'SWAC Receptacle'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []
        self.__currentchanged_event_callbacks = []

        self.__interface = SWACReceptacleInterface(Host,Port)
        self.Commands = {
            'State': {'Status': {'Live':self.__interface.State}},
            'Current': {'Status': {'Live':self.__interface.Current}},
            'OnlineStatus':{'Status':{}}
            }


        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Online'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: SWACReceptacleInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Offline'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: SWACReceptacleInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        @event(self.__interface,'CurrentChanged')
        def handleOnline(interface,state):
            self.Commands['Current']['Status']['Live'] = str(state)
            update = {'command':'Current','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: SWACReceptacleInterface({}) ~ CurrentChanged {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)
        if command == 'CurrentChanged':
            self.__currentchanged_event_callbacks.append(function)
    def SetState(self,State):
        self.__interface.SetState(State)
        self.__printToServer('Set {}'.format(State))
        states = {'On':'On','Off':'Off',0:'Off',1:'On'}
        self.Commands['State']['Status']['Live'] = states[State]
        update = {'command':'State','value':states[State],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: SWACReceptacleInterface({}) ~ SetState({})'.format(self.__friendly_name,states[State])
        print(str_to_send)
        self.__printToServer(str_to_send)
    def Toggle(self):
        self.__interface.Toggle()
        self.__printToServer('Toggle')
        states = {'On':'Off','Off':'On'}
        self.Commands['State']['Status']['Live'] = states[self.Commands['State']['Status']['Live']]
        update = {'command':'State','value':states[self.Commands['State']['Status']['Live']],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: SWACReceptacleInterface({}) ~ Toggle()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def State(self):
        return self.__interface.State
    @property
    def Current(self):
        return self.__interface.Current

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
            #print('module recieve data:{}'.format(data.decode()))
        except:
            serverBuffer += data
            #print('module recieve data:{}'.format(data))
        if 'State(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            vals = {'0':0,'1':1,'Off':0,'On':1}
            temp=vals[temp_dict['value1']]
            if self.__interface and temp in [0,1,'On','Off']:
                self.SetState(temp)
        if 'Toggle()' in serverBuffer:
            if self.__interface:
                self.Toggle()
class SWPowerInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='SPI1',listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'SW Power'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []

        self.__interface = SWPowerInterface(Host,Port)
        self.Commands = {
            'State': {'Status': {'Live':self.__interface.State}},
            'OnlineStatus':{'Status':{}}
            }

        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Online'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: SWPowerInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Offline'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: SWPowerInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)

    def Pulse(self,duration):
        self.__interface.Pulse(duration)
        self.__printToServer('Pulse : duration {}'.format(duration))
        self.Commands['State']['Status']['Live'] = 'On'
        update = {'command':'State','value':'On','qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: SWPowerInterface({}) ~ Pulse(On)'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        @Wait(duration)
        def w():
            self.Commands['State']['Status']['Live'] = 'Off'
            update = {'command':'State','value':'Off','qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'command: SWPowerInterface({}) ~ Pulse(Off)'.format(self.__friendly_name)
            print(str_to_send)
            self.__printToServer(str_to_send)
    def SetState(self,State):
        self.__interface.SetState(State)
        self.__printToServer('Set {}'.format(State))
        states = {'On':'On','Off':'Off',0:'On',1:'Off'}
        self.Commands['State']['Status']['Live'] = states[State]
        update = {'command':'State','value':'Off','qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: SWPowerInterface({}) ~ State({})'.format(self.__friendly_name,states[State])
        print(str_to_send)
        self.__printToServer(str_to_send)
    def Toggle(self):
        self.__interface.Toggle()
        self.__printToServer('Toggle')
        states = {'On':'Off','Off':'On'}
        self.Commands['State']['Status']['Live'] = states[self.Commands['State']['Status']['Live']]
        update = {'command':'OnlineStatus','value':states[self.Commands['State']['Status']['Live']],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: SWPowerInterface({}) ~ Toggle()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def State(self):
        return self.__interface.State

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
            #print('module recieve data:{}'.format(data.decode()))
        except:
            serverBuffer += data
            #print('module recieve data:{}'.format(data))
        if 'State(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            vals = {'0':0,'1':1,'Off':0,'On':1}
            temp=vals[temp_dict['value1']]
            if self.__interface and temp in [0,1,'On','Off']:
                self.SetState(temp)
        if 'Pulse(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp = float(temp_dict['value1'])
            if self.__interface:
                self.Pulse(temp)
        if 'Toggle()' in serverBuffer:
            if self.__interface:
                self.Toggle()
class TallyInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='TAL1',listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'Tally'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []

        self.__interface = TallyInterface(Host,Port)
        self.Commands = {
            'State': {'Status': {'Live':self.__interface.State}},
            'OnlineStatus':{'Status':{}}
            }


        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: TallyInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: TallyInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)

    def Pulse(self,duration):
        self.__interface.Pulse(duration)
        self.__printToServer('Pulse : duration {}'.format(duration))
        self.Commands['State']['Status']['Live'] = 'On'
        update = {'command':'State','value':'On','qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: TallyInterface({}) ~ Pulse(On)'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        @Wait(duration)
        def w():
            self.Commands['State']['Status']['Live'] = 'Off'
            update = {'command':'State','value':'Off','qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'command: TallyInterface({}) ~ Pulse(Off)'.format(self.__friendly_name)
            print(str_to_send)
            self.__printToServer(str_to_send)
    def SetState(self,State):
        self.__interface.SetState(State)
        self.__printToServer('Set {}'.format(State))
        states = {'On':'On','Off':'Off',0:'On',1:'Off'}
        self.Commands['State']['Status']['Live'] = states[State]
        update = {'command':'State','value':states[State],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: TallyInterface({}) ~ State({})'.format(self.__friendly_name,states[State])
        print(str_to_send)
        self.__printToServer(str_to_send)
    def Toggle(self):
        self.__interface.Toggle()
        self.__printToServer('Toggle')
        states = {'On':'Off','Off':'On'}
        self.Commands['State']['Status']['Live'] = states[self.Commands['State']['Status']['Live']]
        update = {'command':'State','value':states[self.Commands['State']['Status']['Live']],'qualifier':None}
        self._DebugServer__send_interface_status(self.__listening_port,update)
        str_to_send = 'command: TallyInterface({}) ~ Toggle()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def State(self):
        return self.__interface.State

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
            #print('module recieve data:{}'.format(data.decode()))
        except:
            serverBuffer += data
            #print('module recieve data:{}'.format(data))
        if 'State(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            vals = {'0':0,'1':1,'Off':0,'On':1}
            temp=vals[temp_dict['value1']]
            if self.__interface and temp in [0,1,'On','Off']:
                self.SetState(temp)
        if 'Pulse(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp = float(temp_dict['value1'])
            if self.__interface:
                self.Pulse(temp)
        if 'Toggle()' in serverBuffer:
            if self.__interface:
                self.Toggle()
class VolumeInterfaceWrapper(DebugServer):
    def __init__(self,Host:'object',Port:'str'='VOL1',listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'Volume'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []

        self.__interface = VolumeInterface(Host,Port)
        self.__currentlevel = self.__interface.Level
        self.__currentmax = self.__interface.Max
        self.__currentmin = self.__interface.Min
        self.__currentsoftstart = self.__interface.SoftStart
        self.__currentmute = self.__interface.Mute

        self.Commands = {
            'Level':{'Status': {'Live':self.__interface.Level}},
            'Mute':{'Status': {'Live':self.__interface.Mute}},
            'Max':{'Status': {'Live':self.__interface.Max}},
            'Min':{'Status': {'Live':self.__interface.Min}},
            'SoftStart':{'Status': {'Live':self.__interface.SoftStart}},
            'OnlineStatus':{'Status':{}}
            }


        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Online'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: VolumeInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Offline'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: VolumeInterface({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

        @Timer(1)
        def t(timer,count):
            somethingchanged = False
            if self.__currentlevel != self.__interface.Level:
                somethingchanged = True
                self.__currentlevel = self.__interface.Level
                self.Commands['Level']['Status']['Live'] = self.__interface.Level
                update = {'command':'Level','value':self.Commands['Level']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: VolumeInterface({}) ~ Level {}'.format(self.__friendly_name,self.__currentlevel)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__currentmax != self.__interface.Max:
                somethingchanged = True
                self.__currentmax = self.__interface.Max
                self.Commands['Max']['Status']['Live'] = self.__interface.Max
                update = {'command':'Max','value':self.Commands['Max']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: VolumeInterface({}) ~ Max {}'.format(self.__friendly_name,self.__currentmax)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__currentmin != self.__interface.Min:
                somethingchanged = True
                self.__currentmin = self.__interface.Min
                self.Commands['Min']['Status']['Live'] = self.__interface.Min
                update = {'command':'Min','value':self.Commands['Min']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: VolumeInterface({}) ~ Min {}'.format(self.__friendly_name,self.__currentmin)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__currentmute != self.__interface.Mute:
                somethingchanged = True
                self.__currentmute = self.__interface.Mute
                self.Commands['Mute']['Status']['Live'] = self.__interface.Mute
                update = {'command':'Mute','value':self.Commands['Mute']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: VolumeInterface({}) ~ Mute {}'.format(self.__friendly_name,self.__currentmute)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__currentsoftstart != self.__interface.SoftStart:
                somethingchanged = True
                self.__currentsoftstart = self.__interface.SoftStart
                self.Commands['SoftStart']['Status']['Live'] = self.__interface.SoftStart
                update = {'command':'SoftStart','value':self.Commands['SoftStart']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: VolumeInterface({}) ~ SoftStart {}'.format(self.__friendly_name,self.__currentsoftstart)
                print(str_to_send)
                self.__printToServer(str_to_send)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)

    def SetLevel(self,Level):
        str_to_send = 'command: VolumeInterface({}) ~ SetLevel({})'.format(self.__friendly_name,Level)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetLevel(Level)
    def SetMute(self,Mute):
        str_to_send = 'command: VolumeInterface({}) ~ SetMute({})'.format(self.__friendly_name,Mute)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetMute(Mute)
    def SetRange(self,Min,Max):
        str_to_send = 'command: VolumeInterface({}) ~ SetRange({},{})'.format(self.__friendly_name,Min,Max)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetRange(Min,Max)
    def SetSoftStart(self,softstart):
        str_to_send = 'command: VolumeInterface({}) ~ SetSoftStart({})'.format(self.__friendly_name,softstart)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetSoftStart(softstart)
    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def Host(self):
        return self.__interface.Host
    @property
    def Port(self):
        return self.__interface.Port
    @property
    def Level(self):
        return self.__interface.Level
    @property
    def Max(self):
        return self.__interface.Max
    @property
    def Min(self):
        return self.__interface.Min
    @property
    def Mute(self):
        return self.__interface.Mute
    @property
    def SoftStart(self):
        return self.__interface.SoftStart

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
        except:
            serverBuffer += data
        if 'Mute(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            vals = {'0':0,'1':1,'Off':0,'On':1}
            temp=vals[temp_dict['value1']]
            if self.__interface and temp in [0,1,'On','Off']:
                self.SetMute(temp)
        if 'Level(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp = float(temp_dict['value1'])
            if self.__interface:
                self.SetLevel(temp)
        if 'Range(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temps = [temp_dict['value1'],temp_dict['value2']]
            if self.__interface:
                self.SetLevel(temps[0],temps[1])
        if 'SoftStart(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp = temp_dict['value1']
            if self.__interface:
                self.SoftStart(temp)
class ProcessorDeviceWrapper(DebugServer):
    def __init__(self,DeviceAlias:'str',PartNumber:'str'=None,listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'Processor'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []
        self.__combinedcurrent_event_callbacks = []
        self.__combinedloadstate_event_callbacks = []
        self.__combinedwattage_event_callbacks = []
        self.__executivemode_event_callbacks =[]

        self.__interface = ProcessorDevice(DeviceAlias,PartNumber) #type:ProcessorDevice
        self.device = self.__interface
        executivemode = 'Unavailable'
        combinedcurrent = 'Unavailable'
        combinedwattage = 'Unavailable'
        combinedloadstate = 'Unavailable'
        self.__model = self.__interface.ModelName
        if 'PCS1' in self.__model:
            executivemode = self.__interface.ExecutiveMode
            combinedcurrent = self.__interface.CombinedCurrent
            combinedwattage = self.__interface.CombinedWattage
            combinedloadstate = self.__interface.CombinedLoadState
        self.Commands = {
            'ExecutiveMode':{'Status': {'Live':executivemode}},
            'Reboot':{'Status': {}},
            'CombinedCurrent':{'Status': {'Live':combinedcurrent}},
            'CombinedWattage':{'Status': {'Live':combinedwattage}},
            'CombinedLoadState':{'Status': {'Live':combinedloadstate}},
            'SystemSettings':{'Status': {'Live':self.__interface.SystemSettings}},
            'OnlineStatus':{'Status':{}},
            'FirmwareVersion':{'Status':{'Live':self.__interface.FirmwareVersion}},
            'LinkLicenses':{'Status':{'Live':self.__interface.LinkLicenses}},
            'DeviceAlias':{'Status':{'Live':self.__interface.DeviceAlias}},
            'ModelName':{'Status':{'Live':self.__interface.ModelName}},
            'PartNumber':{'Status':{'Live':self.__interface.PartNumber}},
            'SerialNumber':{'Status':{'Live':self.__interface.SerialNumber}},
            'UserUsage':{'Status':{'Live':self.__interface.UserUsage}},
            }

        self.__systemsettings = self.__interface.SystemSettings
        self.__userusage = self.__interface.UserUsage

        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: Processor({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = state
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: Processor({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        if hasattr(self.__interface,'CombinedCurrentChanged'):
            @event(self.__interface,'CombinedCurrentChanged')
            def handleOnline(interface,state):
                self.Commands['CombinedCurrent']['Status']['Live'] = str(state)
                update = {'command':'CombinedCurrent','value':state,'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: Processor({}) ~ CombinedCurrent {}'.format(self.__friendly_name,state)
                print(str_to_send)
                self.__printToServer(str_to_send)
                for f in self.__combinedcurrent_event_callbacks:
                    f(interface,state)
            @event(self.__interface,'CombinedWattageChanged')
            def handleOnline(interface,state):
                self.Commands['CombinedWattage']['Status']['Live'] = str(state)
                update = {'command':'CombinedWattage','value':state,'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: Processor({}) ~ CombinedWattage {}'.format(self.__friendly_name,state)
                print(str_to_send)
                self.__printToServer(str_to_send)
                for f in self.__combinedwattage_event_callbacks:
                    f(interface,state)
            @event(self.__interface,'CombinedLoadStateChanged')
            def handleOnline(interface,state):
                self.Commands['CombinedLoadState']['Status']['Live'] = str(state)
                update = {'command':'CombinedLoadState','value':state,'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: Processor({}) ~ CombinedLoadState {}'.format(self.__friendly_name,state)
                print(str_to_send)
                self.__printToServer(str_to_send)
                for f in self.__combinedloadstate_event_callbacks:
                    f(interface,state)
        if 'PCS1' in self.__model:
            @event(self.__interface,'ExecutiveModeChanged')
            def handleOnline(interface,state):
                self.Commands['ExecutiveMode']['Status']['Live'] = str(state)
                update = {'command':'ExecutiveMode','value':state,'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: Processor({}) ~ ExecutiveMode {}'.format(self.__friendly_name,state)
                print(str_to_send)
                self.__printToServer(str_to_send)
                for f in self.__executivemode_event_callbacks:
                    f(interface,state)
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

        @Timer(1)
        def t(timer,count):
            somethingchanged = False
            if self.__userusage != self.__interface.UserUsage:
                somethingchanged = True
                self.__userusage = self.__interface.UserUsage
                self.Commands['UserUsage']['Status']['Live'] = self.__interface.UserUsage
                update = {'command':'UserUsage','value':self.Commands['UserUsage']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: Processor({}) ~ UserUsage {}'.format(self.__friendly_name,self.__userusage)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__systemsettings != self.__interface.SystemSettings:
                somethingchanged = True
                self.__systemsettings = self.__interface.SystemSettings
                self.Commands['SystemSettings']['Status']['Live'] = self.__interface.SystemSettings
                update = {'command':'SystemSettings','value':self.Commands['SystemSettings']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def SubscribeStatus(self,command,function):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)
        if command == 'CombinedCurrentChanged':
            self.__combinedcurrent_event_callbacks.append(function)
        if command == 'CombinedWattageChanged':
            self.__combinedwattage_event_callbacks.append(function)
        if command == 'CombinedLoadStateChanged':
            self.__combinedloadstate_event_callbacks.append(function)
        if command == 'ExecutiveModeChanged':
            self.__executivemode_event_callbacks.append(function)

    def SetExecutiveMode(self,Level):
        if 'PCS1' in self.__model:
            self.__interface.SetExecutiveMode(Level)
            str_to_send = 'command: Processor({}) ~ SetExecutiveMode({})'.format(self.__friendly_name,Level)
            print(str_to_send)
            self.__printToServer(str_to_send)
    def Reboot(self):
        str_to_send = 'command: Processor({}) ~ Reboot()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.Reboot()
    def SaveProgramLog(self):
        str_to_send = 'command: Processor({}) ~ SaveProgramLog()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        dt = datetime.now()
        filename = 'ProgramLog {}.txt'.format(dt.strftime('%Y-%m-%d %H%M%S'))
        with File(filename, 'w') as f:
            SaveProgramLog(f)

    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def ExecutiveMode(self,ExecutiveMode):
        if 'PCS1' in self.__model:
            return self.__interface.ExecutiveMode
        else:
            return 'Unavailable'
    @property
    def CombinedCurrent(self):
        return self.__interface.CombinedCurrent
    @property
    def CombinedLoadState(self):
        return self.__interface.CombinedLoadState
    @property
    def CombinedWattage(self):
        return self.__interface.CombinedWattage
    @property
    def CurrentLoad(self):
        return self.__interface.CurrentLoad
    @property
    def FirmwareVersion(self):
        return self.__interface.FirmwareVersion
    @property
    def Hostname(self):
        return self.__interface.Hostname
    @property
    def IPAddress(self):
        return self.__interface.IPAddress
    @property
    def LinkLicenses(self):
        return self.__interface.LinkLicenses
    @property
    def MACAddress(self):
        return self.__interface.MACAddress
    @property
    def ModelName(self):
        return self.__interface.ModelName
    @property
    def PartNumber(self):
        return self.__interface.PartNumber
    @property
    def SerialNumber(self):
        return self.__interface.SerialNumber
    @property
    def SystemSettings(self):
        return self.__interface.SystemSettings
    @property
    def UserUsage(self):
        return self.__interface.UserUsage

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
        except:
            serverBuffer += data
        if 'ExecutiveMode(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp=temp_dict['value1']
            try:
                temp=int(temp)
            except:
                temp = None
            if self.__interface and temp is not None:
                self.SetExecutiveMode(temp)
        if 'Reboot(' in serverBuffer:
            if self.__interface:
                self.Reboot()
        if 'SaveProgramLog(' in serverBuffer:
            if self.__interface:
                self.SaveProgramLog()
class UIDeviceWrapper(DebugServer):
    def __init__(self,DeviceAlias:'str',PartNumber:'str'=None,listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'UI'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)

        self.__online_event_callbacks = []
        self.__offline_event_callbacks = []
        self.__brightnesschanged_event_callbacks = []
        self.__hdcpstatuschanged_event_callbacks = []
        self.__inactivitychanged_event_callbacks = []
        self.__inputpresencechanged_event_callbacks =[]
        self.__lidchanged_event_callbacks =[]
        self.__lightchanged_event_callbacks =[]
        self.__motiondetected_event_callbacks =[]
        self.__overtemperaturechanged_event_callbacks =[]
        self.__overtemperaturewarning_event_callbacks =[]
        self.__overtemperaturewarningstatechanged_event_callbacks =[]
        self.__sleepchanged_event_callbacks =[]

        self.__interface = UIDevice(DeviceAlias,PartNumber) #type:UIDevice
        self.device = self.__interface
        #@Wait(0.1)
        #def w():
        self.Commands = {
            'OnlineStatus':{'Status':{}},
            'HDCPStatus':{'Parameters': ['Video Input'],'Status': {}},
            'InputPresence':{'Parameters': ['Video Input'],'Status': {}},
            'Mute':{'Parameters': ['Channel Name'],'Status': {}},
            'Volume':{'Parameters': ['Channel Name'],'Status': {}},
            'AutoBrightness':{'Status': {}},
            'Brightness':{'Status':{}},
            'DisplayTimer':{'Status':{}},
            'InactivityTime':{'Status':{}},
            'Input':{'Status':{}},
            'LEDBlinking':{'Status':{}},
            'LEDState':{'Status':{}},
            'MotionDecayTime':{'Status':{}},
            'SleepTimer':{'Status':{}},
            'WakeOnMotion':{'Status':{}},
            'AmbientLightValue':{'Status':{}},
            'DeviceAlias':{'Status':{}},
            'DisplayState':{'Status':{}},
            'DisplayTimerEnabled':{'Status':{}},
            'FirmwareVersion':{'Status':{}},
            'Inactivity':{'Status':{}},
            'LidState':{'Status':{}},
            'LightDetectedState':{'Status':{}},
            'LinkLicenses':{'Status':{}},
            'ModelName':{'Status':{}},
            'MotionState':{'Status':{}},
            'OverTemperature':{'Status':{}},
            'OverTemperatureWarningState':{'Status':{}},
            'PartNumber':{'Status':{}},
            'SerialNumber':{'Status':{}},
            'SleepState':{'Status':{}},
            'SleepTimerEnabled':{'Status':{}},
            'SystemSettings':{'Status':{}},
            'UserUsage':{'Status':{}},
            'WakeOnMotion':{'Status':{}},
            }
        self.__model = self.__interface.ModelName


        self.__systemsettings = None
        self.__userusage = None
        self.__autobrightness = None
        self.__displaystate = None
        self.__displaytimer = None
        self.__displaytimerenabled = None
        self.__inactivitytime = None
        self.__lightdetectedstate = None
        self.__motiondecaytime = None
        self.__sleeptimer = None
        self.__sleeptimerenabled = None
        self.__wakeonmotion = None

        self.__polling_timer = Timer(5,self.__create_polling_timer())
        self.__polling_timer.Stop()

        print('debug: UIDevice({}) init events start'.format(self.__friendly_name))
        @event(self.__interface,'Online')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Online'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__online_event_callbacks:
                f(interface,state)
        @event(self.__interface,'Offline')
        def handleOnline(interface,state):
            self.Commands['OnlineStatus']['Status']['Live'] = 'Offline'
            update = {'command':'OnlineStatus','value':state,'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ OnlineStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__offline_event_callbacks:
                f(interface,state)
        @event(self.__interface,'BrightnessChanged')
        def handlebrightness(interface,state):
            self.Commands['Brightness']['Status']['Live'] = str(state)
            update = {'command':'Brightness','value':str(state),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ Brightness {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__brightnesschanged_event_callbacks:
                f(interface,state)
        @event(self.__interface,'HDCPStatusChanged')
        def handlehdcp(interface,state):
            self.Commands['HDCPStatus']['Status'][state[0]]['Live'] = str(state[1])
            update = {'command':'HDCPStatus','value':str(state[1]),'qualifier':{'Video Input':state[0]}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ HDCPStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__hdcpstatuschanged_event_callbacks:
                f(interface,state)
        @event(self.__interface,'InactivityChanged')
        def handleinactivity(interface,state):
            self.Commands['Inactivity']['Status']['Live'] = str(state)
            update = {'command':'Inactivity','value':str(state),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ Inactivity {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__inactivitychanged_event_callbacks:
                f(interface,state)
        @event(self.__interface,'InputPresenceChanged')
        def handleinputpresence(interface,state):
            self.Commands['InputPresence']['Status'][state[0]]['Live'] = str(state[1])
            update = {'command':'InputPresence','value':str(state[1]),'qualifier':{'Video Input':state[0]}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ InputPresence {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__inputpresencechanged_event_callbacks:
                f(interface,state)
        @event(self.__interface,'LidChanged')
        def handlelidstate(interface,state):
            self.Commands['LidState']['Status']['Live'] = str(state)
            update = {'command':'LidState','value':str(state),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ LidState {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__lidchanged_event_callbacks:
                f(interface,state)
        @event(self.__interface,'LightChanged')
        def handlelight(interface,state):
            self.Commands['AmbientLightValue']['Status']['Live'] = str(state)
            update = {'command':'AmbientLightValue','value':str(state),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ AmbientLightValue {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__lightchanged_event_callbacks:
                f(interface,state)
        @event(self.__interface,'MotionDetected')
        def handlemotion(interface,state):
            self.Commands['MotionState']['Status']['Live'] = str(state)
            update = {'command':'MotionState','value':str(state),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ MotionDetection {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__motiondetected_event_callbacks:
                f(interface,state)
        @event(self.__interface,'OverTemperatureChanged')
        def handleovertemp(interface,state):
            self.Commands['OverTemperature']['Status']['Live'] = str(state)
            update = {'command':'OverTemperature','value':str(state),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ OverTemperature {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__overtemperaturechanged_event_callbacks:
                f(interface,state)
        @event(self.__interface,'OverTemperatureWarning')
        def handleovertempwarn(interface,state):
            self.Commands['OverTemperatureWarning']['Status']['Live'] = str(state)
            update = {'command':'OverTemperatureWarning','value':str(state),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ OverTemperatureWarning {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__overtemperaturewarning_event_callbacks:
                f(interface,state)
        @event(self.__interface,'OverTemperatureWarningStateChanged')
        def handleovertempwarnstate(interface,state):
            self.Commands['OverTemperatureWarning']['Status']['Live'] = str(state)
            update = {'command':'OverTemperatureWarning','value':str(state),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ OverTemperatureWarningState {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__overtemperaturewarningstatechanged_event_callbacks:
                f(interface,state)
        @event(self.__interface,'SleepChanged')
        def handlesleep(interface,state):
            self.Commands['SleepState']['Status']['Live'] = str(state)
            update = {'command':'SleepState','value':str(state),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ SleepStatus {}'.format(self.__friendly_name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
            for f in self.__sleepchanged_event_callbacks:
                f(interface,state)
        print('debug: UIDevice({}) init events end'.format(self.__friendly_name))
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)
        self.__init_values_wait = Wait(10,self.__init_values())
        self.__init_values_wait.Restart()
        print('debug: UIDevice({}) init complete'.format(self.__friendly_name))

    def __init_values(self):
        def w():
            print('debug: UIDevice({}) init commands start'.format(self.__friendly_name))
            self.__systemsettings = self.__interface.SystemSettings
            self.__userusage = self.__interface.UserUsage
            self.__autobrightness = self.__interface.AutoBrightness
            self.__wakeonmotion = self.__interface.WakeOnMotion
            self.__motiondecaytime = self.__interface.MotionDecayTime
            if self.__model:
                brightness = self.__interface.Brightness
                displaytimer = self.__interface.DisplayTimer
                sleeptimer = self.__interface.SleepTimer
                ambientlight = self.__interface.AmbientLightValue
                displaystate = self.__interface.DisplayState
                displaytimerenabled = self.__interface.DisplayTimerEnabled
                lightdetectedstate = self.__interface.LightDetectedState
                sleepstate = self.__interface.SleepState
                sleeptimerenabled = self.__interface.SleepTimerEnabled
                volumemaster = self.__interface.GetVolume('Master')
                volumeclick = self.__interface.GetVolume('Click')
                volumesound = self.__interface.GetVolume('Sound')
                volumehdmi = self.__interface.GetVolume('HDMI')
                volumextp = self.__interface.GetVolume('XTP')
                mutemaster = self.__interface.GetMute('Master')
                muteclick = self.__interface.GetMute('Click')
                mutesound = self.__interface.GetMute('Sound')
                mutehdmi = self.__interface.GetMute('HDMI')
                mutextp = self.__interface.GetMute('XTP')
            else:
                brightness = 'Unavailable'
                displaytimer = 'Unavailable'
                sleeptimer = 'Unavailable'
                ambientlight = 'Unavailable'
                displaystate = 'Unavailable'
                displaytimerenabled = 'Unavailable'
                lightdetectedstate = 'Unavailable'
                sleepstate = 'Unavailable'
                sleeptimerenabled = 'Unavailable'
                volumemaster = 'Unavailable'
                volumeclick = 'Unavailable'
                volumesound = 'Unavailable'
                volumehdmi = 'Unavailable'
                volumextp = 'Unavailable'
                mutemaster = 'Unavailable'
                muteclick = 'Unavailable'
                mutesound = 'Unavailable'
                mutehdmi = 'Unavailable'
                mutextp = 'Unavailable'
            self.Commands['HDCPStatus']['Status'] = {'HDMI':{'Live':self.__interface.GetHDCPStatus('HDMI')},'XTP':{'Live':self.__interface.GetHDCPStatus('XTP')}}
            update = {'command':'HDCPStatus','value':str(self.Commands['HDCPStatus']['Status']['HDMI']['Live']),'qualifier':{'Video Input':'HDMI'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            update = {'command':'HDCPStatus','value':str(self.Commands['HDCPStatus']['Status']['XTP']['Live']),'qualifier':{'Video Input':'XTP'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['InputPresence']['Status'] = {'HDMI':{'Live':self.__interface.GetHDCPStatus('HDMI')},'XTP':{'Live':self.__interface.GetHDCPStatus('XTP')}}
            update = {'command':'InputPresence','value':str(self.Commands['InputPresence']['Status']['HDMI']['Live']),'qualifier':{'Video Input':'HDMI'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            update = {'command':'InputPresence','value':str(self.Commands['InputPresence']['Status']['XTP']['Live']),'qualifier':{'Video Input':'XTP'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['Mute']['Status'] = {
                    'Master':{'Live':mutemaster},
                    'Click':{'Live':muteclick},
                    'Sound':{'Live':mutesound},
                    'HDMI':{'Live':mutehdmi},
                    'XTP':{'Live':mutextp}}
            update = {'command':'Mute','value':str(mutemaster),'qualifier':{'Channel Name':'Master'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            update = {'command':'Mute','value':str(muteclick),'qualifier':{'Channel Name':'Click'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            update = {'command':'Mute','value':str(mutesound),'qualifier':{'Channel Name':'Sound'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            update = {'command':'Mute','value':str(mutehdmi),'qualifier':{'Channel Name':'HDMI'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            update = {'command':'Mute','value':str(mutextp),'qualifier':{'Channel Name':'XTP'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['Volume']['Status'] = {
                    'Master':{'Live':volumemaster},
                    'Click':{'Live':volumeclick},
                    'Sound':{'Live':volumesound},
                    'HDMI':{'Live':volumehdmi},
                    'XTP':{'Live':volumextp}}
            update = {'command':'Volume','value':str(mutemaster),'qualifier':{'Channel Name':'Master'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            update = {'command':'Volume','value':str(muteclick),'qualifier':{'Channel Name':'Click'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            update = {'command':'Volume','value':str(mutesound),'qualifier':{'Channel Name':'Sound'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            update = {'command':'Volume','value':str(mutehdmi),'qualifier':{'Channel Name':'HDMI'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            update = {'command':'Volume','value':str(mutextp),'qualifier':{'Channel Name':'XTP'}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['AutoBrightness']['Status'] = {'Live':self.__interface.AutoBrightness}
            update = {'command':'AutoBrightness','value':str(self.Commands['AutoBrightness']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['Brightness']['Status'] = {'Live':brightness}
            update = {'command':'Brightness','value':str(self.Commands['Brightness']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['DisplayTimer']['Status'] = {'Live':displaytimer}
            update = {'command':'DisplayTimer','value':str(self.Commands['DisplayTimer']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['MotionDecayTime']['Status'] = {'Live':self.__interface.MotionDecayTime}
            update = {'command':'MotionDecayTime','value':str(self.Commands['MotionDecayTime']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['SleepTimer']['Status'] = {'Live':sleeptimer}
            update = {'command':'SleepTimer','value':str(self.Commands['SleepTimer']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['WakeOnMotion']['Status'] = {'Live':self.__interface.WakeOnMotion}
            update = {'command':'WakeOnMotion','value':str(self.Commands['WakeOnMotion']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['AmbientLightValue']['Status'] = {'Live':ambientlight}
            update = {'command':'AmbientLightValue','value':str(self.Commands['AmbientLightValue']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['DeviceAlias']['Status'] = {'Live':self.__interface.DeviceAlias}
            update = {'command':'DeviceAlias','value':str(self.Commands['DeviceAlias']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['DisplayState']['Status'] = {'Live':displaystate}
            update = {'command':'DisplayState','value':str(self.Commands['DisplayState']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['DisplayTimerEnabled']['Status'] = {'Live':displaytimerenabled}
            update = {'command':'DisplayTimerEnabled','value':str(self.Commands['DisplayTimerEnabled']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['FirmwareVersion']['Status'] = {'Live':self.__interface.FirmwareVersion}
            update = {'command':'FirmwareVersion','value':str(self.Commands['FirmwareVersion']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['LidState']['Status'] = {'Live':self.__interface.LidState}
            update = {'command':'LidState','value':str(self.Commands['LidState']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['LightDetectedState']['Status'] = {'Live':lightdetectedstate}
            update = {'command':'LightDetectedState','value':str(self.Commands['LightDetectedState']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['LinkLicenses']['Status'] = {'Live':self.__interface.LinkLicenses}
            update = {'command':'LinkLicenses','value':str(self.Commands['LinkLicenses']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['ModelName']['Status'] = {'Live':self.__interface.ModelName}
            update = {'command':'ModelName','value':str(self.Commands['ModelName']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['MotionState']['Status'] = {'Live':self.__interface.MotionState}
            update = {'command':'MotionState','value':str(self.Commands['MotionState']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['OverTemperature']['Status'] = {'Live':self.__interface.OverTemperature}
            update = {'command':'OverTemperature','value':str(self.Commands['OverTemperature']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['OverTemperatureWarningState']['Status'] = {'Live':self.__interface.OverTemperatureWarningState}
            update = {'command':'OverTemperatureWarningState','value':str(self.Commands['OverTemperatureWarningState']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['PartNumber']['Status'] = {'Live':self.__interface.PartNumber}
            update = {'command':'PartNumber','value':str(self.Commands['PartNumber']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['SerialNumber']['Status'] = {'Live':self.__interface.SerialNumber}
            update = {'command':'SerialNumber','value':str(self.Commands['SerialNumber']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['SleepState']['Status'] = {'Live':sleepstate}
            update = {'command':'SleepState','value':str(self.Commands['SleepState']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['SleepTimerEnabled']['Status'] = {'Live':sleeptimerenabled}
            update = {'command':'SleepTimerEnabled','value':str(self.Commands['SleepTimerEnabled']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['SystemSettings']['Status'] = {'Live':self.__interface.SystemSettings}
            update = {'command':'SystemSettings','value':str(self.Commands['SystemSettings']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            self.Commands['UserUsage']['Status'] = {'Live':self.__interface.UserUsage}
            update = {'command':'UserUsage','value':str(self.Commands['UserUsage']['Status']['Live']),'qualifier':None}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            print('debug: UIDevice({}) init commands end'.format(self.__friendly_name))
            self.__polling_timer.Restart()
        return w
    def __create_polling_timer(self):
        def t(timer,count):
            somethingchanged = False
            if self.__userusage != self.__interface.UserUsage:
                somethingchanged = True
                self.__userusage = self.__interface.UserUsage
                self.Commands['UserUsage']['Status']['Live'] = self.__interface.UserUsage
                update = {'command':'UserUsage','value':self.Commands['UserUsage']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: UI({}) ~ UserUsage {}'.format(self.__friendly_name,self.__userusage)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__systemsettings != self.__interface.SystemSettings:
                somethingchanged = True
                self.__systemsettings = self.__interface.SystemSettings
                self.Commands['SystemSettings']['Status']['Live'] = self.__interface.SystemSettings
                update = {'command':'SystemSettings','value':self.Commands['SystemSettings']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
            if self.__autobrightness != self.__interface.AutoBrightness:
                somethingchanged = True
                self.__autobrightness = self.__interface.AutoBrightness
                self.Commands['AutoBrightness']['Status']['Live'] = self.__interface.AutoBrightness
                update = {'command':'AutoBrightness','value':self.Commands['AutoBrightness']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: UI({}) ~ AutoBrightness {}'.format(self.__friendly_name,self.__autobrightness)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__model:
                displaystate = self.__interface.DisplayState
            else:
                displaystate = 'Unavailable'
            if self.__displaystate != displaystate:
                somethingchanged = True
                self.__displaystate = displaystate
                self.Commands['DisplayState']['Status']['Live'] = displaystate
                update = {'command':'DisplayState','value':self.Commands['DisplayState']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: UI({}) ~ DisplayState {}'.format(self.__friendly_name,displaystate)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__model:
                displaytimer = self.__interface.DisplayTimer
            else:
                displaytimer = 'Unavailable'
            if self.__displaytimer != displaytimer:
                somethingchanged = True
                self.__displaytimer = displaytimer
                self.Commands['DisplayTimer']['Status']['Live'] = displaytimer
                update = {'command':'DisplayTimer','value':self.Commands['DisplayTimer']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: UI({}) ~ DisplayTimer {}'.format(self.__friendly_name,displaytimer)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__model:
                displaytimerenabled = self.__interface.DisplayTimerEnabled
            else:
                displaytimerenabled = 'Unavailable'
            if self.__displaytimerenabled != displaytimerenabled:
                somethingchanged = True
                self.__displaytimerenabled = displaytimerenabled
                self.Commands['DisplayTimerEnabled']['Status']['Live'] = displaytimerenabled
                update = {'command':'DisplayTimerEnabled','value':self.Commands['DisplayTimerEnabled']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: UI({}) ~ DisplayTimerEnabled {}'.format(self.__friendly_name,displaytimerenabled)
                print(str_to_send)
                self.__printToServer(str_to_send)
            try:
                inactivitytime = self.__interface.InactivityTime
            except:
                inactivitytime = 'Not Set'
            if self.__inactivitytime != inactivitytime:
                somethingchanged = True
                self.__inactivitytime = inactivitytime
                self.Commands['InactivityTime']['Status']['Live'] = inactivitytime
                update = {'command':'InactivityTime','value':self.Commands['InactivityTime']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: UI({}) ~ InactivityTime {}'.format(self.__friendly_name,inactivitytime)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__model:
                lightdetectedstate = self.__interface.LightDetectedState
            else:
                lightdetectedstate = 'Unavailable'
            if self.__lightdetectedstate != lightdetectedstate:
                somethingchanged = True
                self.__lightdetectedstate = lightdetectedstate
                self.Commands['LightDetectedState']['Status']['Live'] = lightdetectedstate
                update = {'command':'LightDetectedState','value':self.Commands['LightDetectedState']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: UI({}) ~ LightDetectedState {}'.format(self.__friendly_name,lightdetectedstate)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__motiondecaytime != self.__interface.MotionDecayTime:
                somethingchanged = True
                self.__motiondecaytime = self.__interface.SystemMotionDecayTimeSettings
                self.Commands['MotionDecayTime']['Status']['Live'] = self.__interface.MotionDecayTime
                update = {'command':'MotionDecayTime','value':self.Commands['MotionDecayTime']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: UI({}) ~ MotionDecayTime {}'.format(self.__friendly_name,self.__motiondecaytime)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__model:
                sleeptimer = self.__interface.SleepTimer
            else:
                sleeptimer = 'Unavailable'
            if self.__sleeptimer != sleeptimer:
                somethingchanged = True
                self.__sleeptimer = sleeptimer
                self.Commands['SleepTimer']['Status']['Live'] = sleeptimer
                update = {'command':'SleepTimer','value':self.Commands['SleepTimer']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: UI({}) ~ SleepTimer {}'.format(self.__friendly_name,sleeptimer)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__model:
                sleeptimerenabled = self.__interface.SleepTimerEnabled
            else:
                sleeptimerenabled = 'Unavailable'
            if self.__sleeptimerenabled != sleeptimerenabled:
                somethingchanged = True
                self.__sleeptimerenabled = sleeptimerenabled
                self.Commands['SleepTimerEnabled']['Status']['Live'] = sleeptimerenabled
                update = {'command':'SleepTimerEnabled','value':self.Commands['SleepTimerEnabled']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: UI({}) ~ SleepTimerEnabled {}'.format(self.__friendly_name,sleeptimerenabled)
                print(str_to_send)
                self.__printToServer(str_to_send)
            if self.__wakeonmotion != self.__interface.WakeOnMotion:
                somethingchanged = True
                self.__wakeonmotion = self.__interface.WakeOnMotion
                self.Commands['WakeOnMotion']['Status']['Live'] = self.__interface.WakeOnMotion
                update = {'command':'WakeOnMotion','value':self.Commands['WakeOnMotion']['Status']['Live'],'qualifier':None}
                self._DebugServer__send_interface_status(self.__listening_port,update)
                str_to_send = 'event: UI({}) ~ WakeOnMotion {}'.format(self.__friendly_name,self.__wakeonmotion)
                print(str_to_send)
                self.__printToServer(str_to_send)
        return t

    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type
    def GetHDCPStatus(self,videoInput:'str'):
        return self.__interface.GetHDCPStatus(videoInput)
    def GetMute(self,name:'str'):
        v = self.__interface.GetMute(name)
        if v != self.Commands['Mute']['Status'][name]['Live']:
            self.Commands['Mute']['Status'][name]['Live'] = v
            update = {'command':'Mute','value':v,'qualifier':{'Channel Name':name}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ Mute {} {}'.format(self.__friendly_name,name,v)
            print(str_to_send)
            self.__printToServer(str_to_send)
        return v
    def GetVolume(self,name:'str'):
        v = self.__interface.GetVolume(name)
        if str(v) != self.Commands['Volume']['Status'][name]['Live']:
            self.Commands['Volume']['Status'][name]['Live'] = str(v)
            update = {'command':'Volume','value':str(v),'qualifier':{'Channel Name':name}}
            self._DebugServer__send_interface_status(self.__listening_port,update)
            str_to_send = 'event: UI({}) ~ Volume {} {}'.format(self.__friendly_name,name,v)
            print(str_to_send)
            self.__printToServer(str_to_send)
        return v
    def HideAllPopups(self):
        str_to_send = 'command: UI({}) ~ HideAllPopups()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.HideAllPopups()
    def HidePopup(self,popup:'str'):
        str_to_send = 'command: UI({}) ~ HidePopup({})'.format(self.__friendly_name,popup)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.HidePopup(popup)
    def HidePopupGroup(self,group:'int'):
        str_to_send = 'command: UI({}) ~ HidePopupGroup({})'.format(self.__friendly_name,group)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.HidePopupGroup(group)
    def PlaySound(self,filename:'str'):
        str_to_send = 'command: UI({}) ~ PlaySound({})'.format(self.__friendly_name,filename)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.PlaySound(filename)
    def Reboot(self):
        str_to_send = 'command: UI({}) ~ Reboot()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.Reboot()
    def SetAutoBrightness(self,state:'bool'):
        str_to_send = 'command: UI({}) ~ SetAutoBrightness({})'.format(self.__friendly_name,state)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetAutoBrightness(state)
    def SetBrightness(self,level:'int'):
        str_to_send = 'command: UI({}) ~ SetBrightness({})'.format(self.__friendly_name,level)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetBrightness(level)
    def SetDisplayTimer(self,state:'bool',timeout:'int'):
        str_to_send = 'command: UI({}) ~ SetDisplayTimer({},{})'.format(self.__friendly_name,state,timeout)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetDisplayTimer(state)
    def SetInactivityTime(self,times:'list[int]'):
        str_to_send = 'command: UI({}) ~ SetInactivityTime({})'.format(self.__friendly_name,times)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetInactivityTime(times)
    def SetInput(self,videoInput:'str'):
        str_to_send = 'command: UI({}) ~ SetInput({})'.format(self.__friendly_name,videoInput)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetInput(videoInput)
    def SetLEDBlinking(self,ledId:'int',rate:'str',stateList:'list[str]'):
        str_to_send = 'command: UI({}) ~ SetLEDBlinking({},{},{})'.format(self.__friendly_name,ledId,rate,stateList)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetLEDBlinking(ledId,rate,stateList)
    def SetLEDState(self,ledId:'int',state:'str'):
        str_to_send = 'command: UI({}) ~ SetLEDState({},{})'.format(self.__friendly_name,ledId,state)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetLEDState(ledId,state)
    def SetMute(self,name:'str',mute:'str'):
        str_to_send = 'command: UI({}) ~ SetLEDState({},{})'.format(self.__friendly_name,name,mute)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetMute(name,mute)
    def SetSleepTimer(self,state:'bool',duration:'int'=None):
        str_to_send = 'command: UI({}) ~ SetSleepTimer({},{})'.format(self.__friendly_name,state,duration)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetSleepTimer(state,duration)
    def SetMotionDecayTime(self,duration:'int'):
        str_to_send = 'command: UI({}) ~ SetMotionDecayTime({},{})'.format(self.__friendly_name,duration)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetMotionDecayTime(duration)
    def SetVolume(self,name:'str',level:'int'):
        str_to_send = 'command: UI({}) ~ SetVolume({},{})'.format(self.__friendly_name,name,level)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetVolume(name,level)
    def SetWakeOnMotion(self,state:'bool'):
        str_to_send = 'command: UI({}) ~ SetWakeOnMotion({})'.format(self.__friendly_name,state)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetWakeOnMotion(state)
    def ShowPage(self,page:'str'):
        str_to_send = 'command: UI({}) ~ ShowPage({})'.format(self.__friendly_name,page)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.ShowPage(page)
    def ShowPopup(self,popup:'str',duration:'int'=0):
        str_to_send = 'command: UI({}) ~ ShowPopup({},{})'.format(self.__friendly_name,popup,duration)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.ShowPopup(popup,duration)
    def Sleep(self):
        str_to_send = 'command: UI({}) ~ Sleep()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.Sleep()
    def StopSound(self):
        str_to_send = 'command: UI({}) ~ StopSound()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.SetMotionDecayTime()
    def Wake(self):
        str_to_send = 'command: UI({}) ~ Wake()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        self.__interface.Wake()

    def SubscribeStatus(self,command:'str',function:'object'):
        if command == 'Online':
            self.__online_event_callbacks.append(function)
        if command == 'Offline':
            self.__offline_event_callbacks.append(function)
        if command == 'BrightnessChanged':
            self.__brightnesschanged_event_callbacks.append(function)
        if command == 'HDCPStatusChanged':
            self.__hdcpstatuschanged_event_callbacks.append(function)
        if command == 'InactivityChanged':
            self.__inactivitychanged_event_callbacks.append(function)
        if command == 'InputPresenceChanged':
            self.__inputpresencechanged_event_callbacks.append(function)
        if command == 'LidChanged':
            self.__lidchanged_event_callbacks.append(function)
        if command == 'LightChanged':
            self.__lightchanged_event_callbacks.append(function)
        if command == 'MotionDetected':
            self.__motiondetected_event_callbacks.append(function)
        if command == 'OverTemperatureChanged':
            self.__overtemperaturechanged_event_callbacks.append(function)
        if command == 'OverTemperatureWarning':
            self.__overtemperaturewarning_event_callbacks.append(function)
        if command == 'OverTemperatureWarningStateChanged':
            self.__overtemperaturewarningstatechanged_event_callbacks.append(function)
        if command == 'SleepChanged':
            self.__sleepchanged_event_callbacks.append(function)


    def __printToServer(self,string):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    @property
    def Device(self):
        return self.__interface
    @property
    def AmbientLightValue(self):
        if self.__model:
            return self.__interface.AmbientLightValue
        else:
            return 'Unavailable'
    @property
    def AutoBrightness(self):
        return self.__interface.AutoBrightness
    @property
    def Brightness(self):
        if self.__model:
            return self.__interface.Brightness
        else:
            return -1
    @property
    def DeviceAlias(self):
        return self.__interface.DeviceAlias
    @property
    def DisplayState(self):
        return self.__interface.DisplayState
    @property
    def DisplayTimer(self):
        if self.__model:
            return self.__interface.DisplayTimer
        else:
            return 'Unavailable'
    @property
    def DisplayTimerEnabled(self):
        if self.__model:
            return self.__interface.DisplayTimerEnabled
        else:
            return 'Unavailable'
    @property
    def FirmwareVersion(self):
        return self.__interface.FirmwareVersion
    @property
    def Hostname(self):
        return self.__interface.Hostname
    @property
    def IPAddress(self):
        return self.__interface.IPAddress
    @property
    def InactivityTime(self):
        try:
            return self.__interface.InactivityTime
        except:
            return 'Unavailable'
    @property
    def LidState(self):
        return self.__interface.LidState
    @property
    def LightDetectedState(self):
        if self.__model:
            return self.__interface.LightDetectedState
        else:
            return 'Unavailable'
    @property
    def LinkLicenses(self):
        return self.__interface.LinkLicenses
    @property
    def MACAddress(self):
        return self.__interface.MACAddress
    @property
    def ModelName(self):
        return self.__interface.ModelName
    @property
    def MotionDecayTime(self):
        return self.__interface.MotionDecayTime
    @property
    def MotionState(self):
        return self.__interface.MotionState
    @property
    def OverTemperature(self):
        return self.__interface.OverTemperature
    @property
    def PartNumber(self):
        return self.__interface.PartNumber
    @property
    def SerialNumber(self):
        return self.__interface.SerialNumber
    @property
    def SleepState(self):
        if self.__model:
            return self.__interface.SleepState
        else:
            return 'Unavailable'
    @property
    def SleepTimer(self):
        if self.__model:
            return self.__interface.SleepTimer
        else:
            return 'Unavailable'
    @property
    def SleepTimerEnabled(self):
        if self.__model:
            return self.__interface.SleepTimerEnabled
        else:
            return 'Unavailable'
    @property
    def SystemSettings(self):
        return self.__interface.SystemSettings
    @property
    def UserUsage(self):
        return self.__interface.UserUsage
    @property
    def WakeOnMotion(self):
        return self.__interface.WakeOnMotion

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
        except:
            serverBuffer += data
        if 'ShowPage(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse ShowPage command:{}'.format(e))
                return
            temp=temp_dict['value1']
            if self.__interface and temp:
                self.ShowPage(temp)
        if 'ShowPopup(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse ShowPopup command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            temp2=temp_dict['value2']
            try:
                temp2 = int(temp2)
            except:
                temp2 = 0
            if self.__interface and temp1:
                self.ShowPopup(temp1,temp2)
        if 'HidePopupGroup(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse HidePopupGroup command:{}'.format(e))
                return
            temp=temp_dict['value1']
            try:
                temp = int(temp)
            except:
                temp = None
            if self.__interface and temp:
                self.HidePopupGroup(temp)
        if 'HidePopup(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse HidePopup command:{}'.format(e))
                return
            temp=temp_dict['value1']
            if self.__interface and temp:
                self.HidePopup(temp)
        if 'HideAllPopups(' in serverBuffer:
            if self.__interface:
                self.HideAllPopups()
        if 'Wake(' in serverBuffer:
            if self.__interface:
                self.Wake()
        if 'Sleep(' in serverBuffer:
            if self.__interface:
                self.Sleep()
        if 'Reboot(' in serverBuffer:
            if self.__interface:
                self.Reboot()








"""
It is highly advised that after each combination of panels re-send indirect
Text fields,button states, visibility, other settings, popups, and page flips.
Items in combined panels do NOT sync with the combination process unless a sync
function is supplied.
Time required varies depending on how many items there are to combine.

Any panel or ID can be supplied either one at a time or as a list


example: adds panels to room, creates button events for 15 buttons, removes one of the panels from room,
adds new panel to room


Rm = VirtualUI()
Rm.AddPanel([tp1,tp2])

def foo1(button,state):
    pass
Rm.SetFunction(1,foo1,'Pressed')

def foo2(button,state):
    pass
Rm.SetFunction([range(2,16)],foo2,'Pressed',isMomentary=True)  #isMomentary is optional, default is false
Rm.SetFunction([range(2,16)],foo2,'Repeated')

Rm.RemovePanel(tp2)
Rm.AddPanel(tp3)

"""

class VirtualUI(DebugServer):
    def __init__(self,listening_port:'int'=0,friendly_name:'str'=''):
        self.__interface_type = 'VirtualUI'
        self.__listening_port = listening_port
        self.__friendly_name = friendly_name
        if not self.__listening_port:
            self.__listening_port = self._DebugServer__create_listening_port()
        if not self.__friendly_name:
            self.__friendly_name = '{} {}'.format(self.__interface_type,self.__listening_port)
        self.__interface = self
        self.Commands = {}
        self._DebugServer__add_instance(self.__listening_port,self,self.__friendly_name,self.__interface_type)

        self.devTPs = [] #type:list[UIDevice]

        self.__btns = [] #type:list[list[Button]]
        self.__btnIDs = [] #type:list[list[int]]
        self.__btnHoldTimes = {} #type:list[list[float]]
        self.__btnRepeatTimes = {} #type:list[list[float]]
        self.__btnPushFunctions = {} #type:list[list[object]]
        self.__btnReleaseFunctions = {} #type:list[list[object]]
        self.__btnHoldFunctions = {} #type:list[list[object]]
        self.__btnTapFunctions = {} #type:list[list[object]]
        self.__btnRepeatFunctions = {} #type:list[list[object]]

        self.__knobs = [] #type:list[list[Knob]]
        self.__knobIDs = [] #type:list[list[int]]
        self.__knobTurnFunctions = {} #type:list[list[object]]

        self.__lbls = [] #type:list[list[Label]]
        self.__lblIDs = [] #type:list[list[int]]

        self.__lvls = [] #type:list[list[Level]]
        self.__lvlIDs = [] #type:list[list[int]]


        self.__sliders =[] #type:list[list[Slider]]
        self.__sliderIDs = [] #type:list[list[int]]
        self.__sliderChangedFunctions = {} #type:list[list[object]]
        self.__sliderPressedFunctions = {} #type:list[list[object]]
        self.__sliderReleasedFunctions = {} #type:list[list[object]]


        self.__SyncFunctions = [] #type:list[object]


    def GetInterface(self):
        return self.__interface
    def GetInterfaceType(self):
        return self.__interface_type

    def SetSyncFunction(self,function):
        self.__SyncFunctions.append(function)

    # this function adds a panel or list of panels to the virtual panel, then defines the buttons actions for the newly added panel
    def AddPanel(self,tps:'list[UIDevice]'):
        tpList = [] #type:list[UIDevice]
        if type(tps) is type([]):
            tpList.extend(tps)
        else:
            tpList.append(tps)

        for tp in tpList:
            self.devTPs.append(tp)
            self.__btns.append({})
            self.__knobs.append({})
            self.__lbls.append({})
            self.__lvls.append({})
            self.__sliders.append({})
            str_to_send = 'config:VirtualUI({}) AddPanel({})'.format(self.__friendly_name,tp.DeviceAlias)
            print(str_to_send)
            self.__printToServer(str_to_send)
            #create the button list for the new panel
            for itemID in self.__btnIDs:
                print('adding button : {0}'.format(itemID))
                self.__btns[self.devTPs.index(tp)][itemID] = Button(tp,itemID,self.__btnHoldTimes[itemID],self.__btnRepeatTimes[itemID])
            #define button events for new panel based on virtual panel vars
            for itemID in self.__btnPushFunctions.keys():
                @event(self.__btns[self.devTPs.index(tp)][itemID],'Pressed')
                def stuff(button,state):
                    for func in self.__btnPushFunctions[button.ID]:
                        try:
                            func(button,state)
                        except Exception as e:
                            print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))
            for itemID in self.__btnReleaseFunctions.keys():
                @event(self.__btns[self.devTPs.index(tp)][itemID],'Released')
                def stuff(button,state):
                    for func in self.__btnReleaseFunctions[button.ID]:
                        try:
                            func(button,state)
                        except Exception as e:
                            print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))
            for itemID in self.__btnHoldFunctions.keys():
                @event(self.__btns[self.devTPs.index(tp)][itemID],'Held')
                def stuff(button,state):
                    for func in self.__btnHoldFunctions[button.ID]:
                        try:
                            func(button,state)
                        except Exception as e:
                            print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))
            for itemID in self.__btnTapFunctions.keys():
                @event(self.__btns[self.devTPs.index(tp)][itemID],'Tapped')
                def stuff(button,state):
                    for func in self.__btnTapFunctions[button.ID]:
                        try:
                            func(button,state)
                        except Exception as e:
                            print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))
            for itemID in self.__btnRepeatFunctions.keys():
                @event(self.__btns[self.devTPs.index(tp)][itemID],'Repeated')
                def stuff(button,state):
                    for func in self.__btnRepeatFunctions[button.ID]:
                        try:
                            func(button,state)
                        except Exception as e:
                            print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))

            #create the knob list for the new panel
            for itemID in self.__knobIDs:
                print('adding knob : {0}'.format(itemID))
                self.__knobs[self.devTPs.index(tp)][itemID] = Knob(tp,itemID)
                #define knob events for new panel based on virtual panel vars
                if itemID in self.__knobTurnFunctions.keys():
                    @event(self.__knobs[self.devTPs.index(tp)][itemID],'Turned')
                    def stuff(knob,direction):
                        for func in self.__knobTurnFunctions[knob.ID]:
                            try:
                                func(knob,direction)
                            except Exception as e:
                                print('exception calling function for knob {} state:{} :{}'.format(knob.ID,direction,e))


            #create the label list for the new panel
            for itemID in self.__lblIDs:
                print('adding label : {0}'.format(itemID))
                self.__lbls[self.devTPs.index(tp)][itemID] = Label(tp,itemID)

            #create the level list for the new panel
            for itemID in self.__lvlIDs:
                print('adding level : {0}'.format(itemID))
                self.__lvls[self.devTPs.index(tp)][itemID] = Level(tp,itemID)

            #create the slider list for the new panel
            for itemID in self.__sliderIDs:
                print('adding slider : {0}'.format(itemID))
                self.__sliders[self.devTPs.index(tp)][itemID] = Slider(tp,itemID)
                #define slider events for new panel based on virtual panel vars
                if itemID in self.__sliderChangedFunctions.keys():
                    @event(self.__sliders[self.devTPs.index(tp)][itemID],'Changed')
                    def stuff(slider,state,value):
                        for func in self.__sliderChangedFunctions[slider.ID]:
                            try:
                                func(slider,state,value)
                            except Exception as e:
                                print('exception calling function for slider {} state:{} :{}'.format(slider.ID,state,e))

                if itemID in self.__sliderPressedFunctions.keys():
                    @event(self.__sliders[self.devTPs.index(tp)][itemID],'Pressed')
                    def stuff(slider,state,value):
                        for func in self.__sliderPressedFunctions[slider.ID]:
                            try:
                                func(slider,state,value)
                            except Exception as e:
                                print('exception calling function for slider {} state:{} :{}'.format(slider.ID,state,e))
                if itemID in self.__sliderReleasedFunctions.keys():
                    @event(self.__sliders[self.devTPs.index(tp)][itemID],'Released')
                    def stuff(slider,state,value):
                        for func in self.__sliderReleasedFunctions[slider.ID]:
                            try:
                                func(slider,state,value)
                            except Exception as e:
                                print('exception calling function for slider {} state:{} :{}'.format(slider.ID,state,e))

        #resync panels for virtual panel
        if len(self.__SyncFunctions) > 0:
            for func in self.__SyncFunctions:
                func()

    # this function removes a panel or list of panels from the virtual panel
    def RemovePanel(self,tps:'UIDevice'):
        tpList = []
        if type(tps) is type([]):
            tpList.extend(tps)
        else:
            tpList.append(tps)
        for tp in tpList:
            str_to_send = 'config: VirtualUI({}) ~ RemovePanel({})'.format(self.__friendly_name,tp.DeviceAlias)
            print(str_to_send)
            self.__printToServer(str_to_send)
            del self.__btns[self.devTPs.index(tp)]
            del self.__knobs[self.devTPs.index(tp)]
            del self.__lbls[self.devTPs.index(tp)]
            del self.__lvls[self.devTPs.index(tp)]
            del self.__sliders[self.devTPs.index(tp)]
            self.devTPs.remove(tp)

    def RemoveAllPanels(self):
        for tp in self.devTPs:
            str_to_send = 'config: VirtualUI({}) ~ RemovePanel({})'.format(self.__friendly_name,tp.DeviceAlias)
            print(str_to_send)
            self.__printToServer(str_to_send)
            del self.__btns[self.devTPs.index(tp)]
            del self.__knobs[self.devTPs.index(tp)]
            del self.__lbls[self.devTPs.index(tp)]
            del self.__lvls[self.devTPs.index(tp)]
            del self.__sliders[self.devTPs.index(tp)]
            self.devTPs.remove(tp)

    # panel navigation functions
    def HideAllPopups(self):
        str_to_send = 'command: VirtualUI({}) ~ HideAllPopups()'.format(self.__friendly_name)
        print(str_to_send)
        self.__printToServer(str_to_send)
        for tp in self.devTPs:
            tp.HideAllPopups()
    def HidePopup(self,value:str):
        str_to_send = 'command: VirtualUI({}) ~ HidePopup({})'.format(self.__friendly_name,value)
        print(str_to_send)
        self.__printToServer(str_to_send)
        for tp in self.devTPs:
            tp.HidePopup(value)
    def HidePopupGroup(self,value:str):
        str_to_send = 'command: VirtualUI({}) ~ HidePopupGroup({})'.format(self.__friendly_name,value)
        print(str_to_send)
        self.__printToServer(str_to_send)
        for tp in self.devTPs:
            tp.HidePopupGroup(value)
    def ShowPage(self,value:str):
        str_to_send = 'command: VirtualUI({}) ~ ShowPage({})'.format(self.__friendly_name,value)
        print(str_to_send)
        self.__printToServer(str_to_send)
        for tp in self.devTPs:
            tp.ShowPage(value)
    def ShowPopup(self,value:str,duration:int=0):
        str_to_send = 'command: VirtualUI({}) ~ ShowPopup({},{})'.format(self.__friendly_name,value,duration)
        print(str_to_send)
        self.__printToServer(str_to_send)
        for tp in self.devTPs:
            tp.ShowPopup(value,duration)

    def __create_default_button_event_handler(self):
        def e(button:'Button',state:'str'):
            str_to_send = 'event: VirtualUI({}) ~ Button({},{}) {}'.format(button.Host,button.ID,button.Name,state)
            print(str_to_send)
            self.__printToServer(str_to_send)
        return e
    # this function adds buttons to the data for the virtual panel
    def AddButton(self,itemIDs,holdTime:float=None,repeatTime:float=None,isMomentary:bool=False):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            self.__btnIDs.append(itemID)
            self.__btnHoldTimes[itemID] = holdTime
            self.__btnRepeatTimes[itemID] = repeatTime
            self.__btnPushFunctions[itemID] = [self.__create_default_button_event_handler()]
            self.__btnReleaseFunctions[itemID] = [self.__create_default_button_event_handler()]
            self.__btnHoldFunctions[itemID] = [self.__create_default_button_event_handler()]
            self.__btnTapFunctions[itemID] = [self.__create_default_button_event_handler()]
            self.__btnRepeatFunctions[itemID] = [self.__create_default_button_event_handler()]

            for tp in self.devTPs:
                self.__btns[self.devTPs.index(tp)][itemID] = Button(tp,itemID,holdTime,repeatTime)
            if isMomentary:
                def pressed(button:'Button',state):
                    button.SetState(1)
                def released(button:'Button',state):
                    button.SetState(0)
                self.SetFunction(itemID,pressed,'Pressed')
                self.SetFunction(itemID,released,'Released')
                self.SetFunction(itemID,released,'Held')
                self.SetFunction(itemID,released,'Tapped')

    def __create_default_knob_event_handler(self):
        def e(knob:'Knob',direction:'int'):
            str_to_send = 'event: VirtualUI({}) ~ Knob({},{}) ~ Turned({})'.format(knob.Host,knob.ID,knob.Name,direction)
            print(str_to_send)
            self.__printToServer(str_to_send)
        return e
    # this function adds knobs to the data for the virtual panel
    def AddKnob(self,itemIDs:'list[int]'):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            self.__knobIDs.append(itemID)
            self.__knobTurnFunctions[itemID] = [self.__create_default_knob_event_handler()]
            for tp in self.devTPs:
                self.__knobs[self.devTPs.index(tp)][itemID] = Knob(tp,itemID)

    # this function adds knobs to the data for the virtual panel
    def AddLevel(self,itemIDs:'list[int]'):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            self.__lvlIDs.append(itemID)
            for tp in self.devTPs:
                self.__lvls[self.devTPs.index(tp)][itemID] = Level(tp,itemID)

    def __create_default_slider_event_handler(self):
        def e(slider:'Slider',state:'str',value:'int'):
            str_to_send = 'event: VirtualUI({}) ~ Slider({},{}) ~ {}({})'.format(slider.Host,slider.ID,slider.Name,state,value)
            print(str_to_send)
            self.__printToServer(str_to_send)
        return e
    # this function adds sliders to the date for the virtual panel
    def AddSlider(self,itemIDs:'list[int]'):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            self.__sliderIDs.append(itemID)
            self.__sliderChangedFunctions[itemID] = [self.__create_default_slider_event_handler()]
            self.__sliderPressedFunctions[itemID] = [self.__create_default_slider_event_handler()]
            self.__sliderReleasedFunctions[itemID] = [self.__create_default_slider_event_handler()]
            for tp in self.devTPs:
                self.__sliders[self.devTPs.index(tp)][itemID] = Slider(tp,itemID)


    # this function adds knobs to the data for the virtual panel
    def AddLabel(self,itemIDs:'list[int]'):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            self.__lblIDs.append(itemID)
            for tp in self.devTPs:
                self.__lbls[self.devTPs.index(tp)][itemID] = Label(tp,itemID)

    # associates a button with given ID with a function for pressed action for each TP in virtual panel
    def SetFunction(self,itemIDs:'list[int]',function,trigger:str):
        idList = []
        func_list = None
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.__btnIDs:
                if trigger == 'Pressed':
                    if itemID in self.__btnPushFunctions.keys():
                        if function not in self.__btnPushFunctions[itemID]:
                            self.__btnPushFunctions[itemID].append(function)
                    else:
                        self.__btnPushFunctions[itemID] = [function]
                    func_list = self.__btnPushFunctions[itemID]
                elif trigger == 'Released':
                    if itemID in self.__btnReleaseFunctions.keys():
                        if function not in self.__btnReleaseFunctions[itemID]:
                            self.__btnReleaseFunctions[itemID].append(function)
                    else:
                        self.__btnReleaseFunctions[itemID] = [function]
                    func_list = self.__btnReleaseFunctions[itemID]
                elif trigger == 'Held':
                    if itemID in self.__btnHoldFunctions.keys():
                        if function not in self.__btnHoldFunctions[itemID]:
                            self.__btnHoldFunctions[itemID].append(function)
                    else:
                        self.__btnHoldFunctions[itemID] = [function]
                    func_list = self.__btnHoldFunctions[itemID]
                elif trigger == 'Tapped':
                    if itemID in self.__btnTapFunctions.keys():
                        if function not in self.__btnTapFunctions[itemID]:
                            self.__btnTapFunctions[itemID].append(function)
                    else:
                        self.__btnTapFunctions[itemID] = [function]
                    func_list = self.__btnTapFunctions[itemID]
                elif trigger == 'Repeated':
                    if itemID in self.__btnRepeatFunctions.keys():
                        if function not in self.__btnRepeatFunctions[itemID]:
                            self.__btnRepeatFunctions[itemID].append(function)
                    else:
                        self.__btnRepeatFunctions[itemID] = [function]
                    func_list = self.__btnRepeatFunctions[itemID]
                for tp in self.devTPs:
                    @event(self.__btns[self.devTPs.index(tp)][itemID],trigger)
                    def stuff(button,state):
                        print('there are {} functions for btn {} state:{}'.format(len(func_list),button.ID,state))
                        for func in func_list:
                            try:
                                func(button,state)
                            except Exception as e:
                                print('exception calling function for button {} state:{} :{}'.format(button.ID,state,e))
            elif itemID in self.__knobIDs:
                if trigger == 'Turned':
                    if itemID in self.__knobTurnFunctions.keys():
                        if function not in self.__knobTurnFunctions[itemID]:
                            self.__knobTurnFunctions[itemID].append(function)
                    else:
                        self.__knobTurnFunctions[itemID] = [function]
                    func_list = self.__knobTurnFunctions[itemID]
                for tp in self.devTPs:
                    @event(self.__knobs[self.devTPs.index(tp)][itemID],trigger)
                    def stuff(knob,direction):
                        for func in func_list:
                            try:
                                func(knob,direction)
                            except Exception as e:
                                print('exception calling function for knob {} state:{} :'.format(knob.ID,direction,e))
            elif itemID in self.__sliderIDs:
                if trigger == 'Changed':
                    if itemID in self.__sliderChangedFunctions.keys():
                        if function not in self.__sliderChangedFunctions[itemID]:
                            self.__sliderChangedFunctions[itemID].append(function)
                    else:
                        self.__sliderChangedFunctions[itemID] = [function]
                    func_list = self.__sliderChangedFunctions[itemID]
                if trigger == 'Pressed':
                    if itemID in self.__sliderPressedFunctions.keys():
                        if function not in self.__sliderPressedFunctions[itemID]:
                            self.__sliderPressedFunctions[itemID].append(function)
                    else:
                        self.__sliderPressedFunctions[itemID] = [function]
                    func_list = self.__sliderPressedFunctions[itemID]
                if trigger == 'Released':
                    if itemID in self.__sliderReleasedFunctions.keys():
                        if function not in self.__sliderReleasedFunctions[itemID]:
                            self.__sliderReleasedFunctions[itemID].append(function)
                    else:
                        self.__sliderReleasedFunctions[itemID] = [function]
                    func_list = self.__sliderReleasedFunctions[itemID]
                for tp in self.devTPs:
                    @event(self.__sliders[self.devTPs.index(tp)][itemID],trigger)
                    def stuff(slider,state,value):
                        for func in func_list:
                            try:
                                func(slider,state)
                            except Exception as e:
                                print('exception calling function for slider {} state:{} :{}'.format(slider.ID,state,e))
            else:
                print('Addfunction Failed : invalid ID ',str(itemID))

    # modify values of items for each panel by ID number or name
    def SetState(self,itemIDs:'list[int]',value:int):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.__btnIDs:
                for tp in self.devTPs:
                    item = self.__btns[self.devTPs.index(tp)][itemID]
                    item.SetState(value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetState({})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            else:
                print('SetState Failed : invalid ID ',str(itemID))
    def SetText(self,itemIDs:'list[int]',value:str):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.__btnIDs:
                for tp in self.devTPs:
                    item = self.__btns[self.devTPs.index(tp)][itemID]
                    item.SetText(value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetText({})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            elif itemID in self.__lblIDs:
                for tp in self.devTPs:
                    item = self.__lbls[self.devTPs.index(tp)][itemID]
                    item.SetText(value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetText({})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            else:
                print('SetText Failed : invalid ID ',str(itemID))
    def SetBlinking(self,itemIDs:'list[int]',rate:str,value:'list[int]'):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.__btnIDs:
                for tp in self.devTPs:
                    item = self.__btns[self.devTPs.index(tp)][itemID]
                    item.SetBlinking(rate,value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetBlinking({},{})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,rate,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            else:
                print('SetBlinking Failed : invalid ID ',str(itemID))
    def SetLevel(self,itemIDs:'list[int]',value:int):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.__lvlIDs:
                for tp in self.devTPs:
                    item = self.__lvls[self.devTPs.index(tp)][itemID]
                    item.SetLevel(value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetLevel({})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            else:
                print('SetLevel Failed : invalid ID ',str(itemID))
    def SetFill(self,itemIDs:'list[int]',value:int):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.__sliderIDs:
                for tp in self.devTPs:
                    item = self.__sliders[self.devTPs.index(tp)][itemID]
                    item.SetFill(value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetFill({})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            else:
                print('SetFill Failed : invalid ID ',str(itemID))

    def SetEnable(self,itemIDs:'list[int]',value:bool):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.__btnIDs:
                for tp in self.devTPs:
                    item = self.__btns[self.devTPs.index(tp)][itemID]
                    item.SetEnable(value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetEnable({})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            elif itemID in self.__sliderIDs:
                for tp in self.devTPs:
                    item = self.__sliders[self.devTPs.index(tp)][itemID]
                    item.SetEnable(value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetEnable({})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            else:
                print('SetEnable Failed : invalid ID ',str(itemID))
    def SetVisible(self,itemIDs:'list[int]',value:bool):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.__btnIDs:
                for tp in self.devTPs:
                    item = self.__btns[self.devTPs.index(tp)][itemID]
                    item.SetVisible(value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetVisible({})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            elif itemID in self.__lblIDs:
                for tp in self.devTPs:
                    self.__lbls[self.devTPs.index(tp)][itemID].SetVisible(value)
                    item = self.__lbls[self.devTPs.index(tp)][itemID]
                    item.SetVisible(value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetVisible({})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            elif itemID in self.__lvlIDs:
                for tp in self.devTPs:
                    self.__lvls[self.devTPs.index(tp)][itemID].SetVisible(value)
                    item = self.__lvls[self.devTPs.index(tp)][itemID]
                    item.SetVisible(value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetVisible({})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            elif itemID in self.__sliderIDs:
                for tp in self.devTPs:
                    self.__sliders[self.devTPs.index(tp)][itemID].SetVisible(value)
                    item = self.__sliders[self.devTPs.index(tp)][itemID]
                    item.SetVisible(value)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetVisible({})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,value)
                print(str_to_send)
                self.__printToServer(str_to_send)
            else:
                print('SetVisible Failed : invalid ID ',str(itemID))
    def SetRange(self,itemIDs:'list[int]',minimum:int,maximum:int,step:int = 1):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.__lvlIDs:
                for tp in self.devTPs:
                    item = self.__lvls[self.devTPs.index(tp)][itemID]
                    item.SetRange(minimum,maximum,step)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetRange({},{},{})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,minimum,maximum,step)
                print(str_to_send)
                self.__printToServer(str_to_send)
            elif itemID in self.__sliderIDs:
                for tp in self.devTPs:
                    item = self.__sliders[self.devTPs.index(tp)][itemID]
                    item.SetRange(minimum,maximum,step)
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ SetRange({},{},{})'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name,minimum,maximum,step)
                print(str_to_send)
                self.__printToServer(str_to_send)
            else:
                print('SetRange Failed : invalid ID ',str(itemID))
    def Dec(self,itemIDs:'list[int]'):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.__lvlIDs:
                for tp in self.devTPs:
                    self.__lvls[self.devTPs.index(tp)][itemID].Dec()
                    item = self.__lvls[self.devTPs.index(tp)][itemID]
                    item.Dec()
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ Dec()'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name)
                print(str_to_send)
                self.__printToServer(str_to_send)
            else:
                print('Dec Failed : invalid ID ',str(itemID))
    def Inc(self,itemIDs:'list[int]'):
        idList = []
        if type(itemIDs) is type([]):
            idList.extend(itemIDs)
        else:
            idList.append(itemIDs)
        for itemID in idList:
            if itemID in self.__lvlIDs:
                for tp in self.devTPs:
                    self.__lvls[self.devTPs.index(tp)][itemID].Inc()
                    item = self.__lvls[self.devTPs.index(tp)][itemID]
                    item.Inc()
                str_to_send = 'command: VirtualUI({}) ~ {}({},{}) ~ Inc()'.format(self.__friendly_name,type(item).__name__,item.ID,item.Name)
                print(str_to_send)
                self.__printToServer(str_to_send)
            else:
                print('Inc Failed : invalid ID ',str(itemID))

    def SimulateAction(self,itemID:int,action:str):
        if itemID in self.__btnIDs:
            try:
                getattr(self.__btns[0][itemID], '%s' % action)()
            except AttributeError:
                print('{0} does not support {1}.'.format(self.__btns[0][itemID].ID,action))

    def SetCurrent(self,btnIDs:'list[int]',item:int):
        for btnID in btnIDs:
            str_to_send = 'command: VirtualUI({}) ~ Button({}) ~ SetCurrent()'.format(self.__friendly_name,type(item).__name__,btnIDs,item)
            print(str_to_send)
            self.__printToServer(str_to_send)
            if btnID == item:
                self.SetState(btnID,1)
            else:
                self.SetState(btnID,0)
    def __printToServer(self,string:str):
        timestamp = str(datetime.now())
        str_to_send = repr(string)
        str_to_send = '{} {}'.format(timestamp,str_to_send[1:])
        self._DebugServer__send_interface_communication(self.__listening_port,str_to_send)

    def HandleReceiveFromServer(self,client,data:'bytes'):
        serverBuffer = ''
        try:
            serverBuffer += data.decode()
        except:
            serverBuffer += data
        if 'SetState(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            try:
                temp1 = [int(i) for i in temp1]
            except:
                temp1 = None
            temp2 = temp_dict['value2']
            try:
                temp2 = int(temp2)
            except:
                temp2 = -1
            if self.__interface and temp1 and temp2>=0:
                self.SetState(temp1,temp2)
        if 'SetText(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            try:
                temp1 = [int(i) for i in temp1]
            except:
                temp1 = None
            temp2 = temp_dict['value2']
            if self.__interface and temp1:
                self.SetText(temp1,temp2)
        if 'SetBlinking(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            try:
                temp1 = [int(i) for i in temp1]
            except:
                temp1 = None
            temp2=temp_dict['value2']
            temp3=temp_dict['value3']
            try:
                temp3 = [int(i) for i in temp3]
            except:
                temp3 = None
            if self.__interface and temp1 and temp2 and temp3:
                self.SetBlinking(temp1,temp2,temp3)
        if 'SetLevel(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            try:
                temp1 = [int(i) for i in temp1]
            except:
                temp1 = None
            temp2=temp_dict['value2']
            try:
                temp2 = int(temp2)
            except:
                temp2 = -1
            if self.__interface and temp1 and temp2>=0:
                self.SetLevel(temp1,temp2)
        if 'SetFill(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            try:
                temp1 = [int(i) for i in temp1]
            except:
                temp1 = None
            temp2=temp_dict['value2']
            try:
                temp2 = int(temp2)
            except:
                temp2 = -1
            if self.__interface and temp1 and temp2>=0:
                self.SetFill(temp1,temp2)
        if 'SetEnable(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            try:
                temp1 = [int(i) for i in temp1]
            except:
                temp1 = None
            temp2=temp_dict['value2']
            vals = {'True':True,'False':False}
            if temp2 not in vals:
                temp2 = None
            if self.__interface and temp1 and temp2 in ['True','False']:
                self.SetEnable(temp1,vals[temp2])
        if 'SetVisible(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            try:
                temp1 = [int(i) for i in temp1]
            except:
                temp1 = None
            temp2=temp_dict['value2']
            vals = {'True':True,'False':False}
            if temp2 not in vals:
                temp2 = None
            if self.__interface and temp1 and temp2 in ['True','False']:
                self.SetVisible(temp1,vals[temp2])
        if 'SetRange(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            try:
                temp1 = [int(i) for i in temp1]
            except:
                temp1 = None
            temp2=temp_dict['value2']
            try:
                temp2 = int(temp2)
            except:
                temp2 = -1000
            temp3=temp_dict['value3']
            try:
                temp3 = int(temp3)
            except:
                temp3 = -1000
            temp4=temp_dict['value4']
            try:
                temp4 = int(temp4)
            except:
                temp4 = 1
            if self.__interface and temp1 and temp2>-1000 and temp3>-1000 and temp4>0:
                self.SetRange(temp1,temp2,temp3,temp4)
        if 'Dec(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            try:
                temp1 = [int(i) for i in temp1]
            except:
                temp1 = None
            if self.__interface and temp1:
                self.Dec(temp1)
        if 'Inc(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            try:
                temp1 = [int(i) for i in temp1]
            except:
                temp1 = None
            if self.__interface and temp1:
                self.Inc(temp1)
        if 'ShowPage(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp=temp_dict['value1']
            if self.__interface and temp:
                self.ShowPage(temp)
        if 'ShowPopup(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp1=temp_dict['value1']
            temp2=temp_dict['value2']
            try:
                temp2 = int(temp2)
            except:
                temp2 = 0
            if self.__interface and temp1:
                self.ShowPopup(temp1,temp2)
        if 'HidePopupGroup(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp=temp_dict['value1']
            try:
                temp = int(temp)
            except:
                return
            if self.__interface and temp >= 0:
                self.HidePopupGroup(temp)
        if 'HidePopup(' in serverBuffer:
            temp = serverBuffer[serverBuffer.find('(')+1:serverBuffer.rfind(')')]
            try:
                temp_dict = json.loads(temp)
            except Exception as e:
                print('failed to parse mute command:{}'.format(e))
                return
            temp=temp_dict['value1']
            if self.__interface and temp:
                self.HidePopup(temp)
        if 'HideAllPopups(' in serverBuffer:
            if self.__interface:
                self.HideAllPopups()















'''
to allow for more dynamic programs, this class allows multiple event handlers to be attached to a status.  It will execute the handlers in the order that was subscribed

ex:
module.SubscribeStatus('EventName',qualifier,function1)
module.SubscribeStatus('EventName',qualifier,function2)

'''





class ModuleSubscribeWrapper():
    def __init__(self,mod,__debug_info=None):
        self.__debug_info = __debug_info
        self.mod = mod

    def NewStatus(self, command, value, qualifier):
        if self.__debug_info:
            print("{} : subscriber new status: {} {} {}".format(self.__debug_info,command,value,qualifier))
        if command in self.mod.Subscription:
            Subscribe = self.mod.Subscription[command]
            Method = Subscribe['method']
            Command = self.mod.Commands[command]
            if qualifier:
                for Parameter in Command['Parameters']:
                    try:
                        Method = Method[qualifier[Parameter]]
                    except:
                        break
            if 'callback' in Method and Method['callback']:
                if self.__debug_info:
                    print("{} : subscriber new status callbacks{}: {} {} {}".format(self.__debug_info,len(Method['callback']),command,value,qualifier))
                for callback in Method['callback']:
                    callback(command, value, qualifier)

    def SubscribeStatus(self, command, qualifier, callback):

        Command = self.mod.Commands.get(command)
        if Command:
            if command not in self.mod.Subscription:
                self.mod.Subscription[command] = {'method': {}}

            Subscribe = self.mod.Subscription[command]
            Method = Subscribe['method']

            if qualifier:
                for Parameter in Command['Parameters']:
                    try:
                        Method = Method[qualifier[Parameter]]
                    except:
                        if Parameter in qualifier:
                            Method[qualifier[Parameter]] = {}
                            Method = Method[qualifier[Parameter]]
                        else:
                            return
            if 'callback' in Method.keys():
                Method['callback'].append(callback)
                if self.__debug_info:
                    print("{} : subscriber callback add {}: {} {}".format(self.__debug_info,len(Method['callback']),command,qualifier))
            else:
                Method['callback'] = [callback]
                if self.__debug_info:
                    print("{} : subscriber callback add {}: {} {}".format(self.__debug_info,len(Method['callback']),command,qualifier))
            Method['qualifier'] = qualifier
        else:
            print(command, 'does not exist in the module')































'''
creates a dictionary of devices with their values.  upon connection to the given ip port, prints the dictionary in json format to telnet interface.
also prints updates to these values as they occur.

example:

from tools import status_report


sr = status_report(3001)
sr.update('Display','ConnectionStatus','Connected')


'''


class status_report():
    def __init__(self,listening_port=2000,interface='AVLAN'):
        self.listening_port = listening_port
        self.serverBuffer = ''
        self.clientCount = 0
        self.cmdflag = False
        self.interface = interface
        self.info = {}
        self.serv= EthernetServerInterfaceEx(self.listening_port,'TCP',Interface=interface,MaxClients=5)
        self.__startServer()
        self.__startEvents()
    def __register(self,d:'str',s:'str'):
        self.info[d] = {'statuses':{s:''}}
    def __send_single(self,d:'str',s:'str'):
        j = {}
        j[d] = {'statuses':{s:self.info[d]['statuses'][s]}}
        data = json.dumps(j)
        self.__send(data)
    def __send_all(self):
        data = json.dumps(self.info)
        self.__send(data)
    def __startServer(self):
        """Start the server.  Reattempt on failure after 1s."""
        print('StatusReport:startServer: port {0} starting'.format(self.listening_port))
        res = self.serv.StartListen()
        if res != 'Listening':   # Port unavailable
            print('StatusReport:startServer: port {0} unavailable: result={}'.format(self.listening_port,res))
            Wait(1, self.__startServer)
    def __send(self, string):
        if(self.clientCount > 0):
            for client in self.serv.Clients:
                client.Send('{0}'.format(string))
    def __startEvents(self):
        @event(self.serv, 'ReceiveData')
        def HandheReceiveFromServer(client,data):
            pass
        @event(self.serv, 'Connected')
        def HandleClientConnect(interface, state):
            self.clientCount += 1
            print('status_report:Client connected to {0} ({1}).'.format(self.listening_port,interface.IPAddress))
            self.__send_all()
        @event(self.serv, 'Disconnected')
        def HandleClientDisconnect(interface, state):
            self.clientCount = 0
            print('status_report:Client disconnected from {0}).'.format(self.listening_port))
            self.serv.StopListen()
            self.__startServer()

    def Update(self,d:'str',s:'str',v):
        if d not in self.info:
            self.__register(d,s)
        self.info[d]['statuses'][s] = v
        if self.clientCount > 0:
            self.__send_single(d,s)


















































'''
saves a dictionary of values (basic types only) to file as a json object, allows for manipulation of them and recovery.
the optional parameter 'auto_sync_time' allows for saving of the variables to file automatically on a regular interval. (in seconds)

multiple callback functions may be added as needed to make code more readable, not all variables need to be handled in the same callback.

example:

from tools import NonvolatileValues

#default startup values
var1 = ''
var2 = 0
var3 = [False,False]

nvram = NonvolatileValues('filename.dat')
def handle_nvram_var1_var2(values:'dict'):
    global var1
    global var2

    if 'var1key' in values:
        var1 = values['var1key']
    if 'var2key' in values:
        var2 = values['var2key']

def handle_nvram_var3(values:'dict'):
    global var3
    if 'var3key' in values:
        var3 = values['var3key']

nvram.AddSyncValuesFunction(handle_nvram_var1_var2)
nvram.AddSyncValuesFunction(handle_nvram_var3)
nvram.ReadValues()


def update_nvram():
    global var1
    global var2
    global var3
    var1 = 'new value'
    var2 = 1
    var3[1] = True

    nvram.SetValue('var1key',var1)
    nvram.SetValue('var2key',var2)
    nvram.SetValue('var3key',var3)
    nvram.SaveValues() # must be explicitly saved after updating if 'auto_sync_time' not used.


'''


class NonvolatileValues():
    def __init__(self,filename:'str',auto_sync_time:'float'= None) -> None:
        self.__filename = filename
        self.__auto_sync_time = auto_sync_time
        self.values = {}
        self.__syncvaluesfunctions = []

        if self.__auto_sync_time:
            @Timer(self.__auto_sync_time)
            def auto_sync_function(timer,count):
                self.SaveValues()


    def ReadValues(self):
        f = None
        values = {}
        try:
            f = File(self.__filename,'rt')
        except Exception as e:
            print('NonvolatileValues: failed to open and read file:{}'.format(e))
        if f:
            try:
                values = json.load(f)
            except Exception as e:
                print('NonvolatileValues: failed to convert to dict, deleting file:{}'.format(e))
                File.DeleteFile(self.__filename)
            f.close()
        self.values = values
        if self.__syncvaluesfunctions:
            for f in self.__syncvaluesfunctions:
                f(self.values)

    def SetValue(self,id:'str',value):
        self.values[id] = value

    def GetValue(self,id:'str'):
        return self.values[id]

    def GetAllValues(self):
        if self.__syncvaluesfunctions:
            for f in self.__syncvaluesfunctions:
                f(self.values)

    def SaveValues(self):
        f = None
        try:
            f = File(self.__filename,'wt') #try writing
        except Exception as e:
            f = File(self.__filename,'x') #create file and open for writing
            f = File(self.__filename,'wt')
        if f:
            try:
                print('NonvolatileValues: dumping dictionary:{}'.format(self.values))
                json.dump(self.values,f)
            except Exception as e:
                print('NonvolatileValues: unable to dump dictionary:{}:{}'.format(e,self.values))
            f.close()
        self.ReadValues()


    def AddSyncValuesFunction(self,func):
        self.__syncvaluesfunctions.append(func)











class ProgramLogSaver():
    __now = datetime.now()
    __nowstr = __now.strftime('%Y-%m-%d-%H-%M-%S')
    __filename = '{}-{}.log'.format('ProgramLog',__nowstr)
    __cur_log = ''

    def __readdummyprogramlog():
        f = None
        log = None
        try:
            f = File('temp.log','r')
        except Exception as e:
            print('ProgramLogSaver: failed to open file:{}'.format(e))
        if f:
            try:
                log = f.read()
            except Exception as e:
                print('ProgramLogSaver: failed to read file:{}'.format(e))
            f.close()
        return log


    def __saveprogramlog():
        with File(ProgramLogSaver.__filename, 'w') as f:
            SaveProgramLog(f)
    def __savedummyprogramlog():
        with File('temp.log', 'w') as f:
            SaveProgramLog(f)

    def __checkprogramlog(timer,count):
        ProgramLogSaver.__savedummyprogramlog()
        log = ProgramLogSaver.__readdummyprogramlog()
        if log != ProgramLogSaver.__cur_log:
            ProgramLogSaver.__cur_log = log
            ProgramLogSaver.__saveprogramlog()
            print('ProgramLogSaver: new log saved')

    __save_timer = Timer(60,__checkprogramlog)
    __save_timer.Stop()
    def StartProgramLog():
        ProgramLogSaver.__save_timer.Restart()