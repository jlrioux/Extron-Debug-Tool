from tkinter import *


class TouchPanelDevices():
    def __init__(self,frame:'Frame'):
        #class variables
        self.__frame = frame
        self.selected_module = None

        #set up the UI
        self.frame_devices_found = Frame(frame,height=20,width=20)
        self.frame_devices_found.grid(column=0,row=0,sticky='nw')
        self.lbl_devices_found = Label(self.frame_devices_found,text = ' Devices Found: ')
        self.lbl_devices_found.grid(column=0,row=0)
        self.lbox_devices = Listbox(self.frame_devices_found,selectmode=SINGLE,)
        self.lbox_devices.grid(column=0,row=1,sticky='nsew',pady=2)
        self.scrollb_devices = Scrollbar(self.frame_devices_found,command=self.lbox_devices.yview)
        self.scrollb_devices.grid(column=1,row=1,sticky='nsew',pady=2)
        self.lbox_devices['yscrollcommand'] = self.scrollb_devices.set
        self.lbox_devices.bind("<<ListboxSelect>>",self.__select_module_callback)

        self.frame_log = Frame(frame,padx=10)
        self.frame_log.grid(column=1,row=0,sticky='e')
        self.tb_log = Text(self.frame_log,height=20,width=70,wrap='none')
        self.tb_log.grid(column=0,row=0,sticky='nw')
        self.scrollb_logy = Scrollbar(self.frame_log,command=self.tb_log.yview)
        self.scrollb_logy.grid(column=1,row=0,sticky='nsew')
        self.tb_log['yscrollcommand'] = self.scrollb_logy.set
        self.scrollb_logx = Scrollbar(self.frame_log,orient='horizontal',command=self.tb_log.xview)
        self.scrollb_logx.grid(column=0,row=1,sticky='nsew')
        self.tb_log['xscrollcommand'] = self.scrollb_logx.set

        #some test data
        self.lbox_devices.insert('end','tp1','tp2','tp3','tp4')

    #class methods
    def __select_module_callback(self,event):
        self.selected_module = self.lbox_devices.curselection()[0]
        print(self.selected_module)

    #public functions
    def Hide(self):
        self.__frame._grid_info = self.__frame.grid_info()
        self.__frame.grid_remove()
    def Show(self):
        self.__frame.grid(**self.__frame._grid_info)
