
from tkinter import *
from Timer import Timer
import json
import re
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from variables import variablesclass

class EthernetAndSerialDevices():
    def __init__(self,frame:'Frame',vars:'variablesclass'):
        #class variables
        self.vars = vars
        self.__frame = frame
        self.__selected_module = None
        self.__timestamp_newest_first = True

        self.__device_logs = {} #type:dict[list[str]]
        self.__current_tb_log = ''
        self.__tb_pause_flag = False
        self.__tb_hex_flag = False

        #set up the UI
        self.__frame_controller_status = Frame(self.__frame)
        self.__frame_controller_status.grid(column=0,row=0,sticky='nw')
        self.__lbl_controller_status = Label(self.__frame_controller_status,text = ' STATUS : Controller Disconnected')
        self.__lbl_controller_status.grid(column=0,row=0,sticky='nw')

        self.__frame_controller_views = Frame(self.__frame)
        self.__frame_controller_views.grid(column=1,row=0,sticky='nw')
        self.__btn_tb_view_rxtx_view = Button(self.__frame_controller_views,text="RX/TX View",command=self.__controller_rxtx_view_enable)
        self.__btn_tb_view_rxtx_view.grid(column=0,row=0,sticky='nw')
        self.__btn_tb_view_status_view = Button(self.__frame_controller_views,text="Status View",command=self.__controller_status_view_enable)
        self.__btn_tb_view_status_view.grid(column=1,row=0,sticky='nw')

        self.__frame_controller_clear_logs = Frame(self.__frame_controller_views)
        self.__frame_controller_clear_logs.grid(column=2,row=0,sticky='nw')
        self.__btn_tb_clear_all_logs = Button(self.__frame_controller_clear_logs,text="Clear All Logs",command=self.__clear_all_device_logs)
        self.__btn_tb_clear_all_logs.grid(column=0,row=0,sticky='ne')

        self.__frame_devices_found = Frame(self.__frame,height=40,width=20)
        self.__frame_devices_found.grid(column=0,row=1,sticky='nw')
        self.__frame_devices_found_upper = Frame(self.__frame_devices_found,height=20,width=20)
        self.__frame_devices_found_upper.grid(column=0,row=0,sticky='nw')
        self.__lbl_devices_found = Label(self.__frame_devices_found_upper,text = ' Devices Found: ')
        self.__lbl_devices_found.grid(column=0,row=0)
        self.__lbox_devices = Listbox(self.__frame_devices_found_upper,selectmode=SINGLE,)
        self.__lbox_devices.grid(column=0,row=1,sticky='nsew',pady=2)
        self.__scrollb_devices = Scrollbar(self.__frame_devices_found_upper,command=self.__lbox_devices.yview)
        self.__scrollb_devices.grid(column=1,row=1,sticky='nsew',pady=2)
        self.__lbox_devices['yscrollcommand'] = self.__scrollb_devices.set
        self.__lbox_devices.bind("<<ListboxSelect>>",self.__select_module)
        self.__btn_device_reinit = Button(self.__frame_devices_found_upper,text='Reinitialize Module',command=self.__cmd_reinitialize_selected_module)
        self.__btn_device_reinit.grid(column=0,row=2,sticky='nsew',pady=2)

        self.__frame_devices_found_lower = Frame(self.__frame_devices_found,height=20,width=20)
        self.__frame_devices_found_lower.grid(column=0,row=1,sticky='nw')
        self.__lbl_selected_device_name = Label(self.__frame_devices_found_lower,text = ' Selected: None')
        self.__lbl_selected_device_name.grid(column=0,row=0,sticky='nw')
        self.__lbl_device_comm_detail1 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail1.grid(column=0,row=1,sticky='nw')
        self.__lbl_device_comm_detail2 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail2.grid(column=0,row=2,sticky='nw')
        self.__lbl_device_comm_detail3 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail3.grid(column=0,row=3,sticky='nw')
        self.__lbl_device_comm_detail4 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail4.grid(column=0,row=4,sticky='nw')
        self.__lbl_device_comm_detail5 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail5.grid(column=0,row=5,sticky='nw')
        self.__lbl_device_comm_detail6 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail6.grid(column=0,row=6,sticky='nw')
        self.__lbl_device_comm_detail7 = Label(self.__frame_devices_found_lower,text = ' ')
        self.__lbl_device_comm_detail7.grid(column=0,row=7,sticky='nw')

        self.__frame_log = Frame(self.__frame,padx=10)
        self.__frame_log.grid(column=1,row=1,sticky='w')

        self.__frame_log_top = Frame(self.__frame_log)
        self.__frame_log_top.grid(column=0,row=0,sticky='w')
        self.__btn_tb_sort_timestamp = Button(self.__frame_log_top,text="Timestamp:Newest",command=self.__toggle_tb_timestamp)
        self.__btn_tb_sort_timestamp.grid(column=0,row=0,sticky='nw')
        self.__btn_tb_clear_log = Button(self.__frame_log_top,text="Clear Log",command=self.__clear_current_device_log)
        self.__btn_tb_clear_log.grid(column=1,row=0,sticky='nw')
        self.__btn_tb_pause_log = Button(self.__frame_log_top,text="Pause Log",command=self.__pause_current_device_log)
        self.__btn_tb_pause_log.grid(column=2,row=0,sticky='nw')
        self.__btn_tb_hex_format = Button(self.__frame_log_top,text="Display HEX",command=self.__format_device_log)
        self.__btn_tb_hex_format.grid(column=3,row=0,sticky='nw')

        self.__tb_log = Text(self.__frame_log,height=20,width=95,wrap='none')
        self.__tb_log.grid(column=0,row=1,sticky='nw')
        self.__scrollb_logy = Scrollbar(self.__frame_log,command=self.__tb_log.yview)
        self.__scrollb_logy.grid(column=1,row=1,sticky='nsew')
        self.__tb_log['yscrollcommand'] = self.__scrollb_logy.set
        self.__scrollb_logx = Scrollbar(self.__frame_log,orient='horizontal',command=self.__tb_log.xview)
        self.__scrollb_logx.grid(column=0,row=2,sticky='nsew')
        self.__tb_log['xscrollcommand'] = self.__scrollb_logx.set

        self.__frame_status = Frame(self.__frame,padx=10)
        self.__frame_status.grid(column=1,row=1,sticky='e')
        self.__tb_status = Text(self.__frame_status,height=20,width=95,wrap='none')
        self.__tb_status.grid(column=0,row=0,sticky='nw')
        self.__scrollb_statusy = Scrollbar(self.__frame_status,command=self.__tb_status.yview)
        self.__scrollb_statusy.grid(column=1,row=0,sticky='nsew')
        self.__tb_status['yscrollcommand'] = self.__scrollb_statusy.set
        self.__scrollb_statusx = Scrollbar(self.__frame_status,orient='horizontal',command=self.__tb_status.xview)
        self.__scrollb_statusx.grid(column=0,row=1,sticky='nsew')
        self.__tb_status['xscrollcommand'] = self.__scrollb_statusx.set





        self.__frame_device_commands = Frame(self.__frame,pady=10)
        self.__frame_device_commands.grid(column=1,row=2,sticky='w')

        self.__frame_device_commands_for_modules = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_modules.grid(column=0,row=0,sticky='w')
        self.__frame_device_commands_for_modules_top = Frame(self.__frame_device_commands_for_modules)
        self.__frame_device_commands_for_modules_top.grid(column=0,row=0,sticky='w')
        #Set(command,value,qualifier)
        self.__lbl_commands_module_set1 = Label(self.__frame_device_commands_for_modules_top,text='Command')
        self.__lbl_commands_module_set1.grid(column=1,row=0,sticky='w')
        self.__lbl_commands_module_set2 = Label(self.__frame_device_commands_for_modules_top,text='Value')
        self.__lbl_commands_module_set2.grid(column=2,row=0,sticky='w')
        self.__lbl_commands_module_set3 = Label(self.__frame_device_commands_for_modules_top,text='Qualifier ( example: {"Output":"1"} )')
        self.__lbl_commands_module_set3.grid(column=3,row=0,sticky='w')
        self.__btn_cmd_set = Button(self.__frame_device_commands_for_modules_top,text="Set",width=15,command=self.__cmd_set_selected_module)
        self.__btn_cmd_set.grid(column=0,row=1,sticky='w')
        self.__tb_set_command1 = Text(self.__frame_device_commands_for_modules_top,height=1,width=15,wrap='none')
        self.__tb_set_command1.grid(column=1,row=1,sticky='w')
        self.__tb_set_command2 = Text(self.__frame_device_commands_for_modules_top,height=1,width=20,wrap='none')
        self.__tb_set_command2.grid(column=2,row=1,sticky='w')
        self.__tb_set_command3 = Text(self.__frame_device_commands_for_modules_top,height=1,width=30,wrap='none')
        self.__tb_set_command3.grid(column=3,row=1,sticky='w')
        #Update(command,qualifier)
        self.__lbl_commands_module_update1 = Label(self.__frame_device_commands_for_modules_top,text='Command')
        self.__lbl_commands_module_update1.grid(column=1,row=2,sticky='w')
        self.__lbl_commands_module_update2 = Label(self.__frame_device_commands_for_modules_top,text='Qualifier ( example: {"Output":"1"} )')
        self.__lbl_commands_module_update2.grid(column=3,row=2,sticky='w')
        self.__btn_cmd_update = Button(self.__frame_device_commands_for_modules_top,text='Update',width=15,command=self.__cmd_update_selected_module)
        self.__btn_cmd_update.grid(column=0,row=3,sticky='w')
        self.__tb_update_command1 = Text(self.__frame_device_commands_for_modules_top,height=1,width=15,wrap='none')
        self.__tb_update_command1.grid(column=1,row=3,sticky='w')
        self.__tb_update_command2 = Text(self.__frame_device_commands_for_modules_top,height=1,width=30,wrap='none')
        self.__tb_update_command2.grid(column=3,row=3,sticky='w')
        #WriteStatus(command,value,qualifier)
        self.__lbl_commands_module_writestatus1 = Label(self.__frame_device_commands_for_modules_top,text='Command')
        self.__lbl_commands_module_writestatus1.grid(column=1,row=4,sticky='w')
        self.__lbl_commands_module_writestatus2 = Label(self.__frame_device_commands_for_modules_top,text='Value')
        self.__lbl_commands_module_writestatus2.grid(column=2,row=4,sticky='w')
        self.__lbl_commands_module_writestatus3 = Label(self.__frame_device_commands_for_modules_top,text='Qualifier ( example: {"Output":"1"} )')
        self.__lbl_commands_module_writestatus3.grid(column=3,row=4,sticky='w')
        self.__btn_cmd_writestatus = Button(self.__frame_device_commands_for_modules_top,text='WriteStatus',width=15,command=self.__cmd_writestatus_selected_module)
        self.__btn_cmd_writestatus.grid(column=0,row=5,sticky='w')
        self.__tb_writestatus_command1 = Text(self.__frame_device_commands_for_modules_top,height=1,width=15,wrap='none')
        self.__tb_writestatus_command1.grid(column=1,row=5,sticky='w')
        self.__tb_writestatus_command2 = Text(self.__frame_device_commands_for_modules_top,height=1,width=20,wrap='none')
        self.__tb_writestatus_command2.grid(column=2,row=5,sticky='w')
        self.__tb_writestatus_command3 = Text(self.__frame_device_commands_for_modules_top,height=1,width=30,wrap='none')
        self.__tb_writestatus_command3.grid(column=3,row=5,sticky='w')
        self.__frame_device_commands_for_modules_bottom = Frame(self.__frame_device_commands_for_modules)
        self.__frame_device_commands_for_modules_bottom.grid(column=0,row=1,sticky='w')
        #Passthrough
        self.__lbl_passthrough_commmand = Label(self.__frame_device_commands_for_modules_bottom,text='Command ( example: power on\\x0d\\x0a )')
        self.__lbl_passthrough_commmand.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_passthrough = Button(self.__frame_device_commands_for_modules_bottom,text='Passthrough',width=15,command=self.__cmd_passthrough_selected_module)
        self.__btn_cmd_passthrough.grid(column=0,row=1,sticky='w')
        self.__tb_passthrough_command = Text(self.__frame_device_commands_for_modules_bottom,height=1,width=65,wrap='none')
        self.__tb_passthrough_command.grid(column=1,row=1,sticky='w')

        self.__frame_device_commands_for_circuit_breaker = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_circuit_breaker.grid(column=0,row=1,sticky='w')
        #none

        self.__frame_device_commands_for_contact = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_contact.grid(column=0,row=2,sticky='w')
        #none

        self.__frame_device_commands_for_digital_input = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_digital_input.grid(column=0,row=3,sticky='w')
        #Initialize (host,port,pullup)
        self.__lbl_device_commands_digital_input_initialize1 = Label(self.__frame_device_commands_for_digital_input,text='Pullup')
        self.__lbl_device_commands_digital_input_initialize1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_digital_input_initialize = Button(self.__frame_device_commands_for_digital_input,text='Initialize',width=15,command=self.__cmd_initialize_selected_device)
        self.__btn_cmd_digital_input_initialize.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_digital_input_initialize1 = Text(self.__frame_device_commands_for_digital_input,height=1,width=20,wrap='none')
        self.__tb_cmd_digital_input_initialize1.grid(column=1,row=1,sticky='w')

        self.__frame_device_commands_for_digital_io = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_digital_io.grid(column=0,row=4,sticky='w')
        #Initialize (host,port,pullup)
        self.__lbl_device_commands_digital_io_initialize1 = Label(self.__frame_device_commands_for_digital_io,text='Mode')
        self.__lbl_device_commands_digital_io_initialize1.grid(column=1,row=0,sticky='w')
        self.__lbl_device_commands_digital_io_initialize2 = Label(self.__frame_device_commands_for_digital_io,text='Pullup')
        self.__lbl_device_commands_digital_io_initialize2.grid(column=2,row=0,sticky='w')
        self.__btn_cmd_digital_io_initialize = Button(self.__frame_device_commands_for_digital_io,text='Initialize',width=15,command=self.__cmd_initialize_selected_device)
        self.__btn_cmd_digital_io_initialize.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_digital_io_initialize1 = Text(self.__frame_device_commands_for_digital_io,height=1,width=20,wrap='none')
        self.__tb_cmd_digital_io_initialize1.grid(column=1,row=1,sticky='w')
        self.__tb_cmd_digital_io_initialize2 = Text(self.__frame_device_commands_for_digital_io,height=1,width=20,wrap='none')
        self.__tb_cmd_digital_io_initialize2.grid(column=2,row=1,sticky='w')
        #Pulse(duration)
        self.__lbl_device_commands_digital_io_pulse1 = Label(self.__frame_device_commands_for_digital_io,text='Duration')
        self.__lbl_device_commands_digital_io_pulse1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_digital_io_pulse = Button(self.__frame_device_commands_for_digital_io,text='Pulse',width=15,command=self.__cmd_pulse_selected_device)
        self.__btn_cmd_digital_io_pulse.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_digital_io_pulse1 = Text(self.__frame_device_commands_for_digital_io,height=1,width=20,wrap='none')
        self.__tb_cmd_digital_io_pulse1.grid(column=1,row=3,sticky='w')
        #State('On' or 'Off')
        self.__lbl_device_commands_digital_io_state1 = Label(self.__frame_device_commands_for_digital_io,text='On or Off')
        self.__lbl_device_commands_digital_io_state1.grid(column=1,row=4,sticky='w')
        self.__btn_cmd_digital_io_state = Button(self.__frame_device_commands_for_digital_io,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_digital_io_state.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_digital_io_state1 = Text(self.__frame_device_commands_for_digital_io,height=1,width=20,wrap='none')
        self.__tb_cmd_digital_io_state1.grid(column=1,row=5,sticky='w')
        #Toggle
        self.__btn_cmd_digital_io_toggle = Button(self.__frame_device_commands_for_digital_io,text='Toggle',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_digital_io_toggle.grid(column=0,row=6,sticky='w')

        self.__frame_device_commands_for_flex_io = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_flex_io.grid(column=0,row=5,sticky='w')
        #initialize (mode,pullup,upper,lower)
        self.__lbl_device_commands_flex_io_initialize1 = Label(self.__frame_device_commands_for_flex_io,text='Mode')
        self.__lbl_device_commands_flex_io_initialize1.grid(column=1,row=0,sticky='w')
        self.__lbl_device_commands_flex_io_initialize2 = Label(self.__frame_device_commands_for_flex_io,text='Pullup')
        self.__lbl_device_commands_flex_io_initialize2.grid(column=2,row=0,sticky='w')
        self.__lbl_device_commands_flex_io_initialize3 = Label(self.__frame_device_commands_for_flex_io,text='Upper')
        self.__lbl_device_commands_flex_io_initialize3.grid(column=3,row=0,sticky='w')
        self.__lbl_device_commands_flex_io_initialize4 = Label(self.__frame_device_commands_for_flex_io,text='Lower')
        self.__lbl_device_commands_flex_io_initialize4.grid(column=4,row=0,sticky='w')
        self.__btn_cmd_flex_io_initialize = Button(self.__frame_device_commands_for_flex_io,text='Initialize',width=15,command=self.__cmd_initialize_selected_device)
        self.__btn_cmd_flex_io_initialize.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_flex_io_initialize1 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_initialize1.grid(column=1,row=1,sticky='w')
        self.__tb_cmd_flex_io_initialize2 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_initialize2.grid(column=2,row=1,sticky='w')
        self.__tb_cmd_flex_io_initialize3 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_initialize3.grid(column=3,row=1,sticky='w')
        self.__tb_cmd_flex_io_initialize4 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_initialize4.grid(column=4,row=1,sticky='w')
        #Pulse(duration)
        self.__lbl_device_commands_flex_io_pulse1 = Label(self.__frame_device_commands_for_flex_io,text='Duration')
        self.__lbl_device_commands_flex_io_pulse1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_flex_io_pulse = Button(self.__frame_device_commands_for_flex_io,text='Pulse',width=15,command=self.__cmd_pulse_selected_device)
        self.__btn_cmd_flex_io_pulse.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_flex_io_pulse1 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_pulse1.grid(column=1,row=3,sticky='w')
        #State('On' or 'Off')
        self.__lbl_device_commands_flex_io_state1 = Label(self.__frame_device_commands_for_flex_io,text='On or Off')
        self.__lbl_device_commands_flex_io_state1.grid(column=1,row=4,sticky='w')
        self.__btn_cmd_flex_io_state = Button(self.__frame_device_commands_for_flex_io,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_flex_io_state.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_flex_io_state1 = Text(self.__frame_device_commands_for_flex_io,height=1,width=20,wrap='none')
        self.__tb_cmd_flex_io_state1.grid(column=1,row=5,sticky='w')
        #Toggle
        self.__btn_cmd_flex_io_toggle = Button(self.__frame_device_commands_for_flex_io,text='Toggle',width=15,command=self.__cmd_toggle_selected_device)
        self.__btn_cmd_flex_io_toggle.grid(column=0,row=6,sticky='w')

        self.__frame_device_commands_for_ir = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_ir.grid(column=0,row=6,sticky='w')
        #PlayContinuous(command)
        self.__lbl_device_commands_ir_playcontinuous1 = Label(self.__frame_device_commands_for_ir,text='Command')
        self.__lbl_device_commands_ir_playcontinuous1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_ir_playcontinuous = Button(self.__frame_device_commands_for_ir,text='PlayContinuous',width=15,command=self.__cmd_playcontinuous_selected_device)
        self.__btn_cmd_ir_playcontinuous.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_ir_playcontinuous1 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_playcontinuous1.grid(column=1,row=1,sticky='w')
        #PlayTime(command,duration)
        self.__lbl_device_commands_ir_playtime1 = Label(self.__frame_device_commands_for_ir,text='Command')
        self.__lbl_device_commands_ir_playtime1.grid(column=1,row=2,sticky='w')
        self.__lbl_device_commands_ir_playtime2 = Label(self.__frame_device_commands_for_ir,text='Duration')
        self.__lbl_device_commands_ir_playtime2.grid(column=2,row=2,sticky='w')
        self.__btn_cmd_ir_playtime = Button(self.__frame_device_commands_for_ir,text='PlayTime',width=15,command=self.__cmd_playtime_selected_device)
        self.__btn_cmd_ir_playtime.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_ir_playtime1 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_playtime1.grid(column=1,row=3,sticky='w')
        self.__tb_cmd_ir_playtime2 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_playtime2.grid(column=2,row=3,sticky='w')
        #PlayCount(comand,count)
        self.__lbl_device_commands_ir_playcount1 = Label(self.__frame_device_commands_for_ir,text='Command')
        self.__lbl_device_commands_ir_playcount1.grid(column=1,row=4,sticky='w')
        self.__lbl_device_commands_ir_playcount2 = Label(self.__frame_device_commands_for_ir,text='Count')
        self.__lbl_device_commands_ir_playcount2.grid(column=2,row=4,sticky='w')
        self.__btn_cmd_ir_playcount = Button(self.__frame_device_commands_for_ir,text='PlayCount',width=15,command=self.__cmd_playcount_selected_device)
        self.__btn_cmd_ir_playcount.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_ir_playcount1 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_playcount1.grid(column=1,row=5,sticky='w')
        self.__tb_cmd_ir_playcount2 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_playcount2.grid(column=2,row=5,sticky='w')
        #Stop
        self.__btn_cmd_ir_stop = Button(self.__frame_device_commands_for_ir,text='Stop',width=15,command=self.__cmd_stop_selected_device)
        self.__btn_cmd_ir_stop.grid(column=0,row=6,sticky='w')
        #Initialize(file)
        self.__lbl_device_commands_ir_initialize1 = Label(self.__frame_device_commands_for_ir,text='Command')
        self.__lbl_device_commands_ir_initialize1.grid(column=1,row=7,sticky='w')
        self.__btn_cmd_ir_initialize = Button(self.__frame_device_commands_for_ir,text='Initialize',width=15,command=self.__cmd_initialize_selected_device)
        self.__btn_cmd_ir_initialize.grid(column=0,row=8,sticky='w')
        self.__tb_cmd_ir_initialize1 = Text(self.__frame_device_commands_for_ir,height=1,width=20,wrap='none')
        self.__tb_cmd_ir_initialize1.grid(column=1,row=8,sticky='w')

        self.__frame_device_commands_for_poe = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_poe.grid(column=0,row=7,sticky='w')
        #State('On' or 'Off')
        self.__lbl_device_commands_poe_state1 = Label(self.__frame_device_commands_for_poe,text='On or Off')
        self.__lbl_device_commands_poe_state1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_poe_state = Button(self.__frame_device_commands_for_poe,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_poe_state.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_poe_state1 = Text(self.__frame_device_commands_for_poe,height=1,width=20,wrap='none')
        self.__tb_cmd_poe_state1.grid(column=1,row=1,sticky='w')
        #Toggle
        self.__btn_cmd_poe_toggle = Button(self.__frame_device_commands_for_poe,text='Toggle',width=15,command=self.__cmd_toggle_selected_device)
        self.__btn_cmd_poe_toggle.grid(column=0,row=2,sticky='w')

        self.__frame_device_commands_for_relay = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_relay.grid(column=0,row=8,sticky='w')
        #Pulse(duration)
        self.__lbl_device_commands_relay_pulse1 = Label(self.__frame_device_commands_for_relay,text='Duration')
        self.__lbl_device_commands_relay_pulse1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_relay_pulse = Button(self.__frame_device_commands_for_relay,text='Pulse',width=15,command=self.__cmd_pulse_selected_device)
        self.__btn_cmd_relay_pulse.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_relay_pulse1 = Text(self.__frame_device_commands_for_relay,height=1,width=20,wrap='none')
        self.__tb_cmd_relay_pulse1.grid(column=1,row=1,sticky='w')
        #State('Open' or 'Close')
        self.__lbl_device_commands_relay_state1 = Label(self.__frame_device_commands_for_relay,text='Open or Close')
        self.__lbl_device_commands_relay_state1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_relay_state = Button(self.__frame_device_commands_for_relay,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_relay_state.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_relay_state1 = Text(self.__frame_device_commands_for_relay,height=1,width=20,wrap='none')
        self.__tb_cmd_relay_state1.grid(column=1,row=3,sticky='w')
        #Toggle
        self.__btn_cmd_relay_toggle = Button(self.__frame_device_commands_for_relay,text='Toggle',width=15,command=self.__cmd_toggle_selected_device)
        self.__btn_cmd_relay_toggle.grid(column=0,row=4,sticky='w')

        self.__frame_device_commands_for_swac_receptacle = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_swac_receptacle.grid(column=0,row=9,sticky='w')
        #State('On' or 'Off')
        self.__lbl_device_commands_swac_receptacle_state1 = Label(self.__frame_device_commands_for_swac_receptacle,text='On or Off')
        self.__lbl_device_commands_swac_receptacle_state1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_swac_receptacle_state = Button(self.__frame_device_commands_for_swac_receptacle,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_swac_receptacle_state.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_swac_receptacle_state1 = Text(self.__frame_device_commands_for_swac_receptacle,height=1,width=20,wrap='none')
        self.__tb_cmd_swac_receptacle_state1.grid(column=1,row=1,sticky='w')
        #Toggle
        self.__btn_cmd_swac_receptacle_toggle = Button(self.__frame_device_commands_for_swac_receptacle,text='Toggle',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_swac_receptacle_toggle.grid(column=0,row=2,sticky='w')

        self.__frame_device_commands_for_sw_power = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_sw_power.grid(column=0,row=10,sticky='w')
        #Pulse(duration)
        self.__lbl_device_commands_sw_power_pulse1 = Label(self.__frame_device_commands_for_sw_power,text='Duration')
        self.__lbl_device_commands_sw_power_pulse1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_sw_power_pulse = Button(self.__frame_device_commands_for_sw_power,text='Pulse',width=15,command=self.__cmd_pulse_selected_device)
        self.__btn_cmd_sw_power_pulse.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_sw_power_pulse1 = Text(self.__frame_device_commands_for_sw_power,height=1,width=20,wrap='none')
        self.__tb_cmd_sw_power_pulse1.grid(column=1,row=1,sticky='w')
        #State('Open' or 'Close')
        self.__lbl_device_commands_sw_power_state1 = Label(self.__frame_device_commands_for_sw_power,text='Open or Close')
        self.__lbl_device_commands_sw_power_state1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_sw_power_state = Button(self.__frame_device_commands_for_sw_power,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_sw_power_state.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_sw_power_state1 = Text(self.__frame_device_commands_for_sw_power,height=1,width=20,wrap='none')
        self.__tb_cmd_sw_power_state1.grid(column=1,row=3,sticky='w')
        #Toggle
        self.__btn_cmd_sw_power_toggle = Button(self.__frame_device_commands_for_sw_power,text='Toggle',width=15,command=self.__cmd_toggle_selected_device)
        self.__btn_cmd_sw_power_toggle.grid(column=0,row=4,sticky='w')

        self.__frame_device_commands_for_tally = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_tally.grid(column=0,row=11,sticky='w')
        #Pulse(duration)
        self.__lbl_device_commands_tally_pulse1 = Label(self.__frame_device_commands_for_tally,text='Duration')
        self.__lbl_device_commands_tally_pulse1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_tally_pulse = Button(self.__frame_device_commands_for_tally,text='Pulse',width=15,command=self.__cmd_pulse_selected_device)
        self.__btn_cmd_tally_pulse.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_tally_pulse1 = Text(self.__frame_device_commands_for_tally,height=1,width=20,wrap='none')
        self.__tb_cmd_tally_pulse1.grid(column=1,row=1,sticky='w')
        #State('On' or 'Off')
        self.__lbl_device_commands_tally_state1 = Label(self.__frame_device_commands_for_tally,text='On or Off')
        self.__lbl_device_commands_tally_state1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_tally_state = Button(self.__frame_device_commands_for_tally,text='State',width=15,command=self.__cmd_state_selected_device)
        self.__btn_cmd_tally_state.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_tally_state1 = Text(self.__frame_device_commands_for_tally,height=1,width=20,wrap='none')
        self.__tb_cmd_tally_state1.grid(column=1,row=3,sticky='w')
        #Toggle
        self.__btn_cmd_tally_toggle = Button(self.__frame_device_commands_for_tally,text='Toggle',width=15,command=self.__cmd_toggle_selected_device)
        self.__btn_cmd_tally_toggle.grid(column=0,row=4,sticky='w')

        self.__frame_device_commands_for_volume = Frame(self.__frame_device_commands)
        self.__frame_device_commands_for_volume.grid(column=0,row=12,sticky='w')
        #Level(value)
        self.__lbl_device_commands_volume_level1 = Label(self.__frame_device_commands_for_volume,text='Number')
        self.__lbl_device_commands_volume_level1.grid(column=1,row=0,sticky='w')
        self.__btn_cmd_volume_level = Button(self.__frame_device_commands_for_volume,text='Volume',width=15,command=self.__cmd_level_selected_device)
        self.__btn_cmd_volume_level.grid(column=0,row=1,sticky='w')
        self.__tb_cmd_volume_level1 = Text(self.__frame_device_commands_for_volume,height=1,width=20,wrap='none')
        self.__tb_cmd_volume_level1.grid(column=1,row=1,sticky='w')
        #Mute('On' or 'Off')
        self.__lbl_device_commands_volume_mute1 = Label(self.__frame_device_commands_for_volume,text='On or Off')
        self.__lbl_device_commands_volume_mute1.grid(column=1,row=2,sticky='w')
        self.__btn_cmd_volume_mute = Button(self.__frame_device_commands_for_volume,text='Mute',width=15,command=self.__cmd_mute_selected_device)
        self.__btn_cmd_volume_mute.grid(column=0,row=3,sticky='w')
        self.__tb_cmd_volume_mute1 = Text(self.__frame_device_commands_for_volume,height=1,width=20,wrap='none')
        self.__tb_cmd_volume_mute1.grid(column=1,row=3,sticky='w')
        #Range(min,max)
        self.__lbl_device_commands_volume_range1 = Label(self.__frame_device_commands_for_volume,text='Min')
        self.__lbl_device_commands_volume_range1.grid(column=1,row=4,sticky='w')
        self.__lbl_device_commands_volume_range1 = Label(self.__frame_device_commands_for_volume,text='Max')
        self.__lbl_device_commands_volume_range1.grid(column=2,row=4,sticky='w')
        self.__btn_cmd_volume_range = Button(self.__frame_device_commands_for_volume,text='Range',width=15,command=self.__cmd_range_selected_device)
        self.__btn_cmd_volume_range.grid(column=0,row=5,sticky='w')
        self.__tb_cmd_volume_range1 = Text(self.__frame_device_commands_for_volume,height=1,width=20,wrap='none')
        self.__tb_cmd_volume_range1.grid(column=1,row=5,sticky='w')
        self.__tb_cmd_volume_range2 = Text(self.__frame_device_commands_for_volume,height=1,width=20,wrap='none')
        self.__tb_cmd_volume_range2.grid(column=2,row=5,sticky='w')
        #SoftStart('Enabled' or 'Disabled')
        self.__lbl_device_commands_volume_softstart1 = Label(self.__frame_device_commands_for_volume,text='Enabled or Disabled')
        self.__lbl_device_commands_volume_softstart1.grid(column=1,row=6,sticky='w')
        self.__btn_cmd_volume_softstart = Button(self.__frame_device_commands_for_volume,text='SoftStart',width=15,command=self.__cmd_softstart_selected_device)
        self.__btn_cmd_volume_softstart.grid(column=0,row=7,sticky='w')
        self.__tb_cmd_volume_softstart1 = Text(self.__frame_device_commands_for_volume,height=1,width=20,wrap='none')
        self.__tb_cmd_volume_softstart1.grid(column=1,row=7,sticky='w')

        self.__device_commands_frames = {'Circuit Breaker':self.__frame_device_commands_for_circuit_breaker,
                  'Contact':self.__frame_device_commands_for_contact,
                  'Digital Input':self.__frame_device_commands_for_digital_input,
                  'Digital IO':self.__frame_device_commands_for_digital_io,
                  'Flex IO':self.__frame_device_commands_for_flex_io,
                  'IR':self.__frame_device_commands_for_ir,
                  'Serial':self.__frame_device_commands_for_modules,
                  'SerialOverEthernet':self.__frame_device_commands_for_modules,
                  'Ethernet':self.__frame_device_commands_for_modules,
                  'SPI':self.__frame_device_commands_for_modules,
                  'PoE':self.__frame_device_commands_for_poe,
                  'Relay':self.__frame_device_commands_for_relay,
                  'SW Power':self.__frame_device_commands_for_sw_power,
                  'SWAC Receptacle':self.__frame_device_commands_for_swac_receptacle,
                  'Tally':self.__frame_device_commands_for_tally,
                  'Volume':self.__frame_device_commands_for_volume}
        self.__hide_device_commands()
        self.Hide(self.__frame_log)
        self.Hide(self.__frame_status)
        self.Hide(self.__frame_controller_clear_logs)
        self.__controller_rxtx_view_enable()
    #class methods



    def __select_module(self,event):
        try:
            self.__selected_module = str(self.__lbox_devices.curselection()[0])
        except:
            self.__selected_module = None
        print('select module {}'.format(self.__selected_module))
        self.__set_device_communication_details(self.__selected_module)
        self.__show_device_log(self.__selected_module)
        self.__show_device_status(self.__selected_module)
        self.__show_device_commands(self.__selected_module)

    def __cmd_reinitialize_selected_module(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd reinit module{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd = '~Command~:{}:Reinit()'.format(device_id)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_update_selected_module(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd update module{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['command'] = self.__tb_update_command1.get('1.0',END)
            cmd_dict['command'] = cmd_dict['command'].strip()
            cmd_dict['qualifier'] = self.__tb_update_command2.get('1.0',END)
            cmd_dict['qualifier'] = cmd_dict['qualifier'].strip()
            try:
                cmd_dict['qualifier'] = json.loads(cmd_dict['qualifier'])
            except:
                cmd_dict['qualifier'] = None
            if cmd_dict['command'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Update({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_set_selected_module(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd set module{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['command'] = self.__tb_set_command1.get('1.0',END)
            cmd_dict['command'] = cmd_dict['command'].strip()
            cmd_dict['value'] = self.__tb_set_command2.get('1.0',END)
            cmd_dict['value'] = cmd_dict['value'].strip()
            cmd_dict['qualifier'] = self.__tb_set_command3.get('1.0',END)
            cmd_dict['qualifier'] = cmd_dict['qualifier'].strip()
            try:
                cmd_dict['qualifier'] = json.loads(cmd_dict['qualifier'])
            except:
                cmd_dict['qualifier'] = None
            if cmd_dict['command'] == '' or cmd_dict['value'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Set({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_writestatus_selected_module(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd writestatus module{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['command'] = self.__tb_writestatus_command1.get('1.0',END)
            cmd_dict['command'] = cmd_dict['command'].strip()
            cmd_dict['value'] = self.__tb_writestatus_command2.get('1.0',END)
            cmd_dict['value'] = cmd_dict['value'].strip()
            cmd_dict['qualifier'] = self.__tb_writestatus_command3.get('1.0',END)
            cmd_dict['qualifier'] = cmd_dict['qualifier'].strip()
            try:
                cmd_dict['qualifier'] = json.loads(cmd_dict['qualifier'])
            except:
                cmd_dict['qualifier'] = None
            if cmd_dict['command'] == '' or cmd_dict['value'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:WriteStatus({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_passthrough_selected_module(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd passthrough module{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            txt = self.__tb_passthrough_command.get('1.0',END)
            txt = txt.strip()
            txt = self.__eval_string(txt)
            cmd = '~Command~:{}:passthru("{}")'.format(device_id,txt)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_initialize_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd initialize device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.vars.device_info[device_id]['type']
            tbs = {'Flex IO':[self.__tb_cmd_flex_io_initialize1,self.__tb_cmd_flex_io_initialize2,self.__tb_cmd_flex_io_initialize3,self.__tb_cmd_flex_io_initialize4],
                    'Digital IO':[self.__tb_cmd_digital_io_initialize1,self.__tb_cmd_digital_io_initialize2],
                    'Digital Input':[self.__tb_cmd_digital_input_initialize1],
                    'Digital IO':[self.__tb_cmd_ir_initialize1]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if device_type in ['Digital IO','Flex IO']:
                cmd_dict['value2'] = tbs[device_type][1].get('1.0',END)
                cmd_dict['value2'] = cmd_dict['value2'].strip()
                if device_type == 'Flex IO':
                    cmd_dict['value3'] = tbs[device_type][2].get('1.0',END)
                    cmd_dict['value3'] = cmd_dict['value3'].strip()
                    cmd_dict['value4'] = tbs[device_type][3].get('1.0',END)
                    cmd_dict['value4'] = cmd_dict['value4'].strip()
            for key in cmd_dict:
                if len(cmd_dict[key]) < 1:
                    cmd_dict[key] = None
                elif cmd_dict[key] == 'True':
                    cmd_dict[key] = True
                elif cmd_dict[key] == 'False':
                    cmd_dict[key] = False
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Initialize({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_pulse_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd pulse device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.vars.device_info[device_id]['type']
            tbs = {'Relay':[self.__tb_cmd_relay_pulse1],
                    'Tally':[self.__tb_cmd_tally_pulse1],
                    'Flex IO':[self.__tb_cmd_flex_io_pulse1],
                    'SW Power':[self.__tb_cmd_sw_power_pulse1],
                    'Digital IO':[self.__tb_cmd_digital_io_pulse1]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Pulse({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_state_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd state device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            device_type = self.vars.device_info[device_id]['type']
            tbs = {'PoE':[self.__tb_cmd_poe_state1],
                    'Relay':[self.__tb_cmd_relay_state1],
                    'Tally':[self.__tb_cmd_tally_state1],
                    'Flex IO':[self.__tb_cmd_flex_io_state1],
                    'SW Power':[self.__tb_cmd_sw_power_state1],
                    'Digital IO':[self.__tb_cmd_digital_io_state1],
                    'SWAC Receptacle':[self.__tb_cmd_swac_receptacle_state1]}
            if device_type not in tbs:
                return
            cmd_dict['value1'] = tbs[device_type][0].get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:State({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_toggle_selected_device(self):
        device_id = self.__get_device_log_id(self.__selected_module)
        print('cmd Toggle device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
        cmd = '~Command~:{}:Toggle()'.format(device_id)
        self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_level_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd Level device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_volume_level1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Level({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_mute_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd Mute device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_volume_mute1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Mute({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_range_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd Range device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_volume_range1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = self.__tb_cmd_volume_range2.get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:Range({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_softstart_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd SoftStart device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_volume_softstart1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['command'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:SoftStart({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_playcontinuous_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd PlayContinuous device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_ir_playcontinuous1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            if cmd_dict['value1'] == '':
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:PlayContinuous({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_playcount_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd PlayCount device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_ir_playcount1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = self.__tb_cmd_ir_playcount1.get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2']:
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:PlayCount({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_playtime_selected_device(self):
        if self.__selected_module is not None:
            device_id = self.__get_device_log_id(self.__selected_module)
            print('cmd PlayTime device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
            cmd_dict = {}
            cmd_dict['value1'] = self.__tb_cmd_ir_playtime1.get('1.0',END)
            cmd_dict['value1'] = cmd_dict['value1'].strip()
            cmd_dict['value2'] = self.__tb_cmd_ir_playtime2.get('1.0',END)
            cmd_dict['value2'] = cmd_dict['value2'].strip()
            if cmd_dict['value1'] == '' or cmd_dict['value2']:
                return
            cmd_dict_str = json.dumps(cmd_dict)
            cmd = '~Command~:{}:PlayTime({})'.format(device_id,cmd_dict_str)
            self.vars.processor_communication.SendToSystem(cmd)
    def __cmd_stop_selected_device(self):
        device_id = self.__get_device_log_id(self.__selected_module)
        print('cmd Stop device{}:{}'.format(device_id,self.vars.device_info[device_id]['name']))
        cmd = '~Command~:{}:Stop()'.format(device_id)
        self.vars.processor_communication.SendToSystem(cmd)


    def __eval_string(self,text:'str'):
        text.replace('\\r','\\x0d')
        text.replace('\\n','\\x0a')
        while '\\x' in text:
            pos = text.find('\\x')
            temp = text[pos:pos+4]
            val = int(temp[2:],16)
            char = chr(val)
            text = text.replace(temp,char)
        return text
    def __get_device_log_id(self,pos):
        device_id = None
        pos = int(pos)
        key_list = []
        for cur in self.vars.device_info:
            key_list.append(cur)
        key_list.sort()
        if len(key_list) > pos:
            device_id = key_list[pos]
        return device_id
    def __get_device_log_pos(self,device_id):
        key_list = []
        for cur in self.vars.device_info:
            key_list.append(cur)
        key_list.sort()
        pos = None
        if device_id in key_list:
            pos = str(key_list.index(device_id))
        return pos
    def __show_device_log(self,pos):
        device_id = self.__get_device_log_id(pos)
        self.__current_tb_log = ''
        if device_id in self.__device_logs.keys():
            for log in self.__device_logs[device_id]:
                self.__current_tb_log += self.__set_device_log_hex_format(log)+'\n'
        self.__tb_log.delete('1.0','end')
        self.__tb_log.insert(END,self.__current_tb_log)
        self.__tb_log.update()
    def __show_device_status(self,pos):
        device_id = self.__get_device_log_id(pos)
        txt = ''
        if device_id in self.vars.device_info:
            txt = json.dumps(self.vars.device_info[device_id]['status'],sort_keys=True,indent=2)
        self.__tb_status.delete('1.0','end')
        self.__tb_status.insert(END,txt)
        self.__tb_status.update()
    def __hide_device_commands(self):
        for f in self.__device_commands_frames:
            self.Hide(self.__device_commands_frames[f])
    def __show_device_commands(self,pos):
        device_id = self.__get_device_log_id(pos)
        device_type = None
        self.__hide_device_commands()
        if device_id in self.vars.device_info:
            device_type = self.vars.device_info[device_id]['type']
        if device_type in self.__device_commands_frames:
            self.Show(self.__device_commands_frames[device_type])



    def __toggle_tb_timestamp(self):
        self.__timestamp_newest_first = not self.__timestamp_newest_first

        vals = {True:'Newest',False:'Oldest'}
        self.__btn_tb_sort_timestamp['text'] = 'Timestamp:{}'.format(vals[self.__timestamp_newest_first])
        print('sort the log:{}'.format(self.__timestamp_newest_first))
        for key in self.__device_logs:
            self.__device_logs[key].sort(reverse=self.__timestamp_newest_first)
        self.__show_device_log(self.__selected_module)

    def __clear_device_communication_details(self):
        self.__lbl_selected_device_name.config(text= ' Selected: None')
        self.__lbl_device_comm_detail1.config(text= ' ')
        self.__lbl_device_comm_detail2.config(text= ' ')
        self.__lbl_device_comm_detail3.config(text= ' ')
        self.__lbl_device_comm_detail4.config(text= ' ')
        self.__lbl_device_comm_detail5.config(text= ' ')
        self.__lbl_device_comm_detail6.config(text= ' ')
        self.__lbl_device_comm_detail7.config(text= ' ')
    def __set_device_communication_details(self,pos):
        self.__clear_device_communication_details()
        device_id = self.__get_device_log_id(pos)
        self.__lbl_selected_device_name.config(text= ' Selected: {} '.format(self.vars.device_info[device_id]['name']))
        if 'communication' in self.vars.device_info[device_id]:
            conn_details = self.vars.device_info[device_id]['communication']
            dtype = conn_details['type']
            self.__lbl_device_comm_detail1.config(text= ' Type: {} '.format(conn_details['type']))
            self.__lbl_device_comm_detail2.config(text= ' Host: {} '.format(conn_details['host']))
            if dtype == 'SPI':
                pass
            if dtype == 'Serial':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Mode: {} '.format(conn_details['mode']))
                self.__lbl_device_comm_detail5.config(text= ' Baud: {} '.format(conn_details['baud']))
            elif dtype == 'Ethernet' or dtype == 'SerialOverEthernet':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Mode: {} '.format(conn_details['mode']))
                if conn_details['mode'] == 'UDP':
                    self.__lbl_device_comm_detail5.config(text= ' Service Port: {} '.format(conn_details['serviceport']))
            elif dtype == 'SSH':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Mode: {} '.format(conn_details['mode']))
                self.__lbl_device_comm_detail5.config(text= ' Credentials: {} '.format(conn_details['credentials']))
            elif dtype == 'Circuit Breaker':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'Contact':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'Digital Input':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Pullup: {} '.format(conn_details['pullup']))
            elif dtype == 'Digital IO':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Mode: {} '.format(conn_details['mode']))
                self.__lbl_device_comm_detail5.config(text= ' Pullup: {} '.format(conn_details['pullup']))
            elif dtype == 'Flex IO':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' Mode: {} '.format(conn_details['mode']))
                self.__lbl_device_comm_detail5.config(text= ' Pullup: {} '.format(conn_details['pullup']))
                self.__lbl_device_comm_detail6.config(text= ' Upper: {} '.format(conn_details['upper']))
                self.__lbl_device_comm_detail7.config(text= ' Lower: {} '.format(conn_details['lower']))
            elif dtype == 'IR':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
                self.__lbl_device_comm_detail4.config(text= ' File: {} '.format(conn_details['file']))
            elif dtype == 'Relay':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'SWAC Receptacle':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'SW Power':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'Tally':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))
            elif dtype == 'Volume':
                self.__lbl_device_comm_detail3.config(text= ' Port: {} '.format(conn_details['port']))


    def __clear_current_device_log(self):
        print('clear current device log')
        device_id = self.__get_device_log_id(self.__selected_module)
        self.__device_logs[device_id] = []
        self.__show_device_log(self.__selected_module)

    def __clear_all_device_logs(self):
        print('clear all device logs')
        for selected_module in range(self.__lbox_devices.size()):
            device_id = self.__get_device_log_id(selected_module)
            self.__device_logs[device_id] = []
            self.__show_device_log(0)

    def __pause_current_device_log(self):
        self.__tb_pause_flag = not self.__tb_pause_flag
        if self.__tb_pause_flag:
            self.__btn_tb_pause_log['text'] = 'Resume Log'
            self.__btn_tb_pause_log['bg'] = 'sky blue'
        else:
            self.__btn_tb_pause_log['text'] = 'Pause Log'
            self.__btn_tb_pause_log['bg'] = '#f0f0f0'
            if self.__selected_module:
                self.__show_device_log(self.__selected_module)

    def __format_device_log(self):
        self.__tb_hex_flag = not self.__tb_hex_flag
        if self.__tb_hex_flag:
            self.__btn_tb_hex_format['bg'] = 'sky blue'
        else:
            self.__btn_tb_hex_format['bg'] = '#f0f0f0'
        if self.__selected_module:
            self.__show_device_log(self.__selected_module)

    def __format_new_log(self,log:'str'):
        log = log.replace('\\\\','\\')
        log = log.replace("-'<<",'-<<')
        log = log.replace("-'>>",'->>')
        if log[-2:] == '\'"':
            log = log[:-2]
        elif log[-1:] == '\'':
            log = log[:-1]
        return log
    def __set_device_log_hex_format(self,log:'str'):
        if self.__tb_hex_flag:
            log = log.replace('\\r','\x0d')
            log = log.replace('\\n','\x0a')
            matches = re.findall('\\\\x(..)',log)
            for match in matches:
                match_str = '0x{}'.format(match.upper())
                an_integer = int(match_str,16)
                log = log.replace('\\x{}'.format(match),chr(an_integer))
            temp = '\\x'
            if '>>' in log:
                parts = log.split(">>")
                temp += "\x5Cx".join("{:02x}".format(ord(c)) for c in parts[1])
                return('{}>>{}'.format(parts[0],temp))
            elif '<<' in log:
                parts = log.split("<<")
                temp += "\x5Cx".join("{:02x}".format(ord(c)) for c in parts[1])
                return('{}<<{}'.format(parts[0],temp))
            else:
                return(log)
        return(log)

    def __controller_rxtx_view_enable(self):
        self.__current_device_view = 0
        self.Hide(self.__frame_status)
        self.Show(self.__frame_log)
        self.Show(self.__frame_controller_clear_logs)
        self.__btn_tb_view_status_view['bg'] = '#f0f0f0'
        self.__btn_tb_view_rxtx_view['bg'] = 'sky blue'
    def __controller_status_view_enable(self):
        self.__current_device_view = 1
        self.Hide(self.__frame_log)
        self.Show(self.__frame_status)
        self.Hide(self.__frame_controller_clear_logs)
        self.__btn_tb_view_rxtx_view['bg'] = '#f0f0f0'
        self.__btn_tb_view_status_view['bg'] = 'sky blue'


    #public functions
    def SetDeviceInfo(self,device_info):
        self.vars.device_info.update(device_info)
    def UpdateDeviceLog(self,device:'str',data:'str'):
        data = self.__format_new_log(data)
        if device not in self.__device_logs.keys():
            self.__device_logs[device] = []
        if self.__timestamp_newest_first:
            self.__device_logs[device].insert(0,data)
        else:
            self.__device_logs[device].append(data)
        pos = self.__get_device_log_pos(device)
        if pos and not self.__tb_pause_flag:
            if pos == self.__selected_module:
                self.__show_device_log(pos)
    def UpdateDeviceInfo(self,key):
        id = self.__get_device_log_pos(key)
        if id == self.__selected_module:
            self.__show_device_status(id)

    def SetDeviceList(self):
        self.__clear_device_communication_details()
        self.__hide_device_commands()
        self.__tb_log.delete('1.0','end')
        self.__tb_status.delete('1.0','end')
        self.__selected_module = None
        self.__lbox_devices.delete(0,END)
        key_list = list(self.vars.device_info.keys()) #type:list
        for i in key_list:
            key_list[key_list.index(i)] = int(i)
        key_list.sort()
        for i in key_list:
            self.__lbox_devices.insert(str(i),self.vars.device_info[str(i)]['name'])
        self.__clear_all_device_logs()
    def SetConnectStatus(self,txt):
        self.__lbl_controller_status['text'] = 'Status : {} {}'.format(self.vars.ip_address,txt)
    def Hide(self,frame=None):
        if frame:
            frame._grid_info = frame.grid_info()
            frame.grid_remove()
        else:
            self.__frame._grid_info = self.__frame.grid_info()
            self.__frame.grid_remove()
    def Show(self,frame=None):
        if frame:
            frame.grid(**frame._grid_info)
        else:
            self.__frame.grid(**self.__frame._grid_info)
